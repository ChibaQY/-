#include "draw.h"



#include <tuple>
#include <stdbool.h>

#include <mutex>

#include <map>












#include <cstdio>






#include <filesystem> // 用于递归搜索文件

#include <filesystem>
#include <regex>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>


#include<string.h>
   
#include "My_icon/pic_ZhenAiKun_png.h"
#include <fstream>
#include <cstring> // 包含 strlen 函数
#include "draw.h"
#include <thread>
#include <cstdint>
#include <stdio.h>
#include "My_font/zh_Font.h"
#include "My_font/fontawesome-brands.h"
#include "My_font/fontawesome-regular.h"
#include "My_font/fontawesome-solid.h"
#include "My_font/gui_icon.h"
#include "kerneldriver-qxqd.hpp"
#include "DrawTool.h"
#include "Name.h"
#include <string>
#include <stdbool.h>
#include <iostream>
#include <fstream>
#include <cctype>
#include <sstream>
#include <unordered_map> //用于引入无序映射容器，方便记录对象和编号的对应关系
#include <vector>
#include <cmath>
#include "imgui.h"
#include <utility>
#include <chrono>
#include <thread>
#include <chrono>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <linux/input.h>
#include <dirent.h>
#include <algorithm>
#include <sstream>
#include <atomic>
#include <cstdlib>
#include <dirent.h>
#include <fcntl.h>
#include <linux/input.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <vector>

#include <set>


#include <stdio.h>
#include <fcntl.h>
#include <linux/input.h>
#include <unistd.h>
#include <errno.h>
#include<string>
std::vector<std::tuple<float, float, float>> motorCoordinates;
std::unordered_set<std::string> recordedMotorPositions;
bool 天赋查看 = false;
bool 电机进度 = false;
float gg0;
float ggx1, ggy1, ggz1;
float ggx2, ggy2, ggz2;
float ggx3, ggy3, ggz3;
float ggx4, ggy4, ggz4;
float ggx5, ggy5, ggz5;
float ggx6, ggy6, ggz6;
float ggx7, ggy7, ggz7;
float ggx8, ggy8, ggz8;
float ggx9, ggy9, ggz9;
float ggx10, ggy10, ggz10;
float ggx11, ggy11, ggz11;
float ggx12, ggy12, ggz12;
float ggx13, ggy13, ggz13;
float ggx14, ggy14, ggz14;
float ggx15, ggy15, ggz15;
bool 网页开关=false;
float 自身向量X;
float 自身向量Y;
float 敌人向量X;
float 敌人向量Y;
int 实验偏移量 = 0;
int 按钮按下次数 = 0;
float globalVar1;
float globalVar2;
float globalVar3;
float globalVar4;
float globalVar5;
float globalVar6;
float globalVar7;
float globalVar8;
float globalVar9;
float globalVar10;
float globalVar11;
float globalVar12;
float globalVar13;
float globalVar14;
float globalVar15;
float globalVar16;
float globalVar17;
float globalVar18;
float globalVar19;
float globalVar20;


namespace fs = std::filesystem;

// 玩家信息结构
struct PlayerInfo {
    std::string name;
    std::vector<std::string> talents;
};

// 程序状态结构
struct AppState {
    std::vector<PlayerInfo> players;
    std::string status = "等待数据...";
    std::chrono::steady_clock::time_point last_check;
};

// 天赋ID到名称的映射
const std::map<int, std::string> TALENT_MAP = {
    {8, "飞轮"},
    {16, "大心脏"},
    {24, "搏命"},
    {32, "双弹"}
};

// 预处理字符串
std::string preprocess_content(const std::string& content) {
    std::string result;
    bool in_string = false;

    for (size_t i = 0; i < content.size(); i++) {
        char c = content[i];

        if (c == '\\' && i + 1 < content.size()) {
            result += c;
            result += content[++i];
            continue;
        }

        if (c == '\'') {
            result += '"';
            in_string = !in_string;
            continue;
        }

        if (!in_string) {
            if (i + 4 <= content.size() && content.substr(i, 4) == "None" &&
                (i + 4 == content.size() || !isalnum(content[i + 4]))) {
                result += "null";
                i += 3;
                continue;
            }
            if (i + 4 <= content.size() && content.substr(i, 4) == "True" &&
                (i + 4 == content.size() || !isalnum(content[i + 4]))) {
                result += "true";
                i += 3;
                continue;
            }
            if (i + 5 <= content.size() && content.substr(i, 5) == "False" &&
                (i + 5 == content.size() || !isalnum(content[i + 5]))) {
                result += "false";
                i += 4;
                continue;
            }
        }

        result += c;
    }

    return result;
}

// 递归查找战斗快照文件
fs::path find_snapshot_file(const fs::path& search_dir) {
    // 使用错误码替代异常
    std::error_code ec;

    // 首先检查当前目录
    for (const auto& entry : fs::directory_iterator(search_dir, ec)) {
        if (ec) {
            ec.clear(); // 清除错误，继续下一个
            continue;
        }

        if (entry.is_regular_file(ec) &&
            entry.path().filename() == "battle_frames_snapshot_0_deserialized.txt") {
            return entry.path();
        }
    }

    // 清除可能的错误
    ec.clear();

    // 递归检查子目录
    for (const auto& entry : fs::directory_iterator(search_dir, ec)) {
        if (ec) {
            ec.clear(); // 清除错误，继续下一个
            continue;
        }

        if (entry.is_directory(ec)) {
            fs::path found_file = find_snapshot_file(entry.path());
            if (!found_file.empty()) {
                return found_file;
            }
        }
    }

    return fs::path(); // 未找到
}
void ApplyPinkTheme()
{
    ImGuiStyle& style = ImGui::GetStyle();

    // 主色调 - 粉色系
    ImVec4 primaryColor = ImVec4(0.9f, 0.4f, 0.7f, 1.0f);     // 浅粉色
    ImVec4 secondaryColor = ImVec4(0.8f, 0.2f, 0.5f, 1.0f);   // 深粉色
    ImVec4 accentColor = ImVec4(1.0f, 0.6f, 0.8f, 1.0f);      // 亮粉色

    // 背景色
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.1f, 0.05f, 0.08f, 0.94f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.15f, 0.07f, 0.1f, 0.9f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.15f, 0.07f, 0.1f, 0.98f);

    // 边框
    style.Colors[ImGuiCol_Border] = ImVec4(0.5f, 0.2f, 0.3f, 0.5f);
    style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);

    // 标题栏
    style.Colors[ImGuiCol_TitleBg] = secondaryColor;
    style.Colors[ImGuiCol_TitleBgActive] = secondaryColor;
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.2f, 0.1f, 0.15f, 0.9f);

    // 菜单
    style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.2f, 0.1f, 0.15f, 0.8f);

    // 滚动条
    style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.1f, 0.05f, 0.08f, 0.9f);
    style.Colors[ImGuiCol_ScrollbarGrab] = primaryColor;
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = accentColor;
    style.Colors[ImGuiCol_ScrollbarGrabActive] = accentColor;

    // 按钮
    style.Colors[ImGuiCol_Button] = primaryColor;
    style.Colors[ImGuiCol_ButtonHovered] = accentColor;
    style.Colors[ImGuiCol_ButtonActive] = secondaryColor;

    // 复选框/单选框
    style.Colors[ImGuiCol_CheckMark] = accentColor;

    // 滑块
    style.Colors[ImGuiCol_SliderGrab] = primaryColor;
    style.Colors[ImGuiCol_SliderGrabActive] = accentColor;

    // 文本
    style.Colors[ImGuiCol_Text] = ImVec4(0.95f, 0.9f, 0.92f, 1.0f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.5f, 0.4f, 0.45f, 1.0f);

    // 选择状态
    style.Colors[ImGuiCol_Header] = primaryColor;
    style.Colors[ImGuiCol_HeaderHovered] = accentColor;
    style.Colors[ImGuiCol_HeaderActive] = secondaryColor;

    // 其他UI元素
    style.Colors[ImGuiCol_ResizeGrip] = primaryColor;
    style.Colors[ImGuiCol_ResizeGripHovered] = accentColor;
    style.Colors[ImGuiCol_ResizeGripActive] = secondaryColor;

    style.Colors[ImGuiCol_PlotLines] = accentColor;
    style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(1.0f, 0.8f, 0.9f, 1.0f);
    style.Colors[ImGuiCol_PlotHistogram] = primaryColor;
    style.Colors[ImGuiCol_PlotHistogramHovered] = accentColor;

    // 样式调整
    style.WindowPadding = ImVec2(8, 8);
    style.FramePadding = ImVec2(5, 3);
    style.ItemSpacing = ImVec2(6, 3);
    style.ItemInnerSpacing = ImVec2(4, 4);
    style.IndentSpacing = 21.0f;
    style.ScrollbarSize = 14.0f;

    style.GrabMinSize = 10.0f;

    style.WindowBorderSize = 1.0f;
    style.ChildBorderSize = 1.0f;
    style.PopupBorderSize = 1.0f;
    style.FrameBorderSize = 0.0f;
    style.TabBorderSize = 0.0f;

    style.WindowRounding = 4.0f;
    style.ChildRounding = 4.0f;
    style.FrameRounding = 3.0f;
    style.PopupRounding = 4.0f;
    style.ScrollbarRounding = 9.0f;
    style.GrabRounding = 3.0f;
    style.TabRounding = 4.0f;
}
// 解析文件内容
void parse_file(AppState& state, const fs::path& file_path) {
    state.players.clear();

    // 使用错误码打开文件
    std::error_code ec;
    if (!fs::exists(file_path, ec) || ec) {
        state.status = "文件不存在";
        return;
    }

    // 读取文件内容
    std::ifstream file(file_path);
    if (!file.is_open()) {
        state.status = "无法打开文件";
        return;
    }

    // 获取文件大小
    file.seekg(0, std::ios::end);
    size_t size = file.tellg();
    if (size == 0) {
        state.status = "文件为空";
        file.close();
        return;
    }

    file.seekg(0, std::ios::beg);

    // 分配内存并读取内容
    std::string content(size, ' ');
    file.read(&content[0], size);
    file.close();

    // 预处理内容
    std::string json_str = preprocess_content(content);

    // 解析玩家数据
    size_t pos = 0;
    while ((pos = json_str.find("\"player_name\":", pos)) != std::string::npos) {
        PlayerInfo player;

        // 提取玩家名字
        size_t name_start = json_str.find("\"", pos + 14) + 1;
        if (name_start == std::string::npos) break;

        size_t name_end = json_str.find("\"", name_start);
        if (name_end == std::string::npos) break;

        player.name = json_str.substr(name_start, name_end - name_start);

        // 查找天赋数据
        size_t talents_pos = json_str.find("\"genius_id_lvs\":", name_end);
        if (talents_pos == std::string::npos) break;

        size_t array_start = json_str.find("[[", talents_pos);
        if (array_start == std::string::npos) break;

        size_t array_end = json_str.find("]]", array_start);
        if (array_end == std::string::npos) break;

        // 提取天赋数组部分
        std::string talent_str = json_str.substr(array_start, array_end - array_start + 2);
        size_t id_pos = 0;

        while ((id_pos = talent_str.find('[', id_pos)) != std::string::npos) {
            size_t comma_pos = talent_str.find(',', id_pos);
            if (comma_pos == std::string::npos) break;

            std::string id_str = talent_str.substr(id_pos + 1, comma_pos - id_pos - 1);

            // 安全转换字符串为整数
            char* end_ptr = nullptr;
            long talent_id = std::strtol(id_str.c_str(), &end_ptr, 10);

            if (end_ptr != id_str.c_str() && *end_ptr == '\0') {
                auto it = TALENT_MAP.find(static_cast<int>(talent_id));
                if (it != TALENT_MAP.end()) {
                    player.talents.push_back(it->second);
                }
            }

            id_pos = comma_pos + 1;
        }

        state.players.push_back(player);
        pos = array_end;
    }

    if (state.players.empty()) {
        state.status = "未找到玩家数据";
    }
    else {
        state.status = "已加载 " + std::to_string(state.players.size()) + " 名玩家";
    }
}

// 在ImGui中显示结果
void show_talent_viewer() {
    static AppState state;
    // 基础路径
    static const fs::path base_dir = "/storage/emulated/0/Android/data/com.netease.dwrg/files/netease/dwrg.common/Documents/video/";

    // 每1秒检查一次文件更新
    auto now = std::chrono::steady_clock::now();
    if (now - state.last_check > std::chrono::seconds(1)) {
        state.last_check = now;

        fs::path snapshot_file = find_snapshot_file(base_dir);
        if (!snapshot_file.empty()) {
            parse_file(state, snapshot_file);
            state.status = "      Riley" ;
        }
        else {
            state.status = "正在获取数据";
            state.players.clear();
        }
    }
    ImGui::SetNextWindowBgAlpha(0.0f);  // 完全透明
    // 创建窗口
    ImGui::Begin("天赋");
    ApplyPinkTheme();
    // 显示状态信息
  //  ImGui::TextColored(ImVec4(1, 1, 0, 1), "%s", state.status.c_str());
   // ImGui::Separator();

    // 显示玩家信息表
    if (state.players.empty()) {
        ImGui::Text("获取中");
    }
    else {
        if (ImGui::BeginTable("玩家天赋", 2,
            ImGuiTableFlags_Borders |
            ImGuiTableFlags_RowBg |
            ImGuiTableFlags_SizingFixedFit)) {
            // 设置列
            ImGui::TableSetupColumn("玩家名称", ImGuiTableColumnFlags_WidthFixed, 150);
            ImGui::TableSetupColumn("携带天赋", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableHeadersRow();

            // 填充数据
            for (const auto& player : state.players) {
                ImGui::TableNextRow();

                // 玩家名称
                ImGui::TableSetColumnIndex(0);
                ImGui::Text("%s", player.name.c_str());

                // 天赋列表
                ImGui::TableSetColumnIndex(1);
                for (size_t i = 0; i < player.talents.size(); i++) {
                    ImGui::Text("%s", player.talents[i].c_str());
                    if (i < player.talents.size() - 1) {
                        ImGui::SameLine();
                    }
                }
            }

            ImGui::EndTable();
        }
    }

    ImGui::End();
}








// 发电机记录结构
struct GeneratorRecord {
    uint32_t uid;
    int process;
    std::vector<float> position;
};

// 发电机程序状态结构
struct GeneratorState {
    std::map<uint32_t, GeneratorRecord> records_map; // 按UID存储记录，只保留最大进度的记录
    std::vector<GeneratorRecord> records_display;    // 用于显示的记录列表
    std::map<uint32_t, std::vector<float>> uid_positions; // 所有UID到坐标的映射
    std::string status = "等待发电机数据...";
    std::chrono::steady_clock::time_point last_check;
    std::map<std::string, fs::file_time_type> last_modified;
};
GeneratorState g_GeneratorState;
// 预处理函数
std::string preprocess_generator_content(const std::string& content) {
    std::string result;
    bool in_string = false;

    for (size_t i = 0; i < content.size(); i++) {
        char c = content[i];

        if (c == '\\' && i + 1 < content.size()) {
            result += c;
            result += content[++i];
            continue;
        }

        if (c == '\'') {
            result += '"';
            in_string = !in_string;
            continue;
        }

        if (!in_string) {
            if (i + 4 <= content.size() && content.substr(i, 4) == "None" &&
                (i + 4 == content.size() || !isalnum(content[i + 4]))) {
                result += "null";
                i += 3;
                continue;
            }
            if (i + 4 <= content.size() && content.substr(i, 4) == "True" &&
                (i + 4 == content.size() || !isalnum(content[i + 4]))) {
                result += "true";
                i += 3;
                continue;
            }
            if (i + 5 <= content.size() && content.substr(i, 5) == "False" &&
                (i + 5 == content.size() || !isalnum(content[i + 5]))) {
                result += "false";
                i += 4;
                continue;
            }
        }

        result += c;
    }

    return result;
}

// 查找所有战斗快照文件
std::vector<fs::path> find_generator_files(const fs::path& search_dir) {
    std::vector<fs::path> files;
    std::error_code ec;

    for (const auto& entry : fs::recursive_directory_iterator(search_dir, ec)) {
        if (ec) {
            ec.clear();
            continue;
        }

        if (entry.is_regular_file(ec)) {
            std::string filename = entry.path().filename().string();
            if (filename.find("deserialized.txt") != std::string::npos) {
                files.push_back(entry.path());
            }
        }
    }

    return files;
}

// 比较两个文件时间是否相同
bool file_times_equal(const fs::file_time_type& t1, const fs::file_time_type& t2) {
    auto diff = t1 - t2;
    return diff.count() == 0;
}

// 查找UID对应的坐标 - 改进版本
std::vector<float> find_position_for_uid(const std::string& content, uint32_t uid) {
    std::vector<float> position;

    // 尝试多种UID模式
    std::vector<std::string> uid_patterns = {
        "'" + std::to_string(uid) + "':",   // 模式1: '1000010':
        "\"" + std::to_string(uid) + "\":", // 模式2: "1000010":
        std::to_string(uid) + ":",          // 模式3: 1000010:
        "'" + std::to_string(uid) + "'",    // 模式4: '1000010'
        "\"" + std::to_string(uid) + "\"",  // 模式5: "1000010"
    };

    for (const auto& pattern : uid_patterns) {
        size_t uid_pos = content.find(pattern);
        if (uid_pos != std::string::npos) {
            // 在UID后查找"pos"关键字 - 扩大搜索范围
            size_t search_end = std::min(uid_pos + 500, content.size());
            size_t pos_key = content.find("\"pos\":", uid_pos);

            if (pos_key == std::string::npos) {
                // 尝试不带引号的pos
                pos_key = content.find("pos:", uid_pos);
            }

            if (pos_key != std::string::npos && pos_key < search_end) {
                // 查找坐标数组的开始和结束
                size_t array_start = content.find('[', pos_key);
                if (array_start == std::string::npos) continue;

                size_t array_end = content.find(']', array_start);
                if (array_end == std::string::npos) continue;

                // 提取坐标数组字符串
                std::string array_str = content.substr(array_start + 1, array_end - array_start - 1);

                // 解析坐标数组
                size_t num_start = 0;
                size_t num_end = 0;
                int coord_count = 0;

                while (coord_count < 3 && num_end != std::string::npos) {
                    num_end = array_str.find(',', num_start);
                    std::string num_str = (num_end == std::string::npos) ?
                        array_str.substr(num_start) :
                        array_str.substr(num_start, num_end - num_start);

                    // 移除可能的空格
                    num_str.erase(0, num_str.find_first_not_of(" "));
                    num_str.erase(num_str.find_last_not_of(" ") + 1);

                    // 安全解析浮点数
                    char* end_ptr = nullptr;
                    float coord = std::strtof(num_str.c_str(), &end_ptr);

                    // 检查转换是否成功
                    if (end_ptr != num_str.c_str() && *end_ptr == '\0') {
                        position.push_back(coord);
                        coord_count++;
                    }

                    num_start = (num_end == std::string::npos) ? num_end : num_end + 1;
                }

                // 如果找到有效坐标，直接返回
                if (!position.empty()) return position;
            }
        }
    }

    // 确保总是返回3个值（如果没有找到有效坐标，返回空向量）
    return {};
}

// 提取所有UID（不使用异常）
std::vector<uint32_t> extract_all_uids(const std::string& content) {
    std::vector<uint32_t> uids;
    size_t pos = 0;

    // 查找所有类似UID的数字序列
    while (pos < content.size()) {
        // 查找数字序列
        if (isdigit(content[pos])) {
            size_t start = pos;
            while (pos < content.size() && isdigit(content[pos])) {
                pos++;
            }

            // 检查是否可能是UID（6-7位数字）
            size_t len = pos - start;
            if (len >= 6 && len <= 7) {
                // 使用strtoul安全转换
                std::string num_str = content.substr(start, len);
                char* end_ptr;
                unsigned long uid_val = std::strtoul(num_str.c_str(), &end_ptr, 10);
                // 检查转换是否成功：转换必须消耗整个字符串，并且值在范围内
                if (end_ptr == num_str.c_str() + len) {
                    // UID范围检查
                    if (uid_val >= 1000000 && uid_val <= 1005000) {
                        uids.push_back(static_cast<uint32_t>(uid_val));
                    }
                }
            }
        }
        else {
            pos++;
        }
    }

    // 去重
    std::sort(uids.begin(), uids.end());
    uids.erase(std::unique(uids.begin(), uids.end()), uids.end());

    return uids;
}

// 解析文件内容
void parse_generator_file(GeneratorState& state, const fs::path& file_path) {
    // 获取文件最后修改时间
    auto last_write_time = fs::last_write_time(file_path);

    // 检查文件是否已修改
    std::string file_str = file_path.string();
    auto it = state.last_modified.find(file_str);
    if (it != state.last_modified.end() && file_times_equal(it->second, last_write_time)) {
        return; // 文件未修改，跳过
    }

    // 更新最后修改时间
    state.last_modified[file_str] = last_write_time;

    // 读取文件内容
    std::ifstream file(file_path);
    if (!file.is_open()) return;

    file.seekg(0, std::ios::end);
    size_t size = file.tellg();
    if (size == 0) {
        file.close();
        return;
    }

    file.seekg(0, std::ios::beg);
    std::string content(size, ' ');
    file.read(&content[0], size);
    file.close();

    // 预处理内容
    std::string json_str = preprocess_generator_content(content);

    // 第一步：提取所有UID及其坐标
    std::vector<uint32_t> all_uids = extract_all_uids(json_str);
    for (uint32_t uid : all_uids) {
        std::vector<float> position = find_position_for_uid(json_str, uid);
        if (!position.empty()) {
            state.uid_positions[uid] = position;
        }
    }

    // 第二步：解析发电机数据
    size_t parse_pos = 0;
    while ((parse_pos = json_str.find("\"is_generator\": true", parse_pos)) != std::string::npos) {
        size_t search_start = (parse_pos > 100) ? parse_pos - 100 : 0;
        std::string region = json_str.substr(search_start, parse_pos - search_start);

        uint32_t uid = 0;
        int process = -1;

        // 查找uid
        size_t uid_pos = region.find("\"uid\":");
        if (uid_pos != std::string::npos) {
            size_t num_start = uid_pos + 6;
            while (num_start < region.size() &&
                (region[num_start] == ' ' || region[num_start] == ':')) {
                num_start++;
            }

            if (num_start < region.size() && isdigit(region[num_start])) {
                uint32_t value = 0;
                while (num_start < region.size() && isdigit(region[num_start])) {
                    value = value * 10 + (region[num_start] - '0');
                    num_start++;
                }
                uid = value;
            }
        }

        // 查找cur_process
        size_t proc_pos = region.find("\"cur_process\":");
        if (proc_pos != std::string::npos) {
            size_t num_start = proc_pos + 14;
            while (num_start < region.size() &&
                (region[num_start] == ' ' || region[num_start] == ':')) {
                num_start++;
            }

            if (num_start < region.size() && isdigit(region[num_start])) {
                int value = 0;
                while (num_start < region.size() && isdigit(region[num_start])) {
                    value = value * 10 + (region[num_start] - '0');
                    num_start++;
                }
                process = value;
            }
        }

        // 添加记录（如果有效）
        if (uid >= 1000000 && uid <= 1005000 && process >= 0 && process <= 100) {
            // 查找坐标 - 首先尝试从uid_positions映射中获取
            std::vector<float> position;
            auto pos_it = state.uid_positions.find(uid);
            if (pos_it != state.uid_positions.end()) {
                position = pos_it->second;
            }

            // 如果在映射中没找到，尝试直接搜索
            if (position.empty()) {
                position = find_position_for_uid(json_str, uid);
            }

            // 创建记录
            GeneratorRecord new_record = {
                uid,
                process,
                position
            };

            // 检查是否已有该UID的记录
            auto it = state.records_map.find(uid);
            if (it == state.records_map.end()) {
                // 新UID，添加记录
                state.records_map[uid] = new_record;
            }
            else {
                // 已有记录，只保留进度最大的
                if (process > it->second.process) {
                    state.records_map[uid] = new_record;
                }
            }
        }

        parse_pos++; // 移动到下一个位置
    }
}

void show_unified_generator_viewer() {
    static const fs::path base_dir = "/storage/emulated/0/Android/data/com.netease.dwrg/files/netease/dwrg.common/Documents/video/";

    // 每2秒检查一次
    auto now = std::chrono::steady_clock::now();
    if (now - g_GeneratorState.last_check > std::chrono::seconds(2)) {
        g_GeneratorState.last_check = now;

        // 清空显示列表，从map重新生成
        g_GeneratorState.records_display.clear();
        for (const auto& pair : g_GeneratorState.records_map) {
            g_GeneratorState.records_display.push_back(pair.second);
        }

        // 按UID排序显示列表
        std::sort(g_GeneratorState.records_display.begin(), g_GeneratorState.records_display.end(),
            [](const GeneratorRecord& a, const GeneratorRecord& b) {
                return a.uid < b.uid;
            });

        auto files = find_generator_files(base_dir);
        if (!files.empty()) {
            // 清除旧的位置映射
            g_GeneratorState.uid_positions.clear();

            for (const auto& file : files) {
                parse_generator_file(g_GeneratorState, file);
            }
            g_GeneratorState.status = "已加载 " + std::to_string(g_GeneratorState.records_display.size()) + " 条记录";
        }
        else {
            g_GeneratorState.status = "未找到数据文件";
        }
    }

    //// 创建窗口
    //ImGui::Begin("发电机状态查看器");

    //// 显示状态
    //ImGui::TextColored(ImVec4(1, 1, 0, 1), "%s", g_GeneratorState.status.c_str());
    //ImGui::Separator();

    //// 显示表格
    //if (g_GeneratorState.records_display.empty()) {
    //    ImGui::Text("没有发电机数据");
    //}
    //else {
    //    if (ImGui::BeginTable("发电机状态", 3,
    //        ImGuiTableFlags_Borders |
    //        ImGuiTableFlags_RowBg |
    //        ImGuiTableFlags_ScrollY |
    //        ImGuiTableFlags_SizingFixedFit)) {

    //        ImGui::TableSetupColumn("UID", ImGuiTableColumnFlags_WidthFixed, 80);
    //        ImGui::TableSetupColumn("进度", ImGuiTableColumnFlags_WidthFixed, 60);
    //        ImGui::TableSetupColumn("坐标", ImGuiTableColumnFlags_WidthFixed, 200);
    //        ImGui::TableHeadersRow();

    //        for (const auto& rec : g_GeneratorState.records_display) {
    //            ImGui::TableNextRow();

    //            // UID
    //            ImGui::TableSetColumnIndex(0);
    //            ImGui::Text("%u", rec.uid);

    //            // 进度
    //            ImGui::TableSetColumnIndex(1);
    //            ImGui::Text("%d%%", rec.process);

    //            // 坐标
    //            ImGui::TableSetColumnIndex(2);
    //            if (!rec.position.empty() && rec.position.size() >= 3) {
    //                ImGui::Text("[%.2f, %.2f, %.2f]",
    //                    rec.position[0],  // X
    //                    rec.position[1],  // Z
    //                    rec.position[2]); // Y
    //            }
    //            else {
    //                ImGui::Text("无坐标数据");
    //            }
    //        }

    //        ImGui::EndTable();
    //    }
    //}

    //ImGui::End();
}



int 显示监管距离;
std::string yujingjuli;
bool 灵魂 = true;
bool 被打预警 = false;
bool showWarning = false;
float 预警距离 = 4.0f;
float  godvalue = 1.7;
int 共享 = false;
static int 录屏时长 = 20; // 默认时间为10秒
static std::atomic<bool> isRecording(false); // 全局变量
static std::atomic<int> recordingTimeElapsed(0); // 录制经过的时间
bool 悬浮球 = false;
bool 悬浮窗 = true;
static bool 窗口状态 = false; //窗口状态
ImVec2 Pos;
int 音量键 = 0;
void* handle;// 动态库方案
bool active = false;
bool 捏镜 = false;
float 武器位置X = 0.0f;
float 武器位置Y = 0.0f;
float 武器位置Z = 0.0f;
float 电机位置X = 0.0f;
float 电机位置Y = 0.0f;
float 电机位置Z = 0.0f;
void StartRecordingThread(int duration) {
    // 使用 system() 函数执行命令时需要注意安全性
    std::string command = "screenrecord --time-limit " + std::to_string(duration) + " /sdcard/Riley录制.mp4";
   

    // 更新录制时间
    for (int i = 0; i < duration && isRecording.load(); ++i) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        recordingTimeElapsed.fetch_add(1);
    }

    isRecording.store(false);
}

// 计算敌人朝向的描述性文本
std::string CalculateEnemyDirection(float enemyVectorX, float enemyVectorY) {
    // 定义方向向量和对应的方向名称
    std::vector<std::pair<std::string, std::pair<float, float>>> directions = {
        {"北", {0.0f, 1.0f}},    // 北
        {"东北", {0.7071f, 0.7071f}},   // 东北
        {"东", {1.0f, 0.0f}},    // 东
        {"东南", {0.7071f, -0.7071f}},  // 东南
        {"南", {0.0f, -1.0f}},   // 南
        {"西南", {-0.7071f, -0.7071f}}, // 西南
        {"西", {-1.0f, 0.0f}},   // 西
        {"西北", {-0.7071f, 0.7071f}}  // 西北
    };

    // 计算敌人向量与各个基本方向向量的点积
    float maxDotProduct = -1.0f;
    std::string closestDirection;
    for (const auto& dir : directions) {
        float dotProduct = enemyVectorX * dir.second.first + enemyVectorY * dir.second.second;
        if (dotProduct > maxDotProduct) {
            maxDotProduct = dotProduct;
            closestDirection = dir.first;
        }
    }

    return closestDirection;
}

int GetEventCount3()
{
    DIR* dir = opendir("/dev/input/");
    dirent* ptr = NULL;
    int count = 0;
    while ((ptr = readdir(dir)) != NULL)
    {
        if (strstr(ptr->d_name, "event"))
            count++;
    }
    return count ? count : -1;
}
bool kang = true;



int 音量()
{
    int EventCount = GetEventCount3();
    if (EventCount < 0)
    {
        printf("未找到输入设备\n");
        return -1;
    }

    int* fdArray = (int*)malloc(EventCount * sizeof(int));

    for (int i = 0; i < EventCount; i++)
    {
        char temp[128];
        sprintf(temp, "/dev/input/event%d", i);
        fdArray[i] = open(temp, O_RDWR | O_NONBLOCK);
    }

    input_event ev;
    int count = 0; // 记录按下音量键的次数

    while (1)
    {
        for (int i = 0; i < EventCount; i++)
        {
            memset(&ev, 0, sizeof(ev));
            read(fdArray[i], &ev, sizeof(ev));
            if (ev.type == EV_KEY && ev.code == KEY_VOLUMEUP && ev.value == 1 && kang == true)
            {
                if (音量键 == 0) {
                    悬浮窗 = true;
                    窗口状态 = true;
                }
                else {
                    捏镜 = true;
                }

            }
            else if (ev.type == EV_KEY && ev.code == KEY_VOLUMEDOWN && ev.value == 1 && kang == true)
            {
                if (音量键 == 0) {
                    悬浮窗 = false; 窗口状态 = true;
                }
                else {
                    捏镜 = false;
                }
            }
        }

        usleep(3000);
    }

    return 0;
}



bool permeate_record = false;
bool permeate_record_ini = false;
struct Last_ImRect LastCoordinate = {0, 0, 0, 0};


std::unique_ptr<AndroidImgui> graphics;
ANativeWindow *window ; 
android::ANativeWindowCreator::DisplayInfo displayInfo;// 屏幕信息
ImGuiWindow *g_window ;// 窗口信息
int abs_ScreenX = 0, abs_ScreenY = 0;// 绝对屏幕X _ Y
int native_window_screen_x = 0, native_window_screen_y = 0;

TextureInfo Aekun_image{};

ImFont* zh_font = NULL;
ImFont* icon_font_0 = NULL;
ImFont* icon_font_1 = NULL;
ImFont* icon_font_2 = NULL;

std::vector<std::string> outputBuffer;

void UpdateOutputBuffer(const char* format, ...) {
    va_list args;
    va_start(args, format);
    char buffer[256];
    vsprintf(buffer, format, args);
    va_end(args);
    outputBuffer.push_back(buffer);
}

void ClearOutputBuffer() {
    outputBuffer.clear();
}


bool M_Android_LoadFont(float SizePixels) {
    ImGuiIO &io = ImGui::GetIO();
    
    //ImFontConfig config; //oppo字体部分
    //config.FontDataOwnedByAtlas = false;
    //config.SizePixels = SizePixels;
    //config.OversampleH = 1;
    //::zh_font = io.Fonts->AddFontFromMemoryTTF((void *)OPPOSans_H, OPPOSans_H_size, 0.0f, &config, io.Fonts->GetGlyphRangesChineseFull());    
    ////io.Fonts->AddFontDefault(&config);

	static const ImWchar icons_ranges[] = {ICON_MIN_FA, ICON_MAX_FA, 0};
    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 3.0;
    icons_config.OversampleV = 3.0;		
    icons_config.SizePixels = SizePixels;
    //icons_config.GlyphOffset.y += 7.0f; // 通过 GlyphOffset 调整单个字形偏移量，向下偏移 size 像素
	::icon_font_0 = io.Fonts->AddFontFromMemoryCompressedTTF((const void *)&font_awesome_brands_compressed_data, sizeof(font_awesome_brands_compressed_data), 0.0f, &icons_config, icons_ranges);
	::icon_font_1 = io.Fonts->AddFontFromMemoryCompressedTTF((const void *)&font_awesome_regular_compressed_data, sizeof(font_awesome_regular_compressed_data), 0.0f, &icons_config, icons_ranges);
	::icon_font_2 = io.Fonts->AddFontFromMemoryCompressedTTF((const void *)&font_awesome_solid_compressed_data, sizeof(font_awesome_solid_compressed_data), 0.0f, &icons_config, icons_ranges);

    io.Fonts->AddFontDefault();
    return zh_font != nullptr;
}
void init_My_drawdata() {
    ImGui::StyleColorsLight(); //白色
    ImGui::My_Android_LoadSystemFont(25.0f); //(加载系统字体 安卓15完美适配)
    M_Android_LoadFont(40.0f); //加载字体(还有图标)
    ImGui::GetStyle().ScaleAllSizes(3.25f);
    ::Aekun_image = graphics->LoadTextureFromMemory((void *)picture_ZhenAiKun_PNG_H, sizeof(picture_ZhenAiKun_PNG_H));
}


void screen_config() {
    ::displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
}

void drawBegin() {
    if (::permeate_record_ini) {
        LastCoordinate.Pos_x = ::g_window->Pos.x;
        LastCoordinate.Pos_y = ::g_window->Pos.y;
        LastCoordinate.Size_x = ::g_window->Size.x;
        LastCoordinate.Size_y = ::g_window->Size.y;

        graphics->Shutdown();
        android::ANativeWindowCreator::Destroy(::window);
        ::window = android::ANativeWindowCreator::Create("test_sysGui", native_window_screen_x, native_window_screen_y, permeate_record);
        graphics->Init_Render(::window, native_window_screen_x, native_window_screen_y);
        ::init_My_drawdata(); //初始化绘制数据
    } 


    static uint32_t orientation = -1;
    screen_config();
    if (orientation != displayInfo.orientation) {
        orientation = displayInfo.orientation;
        Touch::setOrientation(displayInfo.orientation);
        if (g_window != NULL) {
            g_window->Pos.x = 100;
            g_window->Pos.y = 125;        
        }        
        //cout << " width:" << displayInfo.width << " height:" << displayInfo.height << " orientation:" << displayInfo.orientation << endl;
    }
}
std::chrono::steady_clock::time_point lastTriggerTime = std::chrono::steady_clock::now();
// 冷却时间（1秒）
bool 显示白色人物;
bool 方框样式 = true;
float bianhaodaxiao = 30.0f;
const int COOLDOWN_TIME_MS = 2000;
bool zhuangtai = true;
extern std::string uid;








extern  bool 触摸开启;
bool isFirstClick = true;  // 用于跟踪按钮的点击状态
bool 必看 = false;
bool 参考数据 = false;
float touchPointX3 = 200.0f;  // 圆的中心 x 坐标
float touchPointY3 = 200.0f;  // 圆的中心 y 坐标
bool 蝴蝶 = true;
bool 触摸3 = false;
bool isLongPress;
bool 转圈判断 = false;// 控制新触摸功能是否开启
bool 信息 = false;
float circleRadius = 100.0f;  // 圆的半径
float currentAngle = 0.0f;    // 当前触摸点绕圆的角度
int zeroDistanceCount = 0; // 记录阵营2中距离为0m的角色数量
// 全局变量，用于存储字体大小
// 声明外部全局变量
bool buttonPressed = false;
double startTime = 0.0;
int 伞距离 = 0;
int 人数 = 0;
float 转圈速度 = 3.5;
const int maxNumber = 200;
float 判断距离 = 3.0f;
float incrementInterval = 0.054f;
float huizhiziti = 30.0f;
float sanjuli = 100.0f;
float pathLengthMultiplier = 1.0f; // 路径长度乘数，用于动态调整滑动幅度
bool 鹿头辅助线 = false;
float chuangkou = 1.0f;
float chuangkou2 = 1.0f;
bool 绘制 = true;
bool 鹿头陷阱;
bool 少绘制;
 int zuida = 20;//板子
int zuida2 = 50;//电机
int zuida3 = 30;//狂欢之椅
int zuida4 = 10;//道具箱
int zuida5 = 15;//圣诞道具箱
int zuida6 = 40;//摄影机
int zuida7 = 1;//柜子
static bool 编号 = false;//编号
bool 平板椅 = false;
bool 平板机 = false;
bool 狗眼 = false;
bool 平板 = false;
struct ObjectInfo {
    int index1;  // 修改为 index1
    bool selected;
};
float sanx = 1800.7;
float sany = 358.6;
static float stopDuration1 = 1.43f; // 停止时间（秒）
static float elapsedDuration1 = 0.0f; // 已经过的时间（秒）
// 交叉点的位置
float crossPointX = 400.0f;
float crossPointY = 300.0f;
bool 地图窗口 = false;
// 交叉线的开合角度（以度为单位）
float openAngle = 45.0f;

// 交叉线的旋转角度（以度为单位）
float rotateAngle = 0.0f;

// 线的长度
float lineLength = 200.0f;
ImVec2 windowPos = ImVec2(sanx, sany); // 窗口位置
std::unordered_map<uintptr_t, int> objectIdMap;
std::unordered_map<uintptr_t, ObjectInfo> objectIdMapWithSelection;
int 道具箱数量 = 0;//
int 电机数量 = 0;//
//bool jiajingzi = true;//假镜子
bool furen = true;//绘制红夫人（监管）
bool 模仿者 = false;
bool dianji = true;
bool luoRileyg = true;
bool 伪镜子 = false;
bool 秒震慑 = true;
bool 延迟震慑 = false;
bool 贴脸震慑 = true;
bool 演戏震慑 = false;
bool 贴脸震慑1 = true;
bool 演戏震慑1 = false;
// 定义震慑延迟变量
float 震慑延迟 = 0.25f;
// 记录满足条件的时间
double 满足条件时间 = 0.0;
// 标记是否满足条件
bool 满足条件1 = false;
// 定义震慑延迟变量
float 震慑延迟1 = 0.15f;
// 记录满足条件的时间
double 满足条件时间1 = 0.0;
// 标记是否满足条件
bool 满足条件 = false;
static float  countdown_timer = 63.0f;
bool 盖板快捷 = false;
bool 快捷切换状态 = false;
bool jishi = false;
bool 快捷 = false;
bool 关绘制 = false;
std::string 过滤类名, 类名;
char gwd1[25];
char gwd2[25];
float 距离比例 = 11.886;
float 红夫人X, 红夫人Y, 红夫人Z, 假镜子X, 假镜子Y, 假镜子Z, 镜子X, 镜子Y, 镜子Z;
float 红夫人镜像X, 红夫人镜像Y, 红夫人镜像Z;
float dx, dy, ux, uy, 长度X, 长度Y, 宽度X, 宽度Y;
float 角度值;
int loops = 7;
float 飞轮延迟 = 10;
bool spiralButtonPressed = false;
std::chrono::steady_clock::time_point SpiralPressStart;

bool 捏镜快捷 = false;
bool spiral = false; // 螺旋开关
float startX = 0.0f; // 起点x坐标
float startY = 0.0f; // 起点y坐标
float endX = 0.0f;   // 终点x坐标
float endY = 0.0f;   // 终点y坐标
float slideSpeed = 0.1f; // 滑动速度（单位：米/秒）
bool touchDown = false; // 触摸是否按下
bool 螺旋窗口 = false;

float fakeMirrorLastX = 0.0f;
float fakeMirrorLastY = 0.0f;
std::chrono::steady_clock::time_point lastUpdate = std::chrono::steady_clock::now();
typedef struct {
    uintptr_t obj;
    uintptr_t objcoor;
    int 阵营;
    char str[256];//翻译名
    char 类名[256];//类名
    float X; // 添加 X 字段
    float Y; // 添加 Y 字段
    float 角度值;
    int 距离;
    std::string 方向;
}DataStruct;
DataStruct data[1000];
//自动盖板
float 板子x1, 板子y1, 板子x2, 板子y2, 板子x3, 板子y3, 板子x4, 板子y4;//板子四个角
bool 自身在板子范围 = false;
bool 监管者在板子范围 = false;
float 盖板触发范围 = 25, 板子范围X = 13, 板子范围Y = 18;
// 获取伪镜子的坐标
float fakeMirrorX = 0.0f;
float fakeMirrorY = 0.0f;
float fakeMirrorZ = 0.0f;
float 红夫人镜像X1 = 0.0f;
float 红夫人镜像Y1 = 0.0f;
std::atomic<bool> 捏了(false);
uintptr_t 盖板监管者, 盖板板子;
float 监管者X, 监管者Y, 监管者Z;
float 板子X, 板子Y, 板子Z;
DataStruct 板子[300], 监管者[100];
int CUSTOM_COUNTDOWN_TIME = 63;
int woodcount = 0;
int bosscount = 0;
bool 触摸位置;
bool 监管距离 = false;


float subWindowPosX1 = 100.0f;
float subWindowPosY1 = 100.0f;
float touchPointX2 = 0.0f;
float touchPointY2 = 0.0f;
bool mirrorFound = false;
extern bool 加载触摸栏;
bool 触摸2 = false;
bool 平a震慑 = false;
bool 拉锯震慑;
bool buttonPressed2 = false;
double startTime2 = 0.0;
bool 宿伞;
bool 镜子伞 = true;
bool niexi;
float 矩阵视野距离;
float 孽蜥触摸点X = displayInfo.width * 0.50;  // 初始触摸点X坐标
float 孽蜥触摸点Y = displayInfo.height * 0.857;  // 初始触摸点Y坐标
float 自动技能X = displayInfo.width * 0.50;  // 初始触摸点X坐标
float 自动技能Y= displayInfo.height * 0.857;  // 初始触摸点Y坐标
bool 孽蜥坠机 = false;
bool 孽蜥开关;
float 孽蜥距离, 孽蜥按住距离;
bool 实体 = true;
bool 视角 = false;
std::string filename = "Riley配置文件.txt"; // 文件名改为 "Riley配置文件.txt"
ImColor textColor;
/*定义*/
bool DrawIo[50];

float 触摸点X = displayInfo.width * 0.89, 触摸点Y = displayInfo.height * 0.163;
float touchPointX4 = 200.0f, touchPointY4 = 200.0f;

std::unordered_map<std::string, float> 监管者距离 = {
    {"红蝶", 3.06f + 0.2f},
    {"约瑟夫", 3.06f + 0.2f},
    {"雕刻家", 3.06f + 0.2f},
    {"小提琴家", 3.11f + 0.2f},
    {"爱哭鬼", 3.12f + 0.2f},
    {"26号守卫", 3.15f + 0.2f},
    {"蜘蛛", 3.15f + 0.2f},
    {"厂长", 3.51f + 0.2f},
    {"噩梦", 3.49f + 0.2f},
    {"渔女", 3.49f + 0.2f},
    {"宿伞之魂", 3.37f + 0.2f},
    {"小丑", 3.38f + 0.2f},
    {"杰克", 3.46f + 0.2f},
    {"守墓人", 3.46f + 0.2f},
    {"破轮", 3.6f + 0.2f},
    {"蜡像师", 3.6f + 0.2f},
    {"邮差", 3.6f + 0.2f},
    {"舞女", 3.6f + 0.2f},
    {"博士", 3.6f + 0.2f},
    {"牛仔", 3.6f + 0.2f},
    {"鹿头", 3.71f + 0.2f},
    {"画家", 3.71f + 0.2f},
    {"孽蜥", 3.8f + 0.2f},
    {"昆虫学者", 4.03f + 0.2f},
    {"摄影师", 4.05f + 0.2f},
    {"黑白无常", 5.49f + 0.2f},
    {"黄衣之主", 5.57f + 0.2f}
};
// 设备数据结构（别名为lddata）
typedef struct {
    char name[32];
    double x;       // X 坐标
    double y;       // Y 坐标
    int room_id;       // 阵营: 0-求生者, 1-监管者
} DEV;

// 全局变量
DEV lddata = { 
    "me", 0.0, 0.0,1001
};

volatile int running = 1; // 控制程序运行状态
const char* uploadUrl = "http://154.37.214.183:5000/api/characters"; // 上传的 URL 地址


void uploadData() {
    char cmd[1024] = { 0 };
    char jsonBuffer[512] = { 0 };

    // 构造 JSON 数据（只包含name, x, y, camp四个字段）
    sprintf(jsonBuffer, "[{\"name\":\"%s\",\"x\":%.2f,\"y\":%.2f,\"room_id\":%d}]",
        lddata.name, lddata.x, lddata.y,lddata.room_id);

    // 构造 curl 命令
    sprintf(cmd, "curl -X POST %s -H \"Content-Type: application/json\" -d '%s'",
        uploadUrl, jsonBuffer);

    // 执行系统命令上传数据
    system(cmd);

    // 输出上传时间及数据
    printf("上传时间: %ld, 数据: %s\n", time(NULL), jsonBuffer);
}

void* uploadLoop(void* arg) {
    while (running) {
      
        uploadData(); // 上传数据
        usleep(200000); // 每 200 毫秒上传一次
    }
    return NULL;
}


void calculatePositionAndDirection(float z_x, float z_y, float x, float y, std::string& direction, float& angle) {
    // 计算相对于原点 Z 的坐标差
    float dx = x - z_x;
    float dy = y - z_y;

    // 计算相对于原点 Z 的向量与正北方向的夹角（顺时针）
    if (dx == 0) {
        if (dy > 0) {
            angle = 0.0f;
        }
        else {
            angle = 180.0f;
        }
    }
    else {
        angle = atan2f(dx, dy) * (180.0f / M_PI);
        if (angle < 0) {
            angle += 360.0f;
        }
    }

    // 根据角度确定方向描述
    if (angle >= 337.5f || angle < 22.5f) {
        direction = "正北";
    }
    else if (angle >= 22.5f && angle < 67.5f) {
        direction = "北偏东";
    }
    else if (angle >= 67.5f && angle < 112.5f) {
        direction = "正东";
    }
    else if (angle >= 112.5f && angle < 157.5f) {
        direction = "南偏东";
    }
    else if (angle >= 157.5f && angle < 202.5f) {
        direction = "正南";
    }
    else if (angle >= 202.5f && angle < 247.5f) {
        direction = "南偏西";
    }
    else if (angle >= 247.5f && angle < 292.5f) {
        direction = "正西";
    }
    else if (angle >= 292.5f && angle < 337.5f) {
        direction = "北偏西";
    }
    else {
        direction = "未知方向";
    }
}


void 绘制字体描边(float size, int x, int y, ImVec4 color, const char* str) {
    ImGui::GetBackgroundDrawList()->AddText(NULL, size, ImVec2(x + 1.0, y), ImGui::ColorConvertFloat4ToU32(ImVec4(0.0f, 0.0f, 0.0f, 1.0f)), str);
    ImGui::GetBackgroundDrawList()->AddText(NULL, size, ImVec2(x - 0.1, y), ImGui::ColorConvertFloat4ToU32(ImVec4(0.0f, 0.0f, 0.0f, 1.0f)), str);
    ImGui::GetBackgroundDrawList()->AddText(NULL, size, ImVec2(x, y + 1.0), ImGui::ColorConvertFloat4ToU32(ImVec4(0.0f, 0.0f, 0.0f, 1.0f)), str);
    ImGui::GetBackgroundDrawList()->AddText(NULL, size, ImVec2(x, y - 1.0), ImGui::ColorConvertFloat4ToU32(ImVec4(0.0f, 0.0f, 0.0f, 1.0f)), str);
    ImGui::GetBackgroundDrawList()->AddText(NULL, size, ImVec2(x, y), ImGui::ColorConvertFloat4ToU32(color), str);
}
struct My_Vector3A//字面意思
{
    float X;
    float Y;
    float Z;

    My_Vector3A()
    {
        this->X = 0;
        this->Y = 0;
        this->Z = 0;
    }

    My_Vector3A(float x, float y, float z)
    {
        this->X = x;
        this->Y = y;
        this->Z = z;
    }

};
float xs_prime_mirror, ys_prime_mirror;
float xs_final, ys_final;
void calculate_mirror_reflection(float x1, float y1, float x2, float y2, float xs, float ys, float* xs_prime, float* ys_prime) {
    float xm = (x1 + x2) / 2.0;
    float ym = (y1 + y2) / 2.0;//镜面原理

    *xs_prime = 2.0 * xm - xs;
    *ys_prime = 2.0 * ym - ys;
}

void calculate_line_reflection(float x1, float y1, float x2, float y2, float xs, float ys, float* xs_prime, float* ys_prime) {
    float A = y2 - y1;
    float B = x1 - x2;
    float C = x2 * y1 - x1 * y2;

    float D = A * xs + B * ys + C;
    float denom = A * A + B * B;

    *xs_prime = xs - 2.0 * A * D / denom;
    *ys_prime = ys - 2.0 * B * D / denom;
}


uintptr_t libbase;//uintptr_t无符号整数类型，在进行内存操作（如读取或写入内存）时，libbase 可以作为偏移的基准点
uintptr_t Arrayaddr, Count, Matrix;
uintptr_t 对象, 对象阵营, 自身, 自身阵营, namezfcz, namezfc, 自身坐标, 对象1;
uintptr_t 红夫人, 红夫人镜像, 镜子, 假镜子;
int 数量, zfcz, zfc;
float 过滤矩阵[17];
float matrix[16];
float angle;
//static bool show_draw_jingzi = true;//假镜子
float subWindowPosX = 100.0f;
float subWindowPosY = 100.0f;
static bool show_draw_Rect = true;//方框
static bool show_draw_Line = false;//射线
static bool show_draw_Camera = true;//相机
static bool show_draw_Door = true;//门
static bool show_draw_Box = true;//盒子
static bool show_draw_Name = true;//名字
static bool show_draw_Distance = true;//距离
static bool show_draw_Cellar = true;//地窖
static bool show_draw_Chair = true;//椅子
static bool show_draw_Prop = true;//道具
static bool show_draw_prophet = true;//预知监管者
static bool redqueenmod = true;//红夫人模式
static bool show_draw_sender = true;//密码机进度
static bool show_draw_Role = false;//角色

static bool show_draw_ClassName = false;//类名
static bool Debugging = false;//调试
static bool mirror = false;//镜子状态
static bool show_draw_touch = false;//盖板
static bool show_draw_BANZI = true;//板子
static bool show_draw_GUIZI = true;//柜子
static bool show_draw_DIANJI = true;//电机
static bool show_draw_XINSHOU = true;//新手
static bool show_demo_window = false;
static bool show_another_window = false;

void SaveConfig(const std::string& filename) {
    std::ofstream configFile(filename);
    if (configFile.is_open()) {
        // 保存配置项

        configFile << "触摸位置=" << (触摸位置 ? "true" : "false") << "\n";
        configFile << "必看=" << (必看 ? "true" : "false") << "\n";
        configFile << "蝴蝶=" << (蝴蝶 ? "true" : "false") << "\n";
        // 保存各种设置
        configFile << "四角边框=" << (方框样式 ? "true" : "false") << "\n";
        configFile << "快捷=" << (快捷 ? "true" : "false") << "\n";
        configFile << "计时=" << (jishi ? "true" : "false") << "\n";
        configFile << "关绘制=" << (关绘制 ? "true" : "false") << "\n";
        configFile << "编号=" << (编号 ? "true" : "false") << "\n";
        configFile << "宿伞=" << (宿伞 ? "true" : "false") << "\n";
        configFile << "盖板快捷=" << (盖板快捷 ? "true" : "false") << "\n";
        configFile << "实体=" << (实体 ? "true" : "false") << "\n";
        configFile << "视角=" << (视角 ? "true" : "false") << "\n";
        configFile << "监管距离=" << (监管距离 ? "true" : "false") << "\n";
        configFile << "鹿头辅助线=" << (鹿头辅助线 ? "true" : "false") << "\n";
        configFile << "快捷切换状态=" << (快捷切换状态 ? "true" : "false") << "\n";
        configFile << "拉锯震慑=" << (拉锯震慑 ? "true" : "false") << "\n";
        configFile << "平a震慑=" << (平a震慑 ? "true" : "false") << "\n";
        configFile << "转圈判断=" << (转圈判断 ? "true" : "false") << "\n";
        configFile << "孽蜥坠机=" << (孽蜥坠机 ? "true" : "false") << "\n";
        configFile << "孽蜥开关=" << (孽蜥开关 ? "true" : "false") << "\n";

        // 保存传伞设置
        configFile << "子窗口X位置=" << subWindowPosX << "\n";
        configFile << "子窗口Y位置=" << subWindowPosY << "\n";
        configFile << "伞速度=" << incrementInterval << "\n";

        // 保存鹿头辅助线设置
        configFile << "交叉点X=" << crossPointX << "\n";
        configFile << "交叉点Y=" << crossPointY << "\n";
        configFile << "线长=" << lineLength << "\n";
        configFile << "开合角度=" << openAngle << "\n";
        configFile << "旋转角度=" << rotateAngle << "\n";

        // 保存拉锯震慑设置
        configFile << "贴脸震慑=" << (贴脸震慑 ? "true" : "false") << "\n";
        configFile << "演戏震慑=" << (演戏震慑 ? "true" : "false") << "\n";
        configFile << "震慑延迟=" << 震慑延迟 << "\n";
        configFile << "触摸点X2=" << touchPointX2 << "\n";
        configFile << "触摸点Y2=" << touchPointY2 << "\n";

        // 保存平a震慑设置
        configFile << "贴脸震慑1=" << (贴脸震慑1 ? "true" : "false") << "\n";
        configFile << "演戏震慑1=" << (演戏震慑1 ? "true" : "false") << "\n";
        configFile << "震慑延迟1=" << 震慑延迟1 << "\n";
        configFile << "平a触摸点X=" << touchPointX4 << "\n";
        configFile << "平a触摸点Y=" << touchPointY4 << "\n";
        // 保存转圈设置
        configFile << "圆半径=" << circleRadius << "\n";
        configFile << "转圈速度=" << 转圈速度 << "\n";
        configFile << "触摸点圆心X=" << touchPointX3 << "\n";
        configFile << "触摸点圆心Y=" << touchPointY3 << "\n";

        // 保存孽蜥坠机设置

        configFile << "判断距离=" << 判断距离 << "\n";
        configFile << "孽蜥触摸点X=" << 孽蜥触摸点X << "\n";
        configFile << "孽蜥触摸点Y=" << 孽蜥触摸点Y << "\n";

        // 保存一键绘制设置
        configFile << "绘制方框=" << (show_draw_Rect ? "true" : "false") << "\n";
        configFile << "绘制射线=" << (show_draw_Line ? "true" : "false") << "\n";
        configFile << "绘制距离=" << (show_draw_Distance ? "true" : "false") << "\n";
        configFile << "绘制大门=" << (show_draw_Door ? "true" : "false") << "\n";
        configFile << "绘制地窖=" << (show_draw_Cellar ? "true" : "false") << "\n";
        configFile << "绘制相机=" << (show_draw_Camera ? "true" : "false") << "\n";
        configFile << "绘制名字=" << (show_draw_Name ? "true" : "false") << "\n";
        configFile << "绘制道具=" << (show_draw_Box ? "true" : "false") << "\n";
        configFile << "绘制板子=" << (show_draw_BANZI ? "true" : "false") << "\n";
        configFile << "绘制电机=" << (show_draw_DIANJI ? "true" : "false") << "\n";
        configFile << "绘制椅子=" << (show_draw_Chair ? "true" : "false") << "\n";
        configFile << "绘制道具=" << (show_draw_Prop ? "true" : "false") << "\n";
        configFile << "绘制柜子=" << (show_draw_GUIZI ? "true" : "false") << "\n";
        configFile << "绘制监管预知=" << (show_draw_prophet ? "true" : "false") << "\n";
        configFile << "监管距离=" << (监管距离 ? "true" : "false") << "\n";
        configFile << "绘制监管=" << (furen ? "true" : "false") << "\n";
        configFile << "红夫人模式=" << (redqueenmod ? "true" : "false") << "\n";
        configFile << "狗眼=" << (狗眼 ? "true" : "false") << "\n";

        // 保存其他设置
        configFile << "绘制字体大小=" << huizhiziti << "\n";
        configFile << "调试模式=" << (Debugging ? "true" : "false") << "\n";
        configFile << "平板椅=" << (平板椅 ? "true" : "false") << "\n";
        configFile << "灵魂=" << (灵魂 ? "true" : "false") << "\n";
        configFile << "平板机=" << (平板机 ? "true" : "false") << "\n";
        // 保存绘制距离设置
        configFile << "箱子距离=" << zuida4 << "\n";
        configFile << "圣诞箱子距离=" << zuida5 << "\n";
        configFile << "摄影机距离=" << zuida6 << "\n";
        configFile << "板子距离=" << zuida << "\n";
        configFile << "电机距离=" << zuida2 << "\n";
        configFile << "椅子距离=" << zuida3 << "\n";
        configFile << "柜子距离=" << zuida7 << "\n";

        // 保存盖板模式设置
        configFile << "绘制盖板=" << (show_draw_touch ? "true" : "false") << "\n";

        configFile << "盖板触发范围=" << 盖板触发范围 << "\n";
        configFile << "板子范围X=" << 板子范围X << "\n";
        configFile << "板子范围Y=" << 板子范围Y << "\n";
        configFile << "触摸点X=" << 触摸点X << "\n";
        configFile << "触摸点Y=" << 触摸点Y << "\n";

        configFile.close();
    }
    else {
        printf("无法保存配置文件 %s\n", filename.c_str());
    }
}
void LoadConfig(const std::string& filename) {
    std::ifstream configFile(filename);
    if (configFile.is_open()) {
        std::string line;
        while (std::getline(configFile, line)) {
            // 解析每一行的键值对
            size_t pos = line.find("=");
            if (pos != std::string::npos) {
                std::string key = line.substr(0, pos);
                std::string value = line.substr(pos + 1);

                // 根据键值对更新配置

                if (key == "触摸位置") 触摸位置 = (value == "true");
                else if (key == "必看") 必看 = (value == "true");
                else if (key == "快捷") 快捷 = (value == "true");
                else if (key == "蝴蝶") 蝴蝶 = (value == "true");
                else if (key == "四角边框") 方框样式 = (value == "true");
                else if (key == "计时") jishi = (value == "true");
                else if (key == "关绘制") 关绘制 = (value == "true");
                else if (key == "编号") 编号 = (value == "true");
                else if (key == "宿伞") 宿伞 = (value == "true");
                else if (key == "盖板快捷") 盖板快捷 = (value == "true");
                else if (key == "实体") 实体 = (value == "true");
                else if (key == "视角") 视角 = (value == "true");
                else if (key == "监管距离") 监管距离 = (value == "true");
                else if (key == "鹿头辅助线") 鹿头辅助线 = (value == "true");
                else if (key == "快捷切换状态") 快捷切换状态 = (value == "true");
                else if (key == "拉锯震慑") 拉锯震慑 = (value == "true");
                else if (key == "平a震慑") 平a震慑 = (value == "true");
                else if (key == "转圈判断") 转圈判断 = (value == "true");
                else if (key == "孽蜥坠机") 孽蜥坠机 = (value == "true");
                else if (key == "孽蜥开关") 孽蜥开关 = (value == "true");
                else if (key == "子窗口X位置") subWindowPosX = std::stof(value);
                else if (key == "子窗口Y位置") subWindowPosY = std::stof(value);
                else if (key == "伞速度") incrementInterval = std::stof(value);
                else if (key == "交叉点X") crossPointX = std::stof(value);
                else if (key == "交叉点Y") crossPointY = std::stof(value);
                else if (key == "线长") lineLength = std::stof(value);
                else if (key == "开合角度") openAngle = std::stof(value);
                else if (key == "旋转角度") rotateAngle = std::stof(value);
                else if (key == "贴脸震慑") 贴脸震慑 = (value == "true");
                else if (key == "演戏震慑") 演戏震慑 = (value == "true");
                else if (key == "震慑延迟") 震慑延迟 = std::stof(value);
                else if (key == "触摸点X2") touchPointX2 = std::stof(value);
                else if (key == "触摸点Y2") touchPointY2 = std::stof(value);
                else if (key == "贴脸震慑1") 贴脸震慑1 = (value == "true");
                else if (key == "演戏震慑1") 演戏震慑1 = (value == "true");
                else if (key == "震慑延迟1") 震慑延迟1 = std::stof(value);
                else if (key == "平a触摸点X") touchPointX4 = std::stof(value);
                else if (key == "平a触摸点Y") touchPointY4 = std::stof(value);
                else if (key == "圆半径") circleRadius = std::stof(value);
                else if (key == "转圈速度") 转圈速度 = std::stof(value);
                else if (key == "触摸点圆心X") touchPointX3 = std::stof(value);
                else if (key == "触摸点圆心Y") touchPointY3 = std::stof(value);

                else if (key == "判断距离") 判断距离 = std::stof(value);
                else if (key == "孽蜥触摸点X") 孽蜥触摸点X = std::stof(value);
                else if (key == "孽蜥触摸点Y") 孽蜥触摸点Y = std::stof(value);
                else if (key == "绘制方框") show_draw_Rect = (value == "true");
                else if (key == "绘制射线") show_draw_Line = (value == "true");
                else if (key == "绘制距离") show_draw_Distance = (value == "true");
                else if (key == "绘制大门") show_draw_Door = (value == "true");
                else if (key == "绘制地窖") show_draw_Cellar = (value == "true");
                else if (key == "绘制相机") show_draw_Camera = (value == "true");
                else if (key == "绘制名字") show_draw_Name = (value == "true");
                else if (key == "绘制道具") show_draw_Box = (value == "true");
                else if (key == "绘制板子") show_draw_BANZI = (value == "true");
                else if (key == "绘制电机") show_draw_DIANJI = (value == "true");
                else if (key == "绘制椅子") show_draw_Chair = (value == "true");
                else if (key == "绘制道具") show_draw_Prop = (value == "true");
                else if (key == "绘制柜子") show_draw_GUIZI = (value == "true");
                else if (key == "绘制监管预知") show_draw_prophet = (value == "true");
                else if (key == "监管距离") 监管距离 = (value == "true");
                else if (key == "绘制监管") furen = (value == "true");
                else if (key == "红夫人模式") redqueenmod = (value == "true");
                else if (key == "狗眼") 狗眼 = (value == "true");
                else if (key == "绘制字体大小") huizhiziti = std::stof(value);
                else if (key == "调试模式") Debugging = (value == "true");
                else if (key == "平板椅") 平板椅 = (value == "true");
                else if (key == "灵魂") 灵魂 = (value == "true");
                else if (key == "平板机") 平板机 = (value == "true");
                else if (key == "箱子距离") zuida4 = std::stoi(value);
                else if (key == "圣诞箱子距离") zuida5 = std::stoi(value);
                else if (key == "摄影机距离") zuida6 = std::stoi(value);
                else if (key == "板子距离") zuida = std::stoi(value);
                else if (key == "电机距离") zuida2 = std::stoi(value);
                else if (key == "椅子距离") zuida3 = std::stoi(value);
                else if (key == "柜子距离") zuida7 = std::stoi(value);
                else if (key == "绘制盖板") show_draw_touch = (value == "true");

                else if (key == "盖板触发范围") 盖板触发范围 = std::stof(value);
                else if (key == "板子范围X") 板子范围X = std::stof(value);
                else if (key == "板子范围Y") 板子范围Y = std::stof(value);
                else if (key == "触摸点X") 触摸点X = std::stof(value);
                else if (key == "触摸点Y") 触摸点Y = std::stof(value);
            }
        }
        configFile.close();
    }
    else {
        printf("无法打开配置文件 %s\n", filename.c_str());
    }
}





void ResetConfig1() {
    // 重置参数值到初始值
    盖板触发范围 = 25;
    板子范围Y = 13.5;
    板子范围X = 7.5;
    触摸点X = displayInfo.width * 0.89;
    触摸点Y = displayInfo.height * 0.163;
    //89
}
void ResetConfig3() {
    // 重置参数值到初始值
    盖板触发范围 = 33;
    板子范围Y = 15.0;
    板子范围X = 11.4;
    触摸点X = displayInfo.width * 0.89;
    触摸点Y = displayInfo.height * 0.163;
    //89
}
void ResetConfig2() {
    // 重置参数值到初始值
    盖板触发范围 = 30;
    板子范围Y = 14;
    板子范围X = 14;
    触摸点X = displayInfo.width * 0.89;
    触摸点Y = displayInfo.height * 0.163;
    //89
}
void ResetConfig4() {
    // 重置参数值到初始值
    crossPointX = displayInfo.width * 0.50;
    crossPointY = displayInfo.height * 0.088;
    lineLength = 1000.000;
    openAngle = 131.327;
    rotateAngle = 115.714;
    //89
}
void ResetConfig5() {
    touchPointX2 = displayInfo.width * 0.158;
    touchPointY2 = displayInfo.height * 1.904;
}
void ResetConfig6() {
    孽蜥触摸点X = displayInfo.width * 0.163;
    孽蜥触摸点Y = displayInfo.height * 2.041;
}
void ResetConfig7() {
    touchPointX4 = displayInfo.width * 0.074;
    touchPointY4 = displayInfo.height * 1.973;
}
void ResetConfig8() {
    startX = displayInfo.width * 0.088;
    startY = displayInfo.height * 2.056;
    endX = displayInfo.width * 0.104;
    endY = displayInfo.height * 0.376;
}
void ResetConfig9() {
    孽蜥触摸点X = displayInfo.width * 0.105;
    孽蜥触摸点Y = displayInfo.height * 1.804;
}
void ResetConfig11() {
    自动技能X = displayInfo.width *0.042 ;
    自动技能Y = displayInfo.height * 1.458;
}
void ResetConfig平板下落() {
    孽蜥触摸点X = 357.8;
    孽蜥触摸点Y = 2230.8;
}
void ResetConfig平板坠机() {
    孽蜥触摸点X = 598.5;
    孽蜥触摸点Y = 2628.8;
}
void 测试触摸() {
    Touch::Down(touchPointX4, touchPointY4);
    usleep(1000 * 1000 / 5);
    Touch::Upyuan();
}
void 松手() {
    Touch::Upyuan();
}
void ResetConfig10() {
    // 重置参数值到初始值
    crossPointX = displayInfo.width * 0.50;
    crossPointY = displayInfo.height * 0.088;
    lineLength = 95.000;
    openAngle = 90.000;
    rotateAngle = 0.000;
    //89
}
float z_x, z_y, z_z, d_x, d_y, d_z, camera, r_x, r_y, r_w;
float X1, Y1, X2, Y2, W, H, MIDDLE, TOP, BOTTOM;
int 距离;
char objtext[256];
//char content[1024];
char Team[1024];
char Name[1024];
char 监管者预知[1024];

float px, py;
My_Vector3A D, Z, M;
// 新增：用于记录角色方框变白的时间
std::unordered_map<uintptr_t, double> whiteBoxStartTime;


// 计算两点之间的距离
float distance(int x1, int y1, int x2, int y2) {
    return sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
}
// 将角度从度转换为弧度
float degreeToRadian(float degree) {
    return degree * (M_PI / 180.0);
}
// 判断点是否在矩形内的函数
int isPointInRectangle(float pointx, float pointy, float rectTopLeftx, float rectTopLefty, float rectBottomRightx, float rectBottomRighty) {
    // 判断横坐标是否在矩形横坐标范围内
    if (pointx >= rectTopLeftx && pointx <= rectBottomRightx) {
        // 判断纵坐标是否在矩形纵坐标范围内
        if (pointy >= rectTopLefty && pointy <= rectBottomRighty) {
            return 1;  // 在矩形内返回1
        }
    }
    return 0;  // 不在矩形内返回0
}
//很简单的自动盖板
//获取盖板目标
void getaim() {
    srand((unsigned int)time(NULL));
    bool isTouchDown = false;
    while (1)
    {


        float minDist = -1;
        int nearestIndex = -1;
        for (int i = 0; i < bosscount; i++) {
            float x = getFloat(监管者[i].objcoor + 0x50);
            float y = getFloat(监管者[i].objcoor + 0x58);
            float dist = distance(Z.X, Z.Y, x, y);
            if (minDist == -1 || dist < minDist) {
                minDist = dist;
                nearestIndex = i;
            }
        }
        盖板监管者 = 监管者[nearestIndex].obj;
        float minDists = -1;
        int nearestIndexs = -1;
        for (int i = 0; i < woodcount; i++) {
            int bzpd = getDword(板子[i].obj + 0xa8);
            if (bzpd == 65536)
            {
                continue;//跳过使用的板子
            }
            float x = getFloat(板子[i].objcoor + 0x50);
            float y = getFloat(板子[i].objcoor + 0x58);
            float dist = distance(Z.X, Z.Y, x, y);
            if (minDists == -1 || dist < minDists) {
                minDists = dist;
                nearestIndexs = i;
            }
        }
        盖板监管者 = 监管者[nearestIndex].obj;
        盖板板子 = 板子[nearestIndexs].obj;
        float 板子x = getFloat(板子[nearestIndexs].objcoor + 0x50);
        float 板子y = getFloat(板子[nearestIndexs].objcoor + 0x58);

        监管者X = getFloat(监管者[nearestIndex].objcoor + 0x50);
        监管者Y = getFloat(监管者[nearestIndex].objcoor + 0x58);
        dx = getFloat(板子[nearestIndexs].objcoor + 0x68);
        dy = getFloat(板子[nearestIndexs].objcoor + 0x80);

        float r = sqrt(dx * dx + dy * dy);
        // 求角度，通过反正切函数atan得到弧度值，再转换为角度值（180/PI转换）
        float angle_radian = atan2(dy, dx);
        角度值 = angle_radian * 180 / M_PI;
        float dist = distance(Z.X, Z.Y, 板子x, 板子y);
        if (dist <= 盖板触发范围)
        {
            自身在板子范围 = true;
        }
        else
        {
            自身在板子范围 = false;
        }
        //以下为板子四角计算
        float angleInRadian = degreeToRadian(角度值);


        // 角A（木板前端左上角）
        板子x1 = 板子x + (板子范围X / 2) * cos(angleInRadian) + (板子范围Y / 2) * cos(degreeToRadian(角度值 + 90));
        板子y1 = 板子y + (板子范围X / 2) * sin(angleInRadian) + (板子范围Y / 2) * sin(degreeToRadian(角度值 + 90));

        // 角B（木板前端右下角）
        板子x2 = 板子x + (板子范围X / 2) * cos(angleInRadian) - (板子范围Y / 2) * cos(degreeToRadian(角度值 + 90));
        板子y2 = 板子y + (板子范围X / 2) * sin(angleInRadian) - (板子范围Y / 2) * sin(degreeToRadian(角度值 + 90));

        // 角C（木板后端右下角）
        板子x3 = 板子x - (板子范围X / 2) * cos(angleInRadian) - (板子范围Y / 2) * cos(degreeToRadian(角度值 + 90));
        板子y3 = 板子y - (板子范围X / 2) * sin(angleInRadian) - (板子范围Y / 2) * sin(degreeToRadian(角度值 + 90));

        // 角D（木板后端左上角）
        板子x4 = 板子x - (板子范围X / 2) * cos(angleInRadian) + (板子范围Y / 2) * cos(degreeToRadian(角度值 + 90));
        板子y4 = 板子y - (板子范围X / 2) * sin(angleInRadian) + (板子范围Y / 2) * sin(degreeToRadian(角度值 + 90));
        //float num1 = 10, num2 = 5, num3 = 15, num4 = 7;
        float xmax, xmin;
        float ymax, ymin;

        // 先假设第一个数是最大和最小的
        xmax = 板子x1;
        xmin = 板子x1;

        if (板子x2 > xmax) {
            xmax = 板子x2;
        }
        if (板子x3 > xmax) {
            xmax = 板子x3;
        }
        if (板子x4 > xmax) {
            xmax = 板子x4;
        }

        if (板子x2 < xmin) {
            xmin = 板子x2;
        }
        if (板子x3 < xmin) {
            xmin = 板子x3;
        }
        if (板子x4 < xmin) {
            xmin = 板子x4;
        }

        // 先假设第一个数是最大和最小的
        ymax = 板子y1;
        ymin = 板子y1;

        if (板子y2 > ymax) {
            ymax = 板子y2;
        }
        if (板子y3 > ymax) {
            ymax = 板子y3;
        }
        if (板子y4 > ymax) {
            ymax = 板子y4;
        }

        if (板子y2 < ymin) {
            ymin = 板子y2;
        }
        if (板子y3 < ymin) {
            ymin = 板子y3;
        }
        if (板子y4 < ymin) {
            ymin = 板子y4;
        }

        //监管者在板子范围 = isPointInRectangle(监管者X,监管者Y, 板子x1,板子y4, 板子x3,板子y2);
        if (监管者X <= xmax && 监管者Y <= ymax && 监管者X >= xmin && 监管者Y >= ymin)
        {
            监管者在板子范围 = true;
        }
        else
        {
            监管者在板子范围 = false;
        }
        if (监管者在板子范围 && 自身在板子范围 && show_draw_touch && 自身阵营 == 2)
        {
            Touch::Down(触摸点Y + rand() % 100 - 50, 触摸点X + rand() % 100 - 50);//随机触摸点，rand就是随机数函数。。
            //printf("按住");
            isTouchDown = true;
            usleep(1000 * 1000 / 5);
            Touch::Upyuan();
            //printf("松开");
            isTouchDown = false;
        }



        usleep(1000 * 1000 / 30);
    }
}
void AimBotAuto()
{
    bool 触摸状态 = false;
    // 是否按下触摸


    float SpeedMin = 2.0f;
    // 临时触摸速度

    double w = 0.0f, h = 0.0f, cmp = 0.0f;
    // 宽度 高度 正切

    /*double ScreenX = displayInfo.width, ScreenY = displayInfo.height;
    const Vector2 P;
    P.x=displayInfo.width;
    P.y=displayInfo.height;
    const Vector2 P(ScreenX, ScreenY); */

    //const ImVec2 P(ScreenX, ScreenY); 
    double ScreenX, ScreenY;
    if (displayInfo.width > displayInfo.height)
    {
        ScreenX = displayInfo.height;
        ScreenY = displayInfo.width;
    }
    else
    {

        ScreenX = displayInfo.width;
        ScreenY = displayInfo.height;
    }
    const My_Vector2 P(ScreenX, ScreenY);
    Touch::Init(P, 触摸开启);	//初始化触摸

    // 分辨率(竖屏)PS:滑屏用的坐标是竖屏状态下的

    double ScrXH = ScreenX / 2.0f;
    // 一半屏幕X

    double ScrYH = ScreenY / 2.0f;
    // 一半屏幕Y

    static float TargetX = 0;
    static float TargetY = 0;
    // 触摸目标位置
    //Vector3A obj;   



    while (1)
    {

        Touch::Down(触摸点X, 触摸点Y);
        usleep(1000 * 10);
        for (int i = 0; i < 50; i++)
        {
            Touch::Move(触摸点X + i * 5, 触摸点Y + i * 5);
            usleep(1000 * 10);
        }
        //usleep(1000*10);
        Touch::Upyuan();
        //Touch::Close;
        usleep(1000 * 1000);
        usleep(1000 * 100);
    }
}



ImColor 监管颜色 = ImColor(255, 0, 0, 255);
ImColor 求生颜色 = ImColor(0, 255, 0, 255);
ImColor 白色 = ImColor(255, 255, 255, 255);
ImColor 红色 = ImColor(255, 0, 0, 255);
ImColor 绿色 = ImColor(0, 255, 0, 255);
ImColor 蓝色 = ImColor(0, 0, 255, 255);
ImColor 黄色 = ImColor(255, 255, 0, 255);
ImColor 紫色 = ImColor(255, 0, 255, 255);
ImColor 黑色 = ImColor(0, 0, 0, 255);
ImColor BoneColor = ImColor(255, 0, 0, 255);
ImColor BotBoneColor = ImColor(255, 255, 255, 255);
ImColor 橙色 = ImColor(255, 165, 0, 255);
int 状态 = 0;
int 数据获取状态 = 0;
int 遍历次数 = 0;
char extractedString[64];//一个字符数组，用于存储提取的字符串
long int MatrixOffset = 0, ArrayaddrOffset = 0;
typedef struct {
    unsigned long addr;
    unsigned long taddr;
} ModuleBssInfo;


ModuleBssInfo get_module_bss(int pid, const char* module_name) {
    FILE* fp;
    ModuleBssInfo info = { 0, 0 };
    char filename[64];
    char line[1024];

    // 生成文件名
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);

    // 打开文件
    fp = fopen(filename, "r");

    bool found_module = false;

    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            // 先判断是否包含模块名
            if (strstr(line, module_name) != NULL) {
                found_module = true;
            }

            if (found_module) {
                // 检查是否满足rw权限且行长度符合要求
                long addr, taddr;
                sscanf(line, "%lx-%lx", &addr, &taddr);
                if (strstr(line, "rw") != NULL && strlen(line) < 86 && (taddr - addr) / 4096 >= 2800) {
                    //printf("%d", (taddr-addr)/4096);

                        // 将行按空格分割成字符串数组（这里简单示意，实际可能需要更完善的分割函数）
                    char* words[10];
                    int numWords = 0;
                    char* token = strtok(line, " ");
                    while (token != NULL && numWords < 10) {
                        words[numWords++] = token;
                        token = strtok(NULL, " ");
                    }

                    // 遍历分割后的字符串数组，查找地址范围并转换
                    for (int i = 0; i < numWords; i++) {
                        if (sscanf(words[i], "%lx-%lx", &info.addr, &info.taddr) == 2) {
                            fclose(fp);
                            return info;
                        }
                    }

                    // 如果未找到正确格式的地址范围，设置为0并返回
                    info.addr = 0;
                    info.taddr = 0;
                    fclose(fp);
                    return info;
                }
            }
        }

        fclose(fp);
    }

    return info;
}

ModuleBssInfo get_module_bssgjf(int pid, const char* module_name) {
    FILE* fp;
    ModuleBssInfo info = { 0, 0 };
    long addr, taddr;
    char* pch;
    char filename[64];
    char line[1024];
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    fp = fopen(filename, "r");
    bool is = false;
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            sscanf(line, "%lx-%lx", &addr, &taddr);
            if (strstr(line, module_name) && strstr(line, "r-xp") != NULL && (taddr - addr) == 114982912) {
                is = true;
            }
            if (is) {
                if (strstr(line, "rw") != NULL && !feof(fp) && (strlen(line) < 86)) {
                    long addr, taddr;
                    sscanf(line, "%lx-%lx", &addr, &taddr);//解析
                    if ((taddr - addr) / 4096 <= 3000)
                        continue;
                    if (sscanf(line, "%lx-%lx", &info.addr, &info.taddr) != 2) {
                        // 处理转换失败的情况
                        info.addr = 0;
                        info.taddr = 0;
                        break;
                    }
                    break;
                }
            }
        }
        fclose(fp);
    }
    return info;
}






int get_name_pid1(const char* packageName) {
    int id = -1;
    DIR* dir;
    FILE* fp;
    char filename[64];
    char cmdline[64];
    struct dirent* entry;
    dir = opendir("/proc");
    while ((entry = readdir(dir)) != NULL) {
        id = atoi(entry->d_name);
        if (id != 0) {
            sprintf(filename, "/proc/%d/cmdline", id);
            fp = fopen(filename, "r");
            if (fp) {
                fgets(cmdline, sizeof(cmdline), fp);
                fclose(fp);
                if ((strstr(cmdline, packageName) != NULL || strstr(cmdline, "com.netease.idv") != NULL) && strstr(cmdline, "com") != NULL && strstr(cmdline, "PushService") == NULL && strstr(cmdline, "gcsdk") == NULL) {
                    sprintf(extractedString, "%s", cmdline);
                    closedir(dir);
                    id = id;
                    return id;
                    break;
                }
            }
        }
    }
    closedir(dir);
    return -1;
}
long getModuleBasegjf(int pid, const char* module_name) {
    FILE* fp;
    long addr, taddr;
    char* pch;
    char filename[64];
    char line[1024];
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    fp = fopen(filename, "r");
    bool is = false;
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "r-xp") != NULL && !feof(fp) && strstr(line, module_name)) {
                sscanf(line, "%lx-%lx", &addr, &taddr);
                if ((taddr - addr) == 114982912) {
                    // 处理转换失败的情况
                    fclose(fp);
                    return addr;
                    break;
                }
                //break;
            }

        }
        fclose(fp);
    }
    return 0;
}

int c;
char libso[256] = { "libclient.so" };
void read_thread(long int PD1, long int PD2, long int PD3)
{
    pid = get_name_pid1("dwrg");
    get_name_pid(extractedString);
    ModuleBssInfo result;
    if (strstr(extractedString, "com.netease.idv") != NULL) {
        libbase = getModuleBasegjf(pid, ".");
        result = get_module_bssgjf(pid, ".");
    }
    else {
        libbase = getModuleBase(libso);
        result = get_module_bss(pid, libso);
    }
    c = (result.taddr - result.addr) / 4096;
    long buff[512];//缓存指针数据
    while (MatrixOffset == 0 || ArrayaddrOffset == 0)
    {
        状态 = 1;
        for (int i = 0; i < c; i++) {
            vm_readv(result.addr + (i * 4096), &buff, 0x1000);
            for (int ii = 0; ii < 512; ii += 1) {
                if (buff[ii] != 0) {
                    int tempMatrix = getDword(getPtr64(buff[ii] + 0x98) + 0x2a8);
                    //int tempMatrixx = getDword(buff[ii+1]);
                    if (tempMatrix == 970037390 || tempMatrix == 970061201 || tempMatrix == 959354481) {
                        MatrixOffset = result.addr - libbase + i * 4096 + ii * 8;
                    }
                }
                //数组偏移，紧下方就有用到
                if (buff[ii] == 16384) {
                    int tempszz = getDword(result.addr + 4096 * i + 8 * ii - 0x8);
                    if (tempszz == 257 && getPtr64(result.addr + i * 4096 + ii * 8 + 0x70) == (result.addr + i * 4096 + ii * 8 + 0x78)) {
                        ArrayaddrOffset = result.addr - libbase + i * 4096 + ii * 8 + 0x88;
                    }
                }
                //坐标
                if (buff[ii] == 16384) {
                    int tempszz = getDword(result.addr + 4096 * i + 8 * ii + 0x28);
                    if (tempszz == 1 && getFloat(result.addr + 4096 * i + 8 * ii + 0x30) == -1) {
                        自身坐标 = result.addr + 4096 * i + 8 * ii + 0x34;
                    }
                }
            }
        }

        if (MatrixOffset != 0 && ArrayaddrOffset != 0) {
            状态 = 2;
            break;
        }
        遍历次数++;
        sleep(5);
    }



    while (true)
    {

        Arrayaddr = getPtr64(libbase + ArrayaddrOffset);    //数组
        long int 测试 = getPtr64(libbase + ArrayaddrOffset + 8);
        Count = 3000;    //数组数量     	        	
        int 指针数量 = 0;
        int 红夫人模式 = 0;
        int 板子数量 = 0;
        int 监管者数量 = 0;
        for (int ii = 0; ii < Count; ii++) {
            对象 = getPtr64(Arrayaddr + 0x8 * ii);	// 遍历数量次数            
            对象1 = getPtr64(Arrayaddr + 0x8 * ii);
            if (对象 == 0)
                break;

            namezfcz = getPtr64(getPtr64(getPtr64(getPtr64(getPtr64(对象 + 0xe0) + 0x0) + 0x8) + 0x20) + 0x20) + 0x8;//字符串组
            int len = getDword(namezfcz + 0x8);//长度
            if (len >= 256)
                continue;

            过滤类名.resize(0);
            for (int i = 0; i < len; i += 24) {
                vm_readv(getPtr64(namezfcz) + i, gwd1, 24);//字符串组
                gwd1[24] = '\0';
                过滤类名 += gwd1;
            }

            int 过滤重复指针 = 0;
            float pd1 = getFloat(对象 + 0x150);//三个判断
            float pd2 = getFloat(对象 + 0x298);
            int jxpd = getDword(对象 + 0x78);
            for (int i = 0; i < 指针数量; i++) {
                if (对象 == data[i].obj) {
                    过滤重复指针 = 1;
                }
            }
            if (过滤重复指针 == 1) {
                continue;
            }
            if (strstr(过滤类名.c_str(), "creature") != NULL) {
                continue;//过滤随从
            }
            std::string s;
            //预知监管者,很简单
            if (show_draw_prophet) {//预知开始
                if (strstr(过滤类名.c_str(), "burke_console") == NULL && strstr(过滤类名.c_str(), "h55_joseph_camera") == NULL && strstr(过滤类名.c_str(), "redqueen_e_heijin_yizi") == NULL) {
                    if (strstr(过滤类名.c_str(), "boss") != NULL) {
                        s += getboss(过滤类名.c_str());
                        sprintf(监管者预知, "%s", s.c_str());
                        std::string name = 监管者预知;
                        if (name.size() >= 2 && name[0] == '[' && name[name.size() - 1] == ']') {
                            name = name.substr(1, name.size() - 2);
                        }

                        // 查找对应的监管者距离
                        auto it = 监管者距离.find(name);
                        if (it != 监管者距离.end()) {
                            预警距离 = it->second;
                        }
                        else {
                            预警距离 = 4.0f; // 默认值
                        }
                    }
                }
            }//预知结束



            if (strstr(过滤类名.c_str(), "woodplane001") != NULL || strstr(过滤类名.c_str(), "woodplane01") != NULL)
            {
                板子[板子数量].obj = 对象;
                strcpy(板子[板子数量].str, "板子");
                板子[板子数量].阵营 = 666;
                板子[板子数量].objcoor = getPtr64(对象 + 0x40);
                板子数量++;
            }
            if (strstr(过滤类名.c_str(), "player") != NULL || strstr(过滤类名.c_str(), "boss") != NULL || pd1 == 450 || strstr(过滤类名.c_str(), "scene") != NULL || strstr(过滤类名.c_str(), "prop") != NULL || strstr(过滤类名.c_str(), "mirror") != NULL || Debugging)
            {
                data[指针数量].obj = 对象;
                if (strstr(过滤类名.c_str(), "boss") != NULL) {
                    //data[指针数量].str=getboss(过滤类名.c_str());
                    if (jxpd != 65150)
                    {
                        监管者[监管者数量].obj = 对象;
                        监管者[监管者数量].objcoor = getPtr64(对象 + 0x40);
                        监管者数量++;
                    }
                    strcpy(data[指针数量].str, getboss(过滤类名.c_str()));
                    data[指针数量].阵营 = 1;
                }
                else if (strstr(过滤类名.c_str(), "player") != NULL || strstr(类名.c_str(), "npc_deluosi_dress_ghost") != NULL || strstr(类名.c_str(), "h55_pendant_huojian") != NULL) {
                    //data[指针数量].str=getplayer(过滤类名.c_str());
                    strcpy(data[指针数量].str, getplayer(过滤类名.c_str()));
                    data[指针数量].阵营 = 2;
                    人数++;
                }
                else if (strstr(过滤类名.c_str(), "scene") != NULL) {
                    //data[指针数量].str=getscene(过滤类名.c_str());
                    strcpy(data[指针数量].str, getscene(过滤类名.c_str()));
                    data[指针数量].阵营 = 3;
                }
                else if (strstr(过滤类名.c_str(), "prop") != NULL) {
                    //data[指针数量].str=getprop(过滤类名.c_str());
                    strcpy(data[指针数量].str, getprop(过滤类名.c_str()));
                    data[指针数量].阵营 = 4;
                }

                else if (strstr(过滤类名.c_str(), "redqueen") != NULL && strstr(过滤类名.c_str(), "mirror") != NULL && strstr(过滤类名.c_str(), "model") != NULL) {
                    //data[指针数量].str=getprop(过滤类名.c_str());
                    //strcpy(data[指针数量].str, getprop(过滤类名.c_str()));
                    data[指针数量].阵营 = 5;
                }
                //sprintf(data[指针数量].类名, "%s", 过滤类名.c_str());
                strcpy(data[指针数量].类名, 过滤类名.c_str());
                data[指针数量].objcoor = getPtr64(对象 + 0x40);
                指针数量++;
            }

            //红夫人模式
            if (pd1 == 450) {

                if (红夫人模式 == 1 && strstr(过滤类名.c_str(), "boss") != NULL && strstr(过滤类名.c_str(), "redqueen") != NULL && strstr(过滤类名.c_str(), "mirror") == NULL && getFloat(getPtr64(对象 + 0x40) + 0xE0) != 0 && getFloat(getPtr64(对象 + 0x40) + 0xE8) != 0 && ((getFloat(getPtr64(对象 + 0x40) + 0xE4) <= -300 && jxpd == 65150) || (getFloat(getPtr64(对象 + 0x40) + 0xE4) >= -300 && jxpd != 65150)))
                {
                    红夫人镜像 = 对象;
                }
                else if (strstr(过滤类名.c_str(), "boss") != NULL && strstr(过滤类名.c_str(), "redqueen") != NULL && strstr(过滤类名.c_str(), "mirror") == NULL && getFloat(getPtr64(对象 + 0x40) + 0xE0) != 0 && getFloat(getPtr64(对象 + 0x40) + 0xE8) != 0 && getFloat(getPtr64(对象 + 0x40) + 0xE4) >= -300 && jxpd != 65150)
                {
                    红夫人 = 对象;
                    红夫人模式 = 1;
                }
                if (strstr(过滤类名.c_str(), "mirror_model_obj_001") != NULL)
                {
                    假镜子 = 对象1;
                }
                else  if (strstr(过滤类名.c_str(), "boss") != NULL && strstr(过滤类名.c_str(), "mirror") != NULL && getFloat(getPtr64(对象 + 0x40) + 0xE0) != 0 && getFloat(getPtr64(对象 + 0x40) + 0xE8) != 0) {
                    镜子 = 对象1;
                }
            }
        }
        woodcount = 板子数量;
        bosscount = 监管者数量;
        //数量=指针数量;
        if (指针数量 > 100) {
            数量 = 指针数量;
        }
        else {
            数量 = 100;
        }
        usleep(1000 * 1000 / 2);
    }
}
void Draw_Main(ImDrawList* Draw) {
    // 根据编号的值更新 show_draw_Name 的值
    show_draw_Name = !编号;

    Matrix = getPtr64(getPtr64(libbase + MatrixOffset) + 0x98) + 0x380; //矩阵
    if (鹿头辅助线) {//仅仅是画两条辅助线而已，有一点难度
        // 将开合角度转换为弧度
        float openAngleRad = openAngle * (M_PI / 180.0f);

        // 定义两个旋转角度参数
        float rotateAngle1 = rotateAngle; // 第一条线的旋转角度
        float rotateAngle2 = rotateAngle + openAngle; // 第二条线的旋转角度

        // 将旋转角度转换为弧度
        float rotateAngle1Rad = rotateAngle1 * (M_PI / 180.0f);
        float rotateAngle2Rad = rotateAngle2 * (M_PI / 180.0f);

        // 计算第一条线相对于旋转中心的向量
        ImVec2 line1Dir = ImVec2(cos(rotateAngle1Rad), sin(rotateAngle1Rad));

        // 计算第二条线相对于旋转中心的向量
        ImVec2 line2Dir = ImVec2(cos(rotateAngle2Rad), sin(rotateAngle2Rad));

        // 计算第一条线的端点
        ImVec2 startPoint1 = ImVec2(
            crossPointX - lineLength * line1Dir.x,
            crossPointY - lineLength * line1Dir.y
        );
        ImVec2 endPoint1 = ImVec2(
            crossPointX + lineLength * line1Dir.x,
            crossPointY + lineLength * line1Dir.y
        );

        // 计算第二条线的端点
        ImVec2 startPoint2 = ImVec2(
            crossPointX - lineLength * line2Dir.x,
            crossPointY - lineLength * line2Dir.y
        );
        ImVec2 endPoint2 = ImVec2(
            crossPointX + lineLength * line2Dir.x,
            crossPointY + lineLength * line2Dir.y
        );

        // 绘制第一条线，颜色为红色
        ImGui::GetBackgroundDrawList()->AddLine(startPoint1, endPoint1, IM_COL32(255, 0, 0, 255), 2.0f);

        // 绘制第二条线，颜色为蓝色
        ImGui::GetBackgroundDrawList()->AddLine(startPoint2, endPoint2, IM_COL32(0, 0, 255, 255), 2.0f);
    }



  




    if (触摸位置)
    {
        /* Draw->AddCircleFilled({触摸点X, py * 2 - 触摸点Y}, 50, 蓝色, 0);
         Draw->AddCircleFilled({ touchPointX2, touchPointY2 }, 50,红色, 0);
         Draw->AddCircleFilled({ 孽蜥触摸点X, 孽蜥触摸点Y }, 50, 绿色, 0);
         Draw->AddCircle({ touchPointX3, touchPointY3 }, circleRadius, 黑色, 0, 1);
         Draw->AddCircleFilled({ touchPointX4, touchPointY4 }, 50, 黄色, 0);
         Draw->AddCircleFilled({ startX,startY},25, 蓝色,0);
         Draw->AddCircleFilled({ endX,endY},25, 红色,0);*///竖屏下的显示

        Draw->AddCircleFilled({ 触摸点X, py * 2 - 触摸点Y }, 50, 蓝色, 0);
        Draw->AddCircleFilled({ touchPointY2, py * 2 - touchPointX2 }, 50, 红色, 0);
        Draw->AddCircleFilled({ 孽蜥触摸点Y, py * 2 - 孽蜥触摸点X }, 50, 绿色, 0);
        Draw->AddCircle({ touchPointY3, py * 2 - touchPointX3 }, circleRadius, 黑色, 0, 1);
        Draw->AddCircleFilled({ touchPointY4,  py * 2 - touchPointX4 }, 50, 黄色, 0);
        Draw->AddCircleFilled({ startY, py * 2 - startX }, 25, 蓝色, 0);
        Draw->AddCircleFilled({ endY, py * 2 - endX }, 25, 红色, 0);
        Draw->AddCircleFilled({ 自动技能Y, py * 2 - 自动技能X }, 25, 绿色, 0);
        /* Draw->AddCircle({触摸点X , py * 2 - 触摸点Y}, 50, ImColor(0, 0, 255), 0, 1);
         Draw->AddCircle({ touchPointX2, touchPointY2 }, 50, 红色, 0, 1);
         // 绘制圆
         Draw->AddCircle({ 孽蜥触摸点X,孽蜥触摸点Y }, 50, 绿色, 0, 1);
         Draw->AddCircle({ touchPointX3, touchPointY3 }, circleRadius, 黑色, 0, 1);
         */
    }

    Z.X = getFloat(自身坐标);
    自身向量X = getFloat(自身坐标 + 24);
    自身向量Y = getFloat(自身坐标 + 32);

   

    Z.Z = getFloat(自身坐标 + 4) - 10;
    Z.Y = getFloat(自身坐标 + 8);



    红夫人X = getFloat(getPtr64(红夫人 + 0x40) + 0x50);
    红夫人Z = getFloat(getPtr64(红夫人 + 0x40) + 0x54);
    红夫人Y = getFloat(getPtr64(红夫人 + 0x40) + 0x58);
    假镜子X = getFloat(getPtr64(假镜子 + 0x40) + 0x50);
    假镜子Z = getFloat(getPtr64(假镜子 + 0x40) + 0x54);
    假镜子Y = getFloat(getPtr64(假镜子 + 0x40) + 0x58);
    镜子X = getFloat(getPtr64(镜子 + 0x40) + 0x50);
    镜子Z = getFloat(getPtr64(镜子 + 0x40) + 0x54);
    镜子Y = getFloat(getPtr64(镜子 + 0x40) + 0x58);
    红夫人镜像X = getFloat(getPtr64(红夫人镜像 + 0x40) + 0x50);
    红夫人镜像Z = getFloat(getPtr64(红夫人镜像 + 0x40) + 0x54);
    红夫人镜像Y = getFloat(getPtr64(红夫人镜像 + 0x40) + 0x58);
    if (红夫人Z >= -300 && 红夫人镜像Z >= -300 && 红夫人X != 0 && 红夫人Y != 0 && 红夫人镜像X != 0 && 红夫人镜像Y != 0) {
        mirror = true;
    }
    else {
        mirror = false;
    }

    Matrix = getPtr64(getPtr64(getPtr64(libbase + MatrixOffset) + 0x98) + 0x10) + 0x180; //矩阵
    memset(matrix, 0, 16);
    vm_readv(Matrix - 4, 过滤矩阵, 17 * 4);



    if (过滤矩阵[0] == 1) {
        for (int i = 0; i < 16; i++) {
            if (i <= 3) {
                if (过滤矩阵[i + 1] >= -2 && 过滤矩阵[i + 1] <= 2)
                    matrix[i] = 过滤矩阵[i + 1];
            }
            else {
                matrix[i] = 过滤矩阵[i + 1];
            }
        }
    }
    if (show_draw_prophet) {
        auto textSize = ImGui::CalcTextSize(监管者预知, 0, 25);//这个0的意思是在双哈希符号（##）之后不隐藏文本
        绘制字体描边(huizhiziti, px - (textSize.x / 2), 130, 红色, 监管者预知);
        //Draw->AddText({px-(textSize.x/2),130}, 红色, 监管者预知);
    }

    double currentTime = ImGui::GetTime(); // 获取当前时间
    for (int i = 0; i < 数量; i++) {

        if (strstr(data[i].类名, "buzz") != NULL)//77
            continue;//跳过不知所谓的东西
        if (strstr(data[i].类名, "nvyao.gim") != NULL)
            continue;//跳过女妖蜡烛
        //多组坐标很正常
        if (实体) {
            D.X = getFloat(data[i].objcoor + 0x50);
            D.Z = getFloat(data[i].objcoor + 0x54);
            D.Y = getFloat(data[i].objcoor + 0x58);
            敌人向量X= getFloat(data[i].objcoor + 0x50+168);
            敌人向量Y = getFloat(data[i].objcoor + 0x50 +176);
        }
        else if (视角) {
            //D.X = getFloat(data[i].objcoor + 0xe0);
            //D.Z = getFloat(data[i].objcoor + 0xe4);
            //D.Y = getFloat(data[i].objcoor + 0xe8);//11
            D.X = getFloat(data[i].objcoor + 实验偏移量);
           D.Z = getFloat(data[i].objcoor +实验偏移量+4);
           D.Y = getFloat(data[i].objcoor + 实验偏移量+8);//11
            敌人向量X = getFloat(data[i].objcoor + 0xe0 +24);
            敌人向量Y = getFloat(data[i].objcoor + 0xe0 +32);
        
        }
        if (D.X == Z.X && D.Y == Z.Y)
        {
            自身 = data[i].obj;
            自身阵营 = data[i].阵营;
        }
        if (D.X == 0 || D.Y == 0) {
            continue;//跳过xy0
        }
        if (D.Z <= -300) {
            continue;//跳过地下
        }
        int jxpd = getDword(data[i].obj + 0x78);
        //字面意思
        camera = matrix[3] * D.X + matrix[7] * D.Z + matrix[11] * D.Y + matrix[15];
        距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2) + pow(D.Z - Z.Z, 2)) / 距离比例;
        矩阵视野距离 = sqrt(pow(D.X - M.X, 2) + pow(D.Y - M.Y, 2) + pow(D.Z - M.Z, 2)) / 距离比例;
        孽蜥距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
        r_x = px + (matrix[0] * D.X + matrix[4] * D.Z + matrix[8] * D.Y + matrix[12]) / camera * px;
        r_y = py - (matrix[1] * D.X + matrix[5] * (D.Z + 8.5) + matrix[9] * (D.Y) + matrix[13]) / camera * py;
        r_w = py - (matrix[1] * D.X + matrix[5] * (D.Z + 28.5) + matrix[9] * (D.Y) + matrix[13]) / camera * py;






        W = (r_y - r_w) / 2;	// 宽度
        H = r_y - r_w;		// 高度
        X1 = r_x - (r_y - r_w) / 4;	// X1
        Y1 = r_y - H / 2;	// Y1
        X2 = X1 + W;		// X2
        Y2 = Y1 + H;		// Y2
        if (距离 >= 300) {
            continue;
        }

        //这下面的都很简单，字面意思。。。。
        if (W > 0) {
            if (Debugging) {
                std::string test;
                sprintf(objtext, "%lx", data[i].obj);
                test += " [";
                test += std::to_string((int)距离);
                test += " 米]  0x";
                test += objtext;
                test += " [类名] ";
                test += data[i].类名;

                auto textSize = ImGui::CalcTextSize(test.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, ImColor(255, 200, 0, 255), test.c_str());

            }

          


            if (strstr(data[i].类名, "camera") != NULL) {
                if (getDword(data[i].obj + 0xa8) == 256) {
                    continue;//跳过使用过的照相机
                }
                std::string s;
                if (show_draw_Camera) {
                    if (距离 > zuida6) {
                        continue;
                    }
                    s += "[摄影机]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, ImColor(255, 200, 0, 255), s.c_str());
            }
            if (strstr(data[i].类名, "caRileyet") != NULL) {
                std::string s;
                if (show_draw_GUIZI) {
                    if (距离 > zuida7) {
                        continue;
                    }
                    s += "[柜子]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 30);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
                textSize.y *= huizhiziti; // 增加文本高度，模拟更大的字体效果
            }

            if (strstr(data[i].类名, "dm65_scene_gallows") != NULL && 平板椅) {//如果使用dm65_scene_gallows（_hx）则会在地板上绘制很多出来
                std::string s;
                if (show_draw_Chair) {
                    if (距离 > zuida3) {
                        continue;
                    }
                    s += "[狂欢之椅]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
            }

         




            if (strstr(data[i].类名, "banqiubang") != NULL) {
                std::string s;
                if (D.Z>11.5) {
                  
                    s += "[击球中]";
                  
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 30);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
               
            }





            if (strstr(data[i].类名, "dm65_scene_sender_01") != NULL && 平板机) {//如果使用dm65_scene_gallows（_hx）则会在地板上绘制很多出来
                std::string s;
                if (show_draw_DIANJI) {
                    if (距离 > zuida2) {
                        continue;
                    }
                    s += "[电机]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
                const float scale = 1.5f; // 1.5倍大小



              
            }
            if (strstr(data[i].类名, "mirror_model_obj_001") != NULL || strstr(data[i].类名, "mirror_model_obj_007") != NULL || strstr(data[i].类名, "h55_guajian_rongguang") != NULL || strstr(data[i].类名, "mirror_model_obj_005") != NULL || strstr(data[i].类名, "mirror_model_obj_002") != NULL || strstr(data[i].类名, "mirror_model_obj_003") != NULL || strstr(data[i].类名, "mirror_model_obj_004") != NULL || strstr(data[i].类名, "mirror_model_obj_006") != NULL || strstr(data[i].类名, "redqueen_e_krm_head") != NULL) {
                std::string s;
                if (镜子伞) {

                    s += "[伪镜子]";
                    s += std::to_string((int)(距离 * 2));
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 白色, s.c_str());
                ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f, 方框样式);


            }
            if (strstr(data[i].类名, "pendant_huojian") != NULL) {
                std::string s;
                if (镜子伞) {

                    s += "[哭泣火箭]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
                ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f, 方框样式);
            }
            if (strstr(data[i].类名, "trap") != NULL) {
                std::string s;
                if (镜子伞) {

                    s += "[鹿头陷阱]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 黄色, s.c_str());
                //ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f);
            }
            if (strstr(data[i].类名, "h55_pendant_puppet") != NULL) {
                std::string s;
                if (镜子伞) {

                    s += "[厂长傀儡]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 黄色, s.c_str());
                //ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f);
            }

            if (strstr(data[i].类名, "h55_pendant_tower") != NULL && 狗眼) {
                std::string s;
                if (镜子伞) {

                    s += "[眼]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 黄色, s.c_str());
                //ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f);
            }
            if (strstr(data[i].类名, "h55_pendant_patro") != NULL && 狗眼) {
                std::string s;
                if (镜子伞) {

                    s += "[狗]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 黄色, s.c_str());
                //ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f);
            }
            if (strstr(data[i].类名, "skill_hudie") != NULL && 蝴蝶) {
                std::string s;
                if (镜子伞) {

                    s += "[蝴蝶]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
                ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f, 方框样式);
            }
            if (镜子伞) {

                if (strstr(data[i].类名, "mirror_model_obj_001") != NULL ||
                    strstr(data[i].类名, "mirror_model_obj_007") != NULL ||
                    strstr(data[i].类名, "h55_guajian_rongguang") != NULL ||
                    strstr(data[i].类名, "mirror_model_obj_005") != NULL ||
                    strstr(data[i].类名, "mirror_model_obj_002") != NULL ||
                    strstr(data[i].类名, "mirror_model_obj_003") != NULL ||
                    strstr(data[i].类名, "mirror_model_obj_004") != NULL ||
                    strstr(data[i].类名, "mirror_model_obj_006") != NULL ||
                    strstr(data[i].类名, "redqueen_e_krm_head") != NULL)
                {

                    捏了 = true;
                }
                else {
                    捏了 = false;
                }
            }
            if (strstr(data[i].类名, "tiaoban") != NULL) {
                std::string s;
                if (镜子伞) {

                    s += "[玩具商跳板]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 黄色, s.c_str());
                //ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f);
            }
            if (strstr(data[i].类名, "pendant_wuchang_umb") != NULL) {
                std::string s;
                if (镜子伞) {

                    s += "[伞]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
                //ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BoneColor, 6, 1, 1.8f);
            }


            if (data[i].阵营 == 3)
            {
                if (strstr(data[i].类名, "dm65_scene_prop_30") != NULL) {
                    std::string s;
                    if (show_draw_Door) {
                        s += "[大门]";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, ImColor(255, 200, 0, 255), s.c_str());
                }
                else if (strstr(data[i].类名, "christmasbox01") != NULL || strstr(data[i].类名, "halloweenbox01") != NULL) {

                    std::string s;
                    if (show_draw_Box) {//55
                        if (距离 > zuida5) {
                            continue;
                        }

                        s += "[道具箱]";
                        s += std::to_string((int)距离);
                        s += " 米";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 白色, s.c_str());


                }
                else if (strstr(data[i].类名, "dm65_scene_prop_01") != NULL) {
                    std::string s;
                    if (show_draw_Box) {
                        if (距离 > zuida4) {
                            continue;
                        }
                        s += "[道具箱]";
                        s += std::to_string((int)距离);
                        s += " 米";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
                }

                else if (strstr(data[i].类名, "dm65_scene_gallows_hx_low") != NULL) {//如果使用dm65_scene_gallows（_hx）则会在地板上绘制很多出来
                    std::string s;
                    if (show_draw_Chair) {
                        if (距离 > zuida3) {
                            continue;
                        }
                        s += "[狂欢之椅]";
                        s += std::to_string((int)距离);
                        s += " 米";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 红色, s.c_str());
                }

                else if (strstr(data[i].类名, "camera") != NULL) {//78

                    std::string s;
                    if (show_draw_Camera) {
                        if (距离 > zuida6) {
                            continue;
                        }
                        s += "[摄影机]";
                        s += std::to_string((int)距离);
                        s += " 米";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, huizhiziti);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, ImColor(255, 255, 255, 255), s.c_str());//白色
                    textSize.y *= huizhiziti; // 增加文本高度，模拟更大的字体效果
                }
                else if (strstr(data[i].类名, "dm65_scene_sender_01_low") != NULL || strstr(data[i].类名, "h55_demo_sender01alow") != NULL || strstr(data[i].类名, "dm65_scene_sender_03_low") != NULL) {
                    std::string s;
                    if (show_draw_DIANJI) {
                        if (距离 > zuida2) {
                            continue;
                        }
                        s += "[电机]";
                        s += std::to_string((int)距离);
                        s += " 米";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 橙色, s.c_str());



                   
                }
               






                
                /*else if (strstr(data[i].类名, "dm65_scene_sender_01") != NULL || strstr(data[i].类名, "h55_demo_sender01alow") != NULL || strstr(data[i].类名, "dm65_scene_sender_03_low") != NULL && 平板) {
                    std::string s;
                    if (show_draw_DIANJI) {
                        if (距离 > zuida2) {
                            continue;
                        }
                        s += "[电机]";
                        s += std::to_string((int)距离);
                        s += " 米";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                    绘制字体描边(huizhiziti,r_x - (textSize.x / 2),r_y , 橙色, s.c_str());
                }
                */
                else if (strstr(data[i].类名, "woodplane001") != NULL || strstr(data[i].类名, "woodplane01") != NULL) {
                    std::string s;
                    if (show_draw_BANZI) {
                        if (距离 > zuida) {
                            continue;
                        }

                        s += "[板子]";
                        s += std::to_string((int)距离);
                        s += " 米";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 白色, s.c_str());
                    textSize.y *= huizhiziti; // 增加文本高度，模拟更大的字体效果

                }

                else if (strstr(data[i].类名, "dm65_scene_prop_76") != NULL) {
                    std::string s;
                    if (show_draw_Cellar) {
                        s += "[地窖] ";
                        s += std::to_string((int)距离);
                        s += " 米 ";
                    }
                    auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 蓝色, s.c_str());
                }
            }

            if (show_draw_Prop && data[i].阵营 == 4) {
                std::string s;
                if (strstr(data[i].类名, "h55_pendant_inject") != NULL) {
                    s += "[镇静剂]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_moshubang") != NULL) {
                    s += "[魔术棒]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_flaregun") != NULL) {
                    s += "[信号枪]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_huzhou") != NULL) {
                    s += "[护肘]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_map") != NULL) {
                    s += "[地图]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_book") != NULL) {
                    s += "[书]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_gjx") != NULL) {
                    s += "[工具箱]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_glim") != NULL) {
                    s += "[手电筒]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_xiangshuiping") != NULL) {
                    s += "[忘忧之香]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_controller") != NULL) {
                    s += "[遥控器]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_football") != NULL) {
                    s += "[橄榄球]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_huaibiao") != NULL) {
                    s += "[怀表]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                else if (strstr(data[i].类名, "h55_pendant_puppet") != NULL) {
                    s += "[厂长傀儡]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                //插眼
                else if (strstr(data[i].类名, "h55_pendant_tower") != NULL) {
                    s += "[窥视者]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                //
                else if (strstr(data[i].类名, "h55_pendant_patro") != NULL) {
                    s += "[巡视者]";
                    s += std::to_string((int)距离);
                    s += " 米";
                }
                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, ImColor(255, 200, 0, 255), s.c_str());

            }

            int zy;//=getbool(data[i].obj + 0xaa);
            vm_readv(data[i].obj + 0xaa, &zy, 1);

            if (getFloat(data[i].obj + 0x150) == 450) {
                if (strstr(data[i].类名, "h55_joseph_camera") != NULL) {
                    continue;//跳过约瑟夫相机
                }

                if (strstr(data[i].类名, "redqueen_mirror") != NULL) {
                    continue;//跳过红芙蓉镜子
                }

                if (strstr(data[i].类名, "burke_console") != NULL) {
                    continue;//跳过疯眼场景
                }

                if (strstr(data[i].类名, "h55_survivor_w_shangren_tiaoban") != NULL) {
                    continue;//跳过商人跳板
                }

                if (show_draw_Role && strstr(data[i].类名, "chr") != NULL) {
                    std::string test;
                    test += " [";
                    test += std::to_string((int)距离);
                    test += " 米]  0x";
                    test += objtext;
                    test += " [类名] ";
                    test += data[i].类名;

                    auto textSize = ImGui::CalcTextSize(test.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, r_x - (textSize.x / 2), r_y, 白色, test.c_str());

                }

                if (自身 == data[i].obj) {
                    continue;
                }

                std::string s;

                if (data[i].阵营 == 1 || data[i].阵营 == 2) {
                    s += data[i].str;

                    if (!编号&&绘制) {
                        if (data[i].阵营 == 1 && furen) {
                            auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                            绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y1 - 45, 紫色, s.c_str());
                        }
                        else if (data[i].阵营 == 2) {
                            auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                            绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y1 - 45, ImColor(255, 255, 255, 255), s.c_str());
                        }
                    }

                    if (show_draw_Rect) {
                       
                            if (jxpd == 65150&&灵魂)
                                ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BotBoneColor, 6, 1, 1.8f, 方框样式);
                       
                        else if (data[i].阵营 == 1 && furen) {
                            ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 },监管颜色, 6, 1, 1.8f, 方框样式);
                            if (show_draw_Line) {
                                ImGui::GetForegroundDrawList()->AddLine({ px, 170 }, { X1 + W / 2, Y1 }, ImColor(255, 0, 0), 2);
                            }
                        }
                        else if (data[i].阵营 == 2) {
                            ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, 求生颜色, 6, 1, 1.8f, 方框样式);
                            if (show_draw_Line) {
                                ImGui::GetForegroundDrawList()->AddLine({ px, 170 }, { X1 + W / 2, Y1 }, ImColor(0, 255, 0), 2);
                            }
                            // 检查当前对象是否已经有编号，如果没有则分配一个新的编号并记录到map中
                            if (objectIdMapWithSelection.find(data[i].obj) == objectIdMapWithSelection.end()) {
                                // 显式进行类型转换
                                objectIdMapWithSelection[data[i].obj] = { static_cast<int>(objectIdMapWithSelection.size() + 1), false };
                            }

                            // 绘制唯一编号，在原本绘制名字的大概位置绘制编号
                            std::string indexStr = std::to_string(objectIdMapWithSelection[data[i].obj].index1);
                            if (编号) {
                                auto textSize = ImGui::CalcTextSize(indexStr.c_str(), 0, huizhiziti);
                                绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y1 - 45, ImColor(255, 200, 0, 255), indexStr.c_str());
                            }
                            float enemyVectorX = 敌人向量X;
                            float enemyVectorY = 敌人向量Y;

                            // 计算敌人朝向的描述性文本
                            std::string directionText = CalculateEnemyDirection(enemyVectorX, enemyVectorY);

                            // 绘制名字
                            std::string nameText = data[i].str;
                            auto textSize = ImGui::CalcTextSize(nameText.c_str(), 0, 25);
                            绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y1 - 45, ImColor(255, 255, 255, 255), nameText.c_str());

                            // 显示朝向信息
                            auto directionTextSize = ImGui::CalcTextSize(directionText.c_str(), 0, 25);
                            绘制字体描边(huizhiziti, X1 + W / 2 - (directionTextSize.x / 2), Y1 - 70, ImColor(255, 255, 0, 255), directionText.c_str());






                        }
                    }
                    /* // 检查当前对象是否已经有编号，如果没有则分配一个新的编号并记录到map中
                         if (objectIdMap.find(data[i].obj) == objectIdMap.end()) {
                             objectIdMap[data[i].obj] = objectIdMap.size() + 1;
                         }

                         // 绘制唯一编号，在原本绘制名字的大概位置绘制编号
                         std::string indexStr = std::to_string(objectIdMap[data[i].obj]);
                         if (编号) {
                             auto textSize = ImGui::CalcTextSize(indexStr.c_str(), 0, huizhiziti);
                             绘制字体描边(huizhiziti,{ X1 + W / 2 - (textSize.x / 2),Y1 - 45 }, ImColor(255, 200, 0, 255), indexStr.c_str());

                         }*/
                    std::string 伞距离_str = std::to_string(伞距离);
                    if (宿伞) {
                        auto textSize = ImGui::CalcTextSize(伞距离_str.c_str(), 0, 25);
                        绘制字体描边(sanjuli, px - (textSize.x / 2), 400, 绿色, 伞距离_str.c_str());
                    }
                    std::string 人数_str = std::to_string(人数);
                    /* if (编号) {
                         auto textSize = ImGui::CalcTextSize(人数_str.c_str(), 0, 25);
                         绘制字体描边(huizhiziti,{ px - (textSize.x / 2), 100 }, 绿色, 人数_str.c_str());
                     }*/
                    std::string zeroDistanceCount_str = std::to_string(zeroDistanceCount);
                    if (触摸2) {
                        auto textSize = ImGui::CalcTextSize(zeroDistanceCount_str.c_str(), 0, 25);
                        绘制字体描边(huizhiziti, px - (textSize.x / 2), 100, 绿色, zeroDistanceCount_str.c_str());
                    }

                    if (show_draw_Distance && 绘制) {
                        std::string 人物距离;
                       
                        人物距离 += std::to_string((int)距离);
                        人物距离 += " 米";
                        显示监管距离 = 距离;
                        if (data[i].阵营 == 1 && furen) {
                            auto textSize = ImGui::CalcTextSize(人物距离.c_str(), 0, 25);
                            绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y2 + 10, ImColor(255, 0, 0, 255), 人物距离.c_str());
                            if (监管距离) {

                                auto textSize = ImGui::CalcTextSize(人物距离.c_str(), 0, 25);
                               if (距离 < 35) {
                                    textColor = ImColor(255, 0, 0, 255); // 红色
                                }
                                else if (距离 >= 35 && 距离 <= 55) {
                                    textColor = ImColor(0, 255, 0, 255); // 绿色
                                }
                                else {
                                    textColor = ImColor(255, 255, 255, 255); // 白色
                                }
                               if (被打预警) {
                                   if (距离 < 预警距离) {
                                       // 定义警告文本
                                       std::string warningText = "会被打";
                                       yujingjuli = warningText;
                                       // 计算文本大小
                                       auto textSize = ImGui::CalcTextSize(warningText.c_str(), 0, 25);

                                       // 绘制带描边的文本
                                       绘制字体描边(50.0f, displayInfo.width / 2 - textSize.x / 2, displayInfo.height / 2, ImColor(255, 0, 0, 255), warningText.c_str());





                                   }
                                   else {

                                       yujingjuli = " ";
                                   }
                               }
                                绘制字体描边(huizhiziti,  px - (textSize.x / 2), 150 , textColor, 人物距离.c_str());
                              //  Draw->AddText(NULL,huizhiziti, { px - (textSize.x / 2), 150 }, textColor, 人物距离.c_str());
                               



                            }
                        }
                        else if (data[i].阵营 == 2) {
                            if (距离 == 0) {
                                zeroDistanceCount++;
                            }
                            auto textSize = ImGui::CalcTextSize(人物距离.c_str(), 0, 25);
                            绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y2 + 10, ImColor(0, 255, 0, 255), 人物距离.c_str());//距离67
                            //绿色来测试循环速度，根据距离为零的人出现的次数（每次循环）
                        }
                    }

                    /*if (show_draw_Line) {
                        ImGui::GetForegroundDrawList()->AddLine({px, py},{X1 + W/2, Y1}, ImColor(255, 255, 255),2);
                    } */
                }
            }
        }//判断w    
        if (1) {
            if (strstr(data[i].类名, "joan_cat") != NULL) {
                武器位置X = getFloat(data[i].objcoor + 0xe0);//x
                武器位置Y = getFloat(data[i].objcoor + 0xe8);//y
                武器位置Z = getFloat(data[i].objcoor + 0xe4);//z

            }

            if (strstr(data[i].类名, "wusa_weapon") != NULL) {
                武器位置X = getFloat(data[i].objcoor + 0xe0);//x
                武器位置Y = getFloat(data[i].objcoor + 0xe8);//y
                武器位置Z = getFloat(data[i].objcoor + 0xe4);//z

            }
            if (strstr(data[i].类名, "guajian") != NULL) {
                武器位置X = getFloat(data[i].objcoor + 0xe0);//x
                武器位置Y = getFloat(data[i].objcoor + 0xe8);//y
                武器位置Z = getFloat(data[i].objcoor + 0xe4);//z

            }
            if (strstr(data[i].类名, "lady_e_dizao") != NULL) {
                武器位置X = getFloat(data[i].objcoor + 0xe0);//x
                武器位置Y = getFloat(data[i].objcoor + 0xe8);//y
                武器位置Z = getFloat(data[i].objcoor + 0xe0 + 384);

            }
           
      }



        if (1) {

            if (strstr(data[i].类名, "dm65_survivor_m_bo") != NULL) {
                // 已知目标对象的坐标
                float targetX = getFloat(data[i].objcoor+1728 + 0xe0);
                float targetZ = getFloat(data[i].objcoor + 1732 + 0xe0);
                float targetY = getFloat(data[i].objcoor + 1736 + 0xe0);

                // 计算屏幕上的位置（假设使用相同的矩阵变换）
                camera = matrix[3] * targetX + matrix[7] * targetZ + matrix[11] * targetY + matrix[15];
                float distance = sqrt(pow(targetX - Z.X, 2) + pow(targetY - Z.Y, 2) + pow(targetZ - Z.Z, 2)) / 距离比例;
                float r_x = px + (matrix[0] * targetX + matrix[4] * targetZ + matrix[8] * targetY + matrix[12]) / camera * px;
                float r_y = py - (matrix[1] * targetX + matrix[5] * (targetZ + 8.5) + matrix[9] * targetY + matrix[13]) / camera * py;
                float r_w = py - (matrix[1] * targetX + matrix[5] * (targetZ + 28.5) + matrix[9] * targetY + matrix[13]) / camera * py;

                float W = (r_y - r_w) / 2;
                float H = r_y - r_w;
                float X1 = r_x - (r_y - r_w) / 4;
                float Y1 = r_y - H / 2;
                float X2 = X1 + W;
                float Y2 = Y1 + H;

                // 绘制目标对象
                std::string s = "1";
              

                auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y1 - 45, 红色, s.c_str());




            }




        }




        if (1) {

            float closestMotorX = 0.0f;
            float closestMotorY = 0.0f;
            float closestMotorZ = 0.0f;
            float minDistance = std::numeric_limits<float>::max();
            uintptr_t closestMotorAddress = 0;

            for (int i = 0; i < 数量; i++) {
        if (strstr(data[i].类名, "lady_e_dizao") != NULL) {
            float motorX = getFloat(data[i].objcoor + 0xe0);
                    float motorY = getFloat(data[i].objcoor + 0xe8);
                    float motorZ = getFloat(data[i].objcoor + 0xe4);

                    float distance = sqrt(pow(motorX - Z.X, 2) + pow(motorY - Z.Y, 2) + pow(motorZ - Z.Z, 2));

                    if (distance < minDistance) {
                        minDistance = distance;
                        closestMotorX = motorX;
                        closestMotorY = motorY;
                        closestMotorZ = motorZ;
                  closestMotorAddress = data[i].objcoor + 0xe0; // 获取最近电机的 X 坐标地址





                        //// 定义点的偏移量
                        //const int offsets[14][3] = {
                        //    {0x7a0, 0x7a8, 0x7a4}, {0x1190, 0x1198, 0x1194}, {0x1270, 0x1278, 0x1274},
                        //    {0x1800, 0x1808, 0x1804}, {0x18e0, 0x18e8, 0x18e4}, {0x21c0, 0x21c8, 0x21c4},
                        //    {0x22a0, 0x22a8, 0x22a4}, {0x2c00, 0x2c08, 0x2c04}, {0x2c80, 0x2c88, 0x2c84},
                        //    {0x32a0, 0x32a8, 0x32a4}, {0x3380, 0x3388, 0x3384}, {0x3960, 0x3968, 0x3964},
                        //    {0x3a70, 0x3a78, 0x3a74}, {0x3c60, 0x3c68, 0x3c64}
                        //};

                        ggx1 = getFloat(data[i].objcoor + 0xe0 + 380);
                        ggy1 = getFloat(data[i].objcoor + 0xe0 + 388);
                        ggz1 = getFloat(data[i].objcoor + 0xe0 + 384);

                        ggx2 = getFloat(data[i].objcoor + 0xe0 + 392);
                        ggy2 = getFloat(data[i].objcoor + 0xe0 + 400);
                        ggz2 = getFloat(data[i].objcoor + 0xe0 + 396);

                        ggx3 = getFloat(data[i].objcoor + 0xe0 + 1728);
                        ggy3 = getFloat(data[i].objcoor + 0xe0 + 1736);
                        ggz3 = getFloat(data[i].objcoor + 0xe0 + 1732);

                        ggx4 = getFloat(data[i].objcoor + 0xe0 + 5184);
                        ggy4 = getFloat(data[i].objcoor + 0xe0 + 5192);
                        ggz4 = getFloat(data[i].objcoor + 0xe0 + 5188);

                        ggx5 = getFloat(data[i].objcoor + 0xe0 + 5392);
                        ggy5 = getFloat(data[i].objcoor + 0xe0 + 5400);
                        ggz5 = getFloat(data[i].objcoor + 0xe0 + 5396);

                        ggx6 = getFloat(data[i].objcoor + 0xe0 + 7776);
                        ggy6 = getFloat(data[i].objcoor + 0xe0 + 7784);
                        ggz6 = getFloat(data[i].objcoor + 0xe0 + 7780);

                        ggx7 = getFloat(data[i].objcoor + 0xe0 + 7984);
                        ggy7 = getFloat(data[i].objcoor + 0xe0 + 7992);
                        ggz7 = getFloat(data[i].objcoor + 0xe0 + 7988);

                        ggx8 = getFloat(data[i].objcoor + 0xe0 + 9504);
                        ggy8 = getFloat(data[i].objcoor + 0xe0 + 9512);
                        ggz8 = getFloat(data[i].objcoor + 0xe0 + 9508);

                        ggx9 = getFloat(data[i].objcoor + 0xe0 + 9712);
                        ggy9 = getFloat(data[i].objcoor + 0xe0 + 9720);
                        ggz9 = getFloat(data[i].objcoor + 0xe0 + 9716);

                        ggx10 = getFloat(data[i].objcoor + 0xe0 + 11232);
                        ggy10 = getFloat(data[i].objcoor + 0xe0 + 11240);
                        ggz10 = getFloat(data[i].objcoor + 0xe0 + 11236);

                        ggx11 = getFloat(data[i].objcoor + 0xe0 + 11440);
                        ggy11 = getFloat(data[i].objcoor + 0xe0 + 11448);
                        ggz11 = getFloat(data[i].objcoor + 0xe0 + 11444);

                        ggx12 = getFloat(data[i].objcoor + 0xe0 + 12960);
                        ggy12 = getFloat(data[i].objcoor + 0xe0 + 12968);
                        ggz12 = getFloat(data[i].objcoor + 0xe0 + 12964);

                        ggx13 = getFloat(data[i].objcoor + 0xe0 + 13168);
                        ggy13 = getFloat(data[i].objcoor + 0xe0 + 13176);
                        ggz13 = getFloat(data[i].objcoor + 0xe0 + 13172);

                        ggx14 = getFloat(data[i].objcoor + 0xe0 + 14688);
                        ggy14 = getFloat(data[i].objcoor + 0xe0 + 14696);
                        ggz14 = getFloat(data[i].objcoor + 0xe0 + 14692);



                        //// 使用 ggx1, ggz1, ggy1
                        //float camera1 = matrix[3] * ggx1 + matrix[7] * (ggz1)+matrix[11] * ggy1 + matrix[15];
                        //float distance1 = sqrt(pow(ggx1 - Z.X, 2) + pow(ggy1 - Z.Y, 2) + pow(ggz1 - Z.Z, 2)) / 距离比例;
                        //float r_x1 = px + (matrix[0] * ggx1 + matrix[4] * (ggz1) + matrix[8] * ggy1 + matrix[12]) / camera1 * px;
                        //float r_y1 = py - (matrix[1] * ggx1 + matrix[5] * (ggz1) + matrix[9] * ggy1 + matrix[13]) / camera1 * py;
                        //float r_w1 = py - (matrix[1] * ggx1 + matrix[5] * (ggz1) + matrix[9] * ggy1 + matrix[13]) / camera1 * py;

                        //float W1 = (r_y1 - r_w1) / 2;
                        //float H1 = r_y1 - r_w1;
                        //float X1_1 = r_x1 - (r_y1 - r_w1) / 4;
                        //float Y1_1 = r_y1 - H1 / 2;
                        //float X2_1 = X1_1 + W1;
                        //float Y2_1 = Y1_1 + H1;

                        //std::string s1 = std::to_string(1);
                        //auto textSize1 = ImGui::CalcTextSize(s1.c_str(), 0, 25);
                        //绘制字体描边(huizhiziti, X1_1 + W1 / 2 - (textSize1.x / 2), Y1_1, 红色, s1.c_str());

                        //// 使用 ggx2, ggz2, ggy2
                        //float camera2 = matrix[3] * ggx2 + matrix[7] * (ggz2)+matrix[11] * ggy2;// + matrix[15];
                        //float distance2 = sqrt(pow(ggx2 - Z.X, 2) + pow(ggy2 - Z.Y, 2) + pow(ggz2 - Z.Z, 2)) / 距离比例;
                        //float r_x2 = px + (matrix[0] * ggx2 + matrix[4] * (ggz2) + matrix[8] * ggy2 + matrix[12]) / camera2 * px;
                        //float r_y2 = py - (matrix[1] * ggx2 + matrix[5] * (ggz2) + matrix[9] * ggy2 + matrix[13]) / camera2 * py;
                        //float r_w2 = py - (matrix[1] * ggx2 + matrix[5] * (ggz2) + matrix[9] * ggy2 + matrix[13]) / camera2 * py;

                        //float W2 = (r_y2 - r_w2) / 2;
                        //float H2 = r_y2 - r_w2;
                        //float X1_2 = r_x2 - (r_y2 - r_w2) / 4;
                        //float Y1_2 = r_y2 - H2 / 2;
                        //float X2_2 = X1_2 + W2;
                        //float Y2_2 = Y1_2 + H2;

                        //std::string s2 = std::to_string(2);
                        //auto textSize2 = ImGui::CalcTextSize(s2.c_str(), 0, 25);
                        //绘制字体描边(huizhiziti, X1_2 + W2 / 2 - (textSize2.x / 2), Y1_2 , 红色, s2.c_str());

                        //// 使用 ggx3, ggz3, ggy3
                        //float camera3 = matrix[3] * ggx3 + matrix[7] * (ggz3)+matrix[11] * ggy3;// + matrix[15];
                        //float distance3 = sqrt(pow(ggx3 - Z.X, 2) + pow(ggy3 - Z.Y, 2) + pow(ggz3 - Z.Z, 2)) / 距离比例;
                        //float r_x3 = px + (matrix[0] * ggx3 + matrix[4] * (ggz3 ) + matrix[8] * ggy3 + matrix[12]) / camera3 * px;
                        //float r_y3 = py - (matrix[1] * ggx3 + matrix[5] * (ggz3) + matrix[9] * ggy3 + matrix[13]) / camera3 * py;
                        //float r_w3 = py - (matrix[1] * ggx3 + matrix[5] * (ggz3 ) + matrix[9] * ggy3 + matrix[13]) / camera3 * py;

                        //float W3 = (r_y3 - r_w3) / 2;
                        //float H3 = r_y3 - r_w3;
                        //float X1_3 = r_x3 - (r_y3 - r_w3) / 4;
                        //float Y1_3 = r_y3 - H3 / 2;
                        //float X2_3 = X1_3 + W3;
                        //float Y2_3 = Y1_3 + H3;

                        //std::string s3 = std::to_string(3);
                        //auto textSize3 = ImGui::CalcTextSize(s3.c_str(), 0, 25);
                        //绘制字体描边(huizhiziti, X1_3 + W3 / 2 - (textSize3.x / 2), Y1_3, 红色, s3.c_str());





                        //float targetX = ggx2;
                        //float targetZ = ggz2 - 10;
                        //float targetY = ggy2;

                        //// 计算屏幕上的位置（假设使用相同的矩阵变换）
                        //float camera = matrix[3] * targetX + matrix[7] * targetZ + matrix[11] * targetY + matrix[15];
                        //float distance = sqrt(pow(targetX - Z.X, 2) + pow(targetY - Z.Y, 2) + pow(targetZ - Z.Z, 2)) / 距离比例;
                        //float r_x = px + (matrix[0] * targetX + matrix[4] * targetZ + matrix[8] * targetY + matrix[12]) / camera * px;
                        //float r_y = py - (matrix[1] * targetX + matrix[5] * (targetZ + 8.5) + matrix[9] * targetY + matrix[13]) / camera * py;
                        //float r_w = py - (matrix[1] * targetX + matrix[5] * (targetZ + 28.5) + matrix[9] * targetY + matrix[13]) / camera * py;

                        //float W = (r_y - r_w) / 2;
                        //float H = r_y - r_w;
                        //float X1 = r_x - (r_y - r_w) / 4;
                        //float Y1 = r_y - H / 2;
                        //float X2 = X1 + W;
                        //float Y2 = Y1 + H;

                        //// 绘制目标对象
                        //std::string s = "鸡把"; // 点的编号

                        //auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 25);
                        //绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y1 - 45, 红色, s.c_str());


                    }
                }
            }




            if (closestMotorAddress != 0) {
                for (int i = 0; i < 20; i++) {
                   uintptr_t currentAddress = closestMotorAddress + 实验偏移量 + i;
                  
                    float value = getFloat(currentAddress);

                    switch (i) {
                    case 0: globalVar1 = value; break;
                    case 1: globalVar2 = value; break;
                    case 2: globalVar3 = value; break;
                    case 3: globalVar4 = value; break;
                    case 4: globalVar5 = value; break;
                    case 5: globalVar6 = value; break;
                    case 6: globalVar7 = value; break;
                    case 7: globalVar8 = value; break;
                    case 8: globalVar9 = value; break;
                    case 9: globalVar10 = value; break;
                    case 10: globalVar11 = value; break;
                    case 11: globalVar12 = value; break;
                    case 12: globalVar13 = value; break;
                    case 13: globalVar14 = value; break;
                    case 14: globalVar15 = value; break;
                    case 15: globalVar16 = value; break;
                    case 16: globalVar17 = value; break;
                    case 17: globalVar18 = value; break;
                    case 18: globalVar19 = value; break;
                    case 19: globalVar20 = value; break;
                    }
                }
            }


        }
      //捏镜绘制
        if (!mirror && 捏镜) {

            if (strstr(data[i].类名, "mirror_model_obj_001") != NULL ||
                strstr(data[i].类名, "mirror_model_obj_007") != NULL ||
                strstr(data[i].类名, "h55_guajian_rongguang") != NULL ||
                strstr(data[i].类名, "mirror_model_obj_005") != NULL ||
                strstr(data[i].类名, "mirror_model_obj_002") != NULL ||
                strstr(data[i].类名, "mirror_model_obj_003") != NULL ||
                strstr(data[i].类名, "mirror_model_obj_004") != NULL ||
                strstr(data[i].类名, "mirror_model_obj_006") != NULL ||
                strstr(data[i].类名, "redqueen_e_krm_head") != NULL)
            {
                // 获取伪镜子的 XY 坐标
                fakeMirrorX = getFloat(data[i].objcoor + 0xe0);
                fakeMirrorY = getFloat(data[i].objcoor + 0xe8);
                fakeMirrorZ = getFloat(data[i].objcoor + 0xe4);
                捏了 = true;
            }





            // 计算红夫人镜像坐标
            if (redqueenmod) {
                // 使用中点公式计算镜像坐标
                红夫人镜像X1 = 2 * fakeMirrorX - Z.X; // 红夫人镜像的 X 坐标
                红夫人镜像Y1 = 2 * fakeMirrorY - Z.Y; // 红夫人镜像的 Y 坐标
            }
            if (getFloat(data[i].obj + 0x150) == 450 && data[i].阵营 == 2) { // 阵营为2的角色
                std::string ss;

                if (redqueenmod) {
                    // 使用镜像坐标进行绘制
                    calculate_mirror_reflection(红夫人X, 红夫人Y, 红夫人镜像X1, 红夫人镜像Y1, D.X, D.Y, &xs_prime_mirror, &ys_prime_mirror);
                    calculate_line_reflection(红夫人X, 红夫人Y, 红夫人镜像X1, 红夫人镜像Y1, xs_prime_mirror, ys_prime_mirror, &D.X, &D.Y);

                    camera = matrix[3] * D.X + matrix[7] * D.Z + matrix[11] * D.Y + matrix[15];
                    距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2) + pow(D.Z - Z.Z, 2)) / 距离比例;
                    r_x = px + (matrix[0] * D.X + matrix[4] * D.Z + matrix[8] * D.Y + matrix[12]) / camera * px;
                    r_y = py - (matrix[1] * D.X + matrix[5] * (D.Z + 8.5) + matrix[9] * (D.Y) + matrix[13]) / camera * py;
                    r_w = py - (matrix[1] * D.X + matrix[5] * (D.Z + 28.5) + matrix[9] * (D.Y) + matrix[13]) / camera * py;

                    W = (r_y - r_w) / 2;   // 宽度
                    H = r_y - r_w;         // 高度
                    X1 = r_x - (r_y - r_w) / 4;   // X1
                    Y1 = r_y - H / 2;      // Y1
                    X2 = X1 + W;           // X2
                    Y2 = Y1 + H;           // Y2

                    if (W > 0) {
                        ss += data[i].str;


                        auto textSize = ImGui::CalcTextSize(ss.c_str(), 0, 25);
                        绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y1 - 45, BotBoneColor, ss.c_str());

                        if (show_draw_Rect) {
                            ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BotBoneColor, 6, 1, 1.8f, 方框样式);
                        }

                        if (show_draw_Distance) {
                            std::string 镜像距离;
                            镜像距离 += std::to_string((int)距离);
                            镜像距离 += " 米";
                            auto textSize = ImGui::CalcTextSize(镜像距离.c_str(), 0, 25);
                            绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y2 + 10, BotBoneColor, 镜像距离.c_str());
                        }

                        if (show_draw_Line) {
                            ImGui::GetForegroundDrawList()->AddLine({ px, 170 }, { X1 + W / 2, Y1 }, ImColor(255, 255, 255), 2);
                        }

                    }

                }
            }
        }

       

        /**/  //红夫人镜像                                   
        if (mirror && redqueenmod) {
            if (getFloat(data[i].obj + 0x150) == 450 && data[i].阵营 == 2) {
                std::string ss;
                calculate_mirror_reflection(红夫人X, 红夫人Y, 红夫人镜像X, 红夫人镜像Y, D.X, D.Y, &xs_prime_mirror, &ys_prime_mirror);
                calculate_line_reflection(红夫人X, 红夫人Y, 红夫人镜像X, 红夫人镜像Y, xs_prime_mirror, ys_prime_mirror, &D.X, &D.Y);
                camera = matrix[3] * D.X + matrix[7] * D.Z + matrix[11] * D.Y + matrix[15];
                距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2) + pow(D.Z - Z.Z, 2)) / 距离比例;
                r_x = px + (matrix[0] * D.X + matrix[4] * D.Z + matrix[8] * D.Y + matrix[12]) / camera * px;
                r_y = py - (matrix[1] * D.X + matrix[5] * (D.Z + 8.5) + matrix[9] * (D.Y) + matrix[13]) / camera * py;
                r_w = py - (matrix[1] * D.X + matrix[5] * (D.Z + 28.5) + matrix[9] * (D.Y) + matrix[13]) / camera * py;

                W = (r_y - r_w) / 2;	// 宽度
                H = r_y - r_w;		// 高度
                X1 = r_x - (r_y - r_w) / 4;	// X1
                Y1 = r_y - H / 2;	// Y1
                X2 = X1 + W;		// X2
                Y2 = Y1 + H;		// Y2

                if (W > 0) {

                    ss += data[i].str;
                    auto textSize = ImGui::CalcTextSize(ss.c_str(), 0, 25);
                    绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y1 - 45, BotBoneColor, ss.c_str());

                    if (show_draw_Rect) {
                        ImGui::GetForegroundDrawList()->AddRect({ X1, Y1 }, { X2, Y2 }, BotBoneColor, 6, 1, 1.8f, 方框样式);
                    }

                    if (show_draw_Distance) {
                        std::string 镜像距离;
                        镜像距离 += std::to_string((int)距离);
                        镜像距离 += " 米";
                        auto textSize = ImGui::CalcTextSize(镜像距离.c_str(), 0, 25);
                        绘制字体描边(huizhiziti, X1 + W / 2 - (textSize.x / 2), Y2 + 10, BotBoneColor, 镜像距离.c_str());
                    }

                    if (show_draw_Line) {
                        ImGui::GetForegroundDrawList()->AddLine({ px, 170 }, { X1 + W / 2, Y1 }, ImColor(255, 255, 255), 2);
                    }
                }//判断W
            }
        }//抬镜结束
    }
    show_draw_ClassName = 0;
}
// 计算立方贝塞尔曲线的坐标点
void CalculateCubicBezierPoint(float t, float startX, float startY, float controlX1, float controlY1, float controlX2, float controlY2, float endX, float endY, float& newX, float& newY) {
    float u = 1.0f - t;
    float uu = u * u;
    float uuu = uu * u;
    float tt = t * t;
    float ttt = tt * t;

    newX = uuu * startX + 3 * uu * t * controlX1 + 3 * u * tt * controlX2 + ttt * endX;
    newY = uuu * startY + 3 * uu * t * controlY1 + 3 * u * tt * controlY2 + ttt * endY;
}






// 滑动触摸线程函数
void SpiralSlide() {
    using namespace std::chrono;

    std::chrono::steady_clock::time_point startTime = steady_clock::now();
    int loopCount = 0;
    bool initialTouch = true; // 标记是否是初始触摸
    float controlX1 = (startX + endX) * 0.4f; // 第一个中间控制点
    float controlY1 = (startY + endY) * 0.4f;
    float controlX2 = (startX + endX) * 0.6f; // 第二个中间控制点
    float controlY2 = (startY + endY) * 0.6f;

    while (spiral) {
        if (loopCount < loops) {
            if (initialTouch || touchDown) {
                if (!touchDown) {
                    // 触摸按下
                    Touch::Down(startX, startY);
                    touchDown = true;
                }

                // 计算已经经过的时间
                auto currentTime = steady_clock::now();
                duration<float> elapsedTime = currentTime - startTime;
                float elapsedLoopTime = elapsedTime.count();

                // 计算本次滑动的进度
                float loopDuration = stopDuration1 / static_cast<float>(loops);
                float t = static_cast<float>(elapsedLoopTime / loopDuration);

                float newX, newY;
                CalculateCubicBezierPoint(t, startX, startY, controlX1, controlY1, controlX2, controlY2, endX, endY, newX, newY);

                Touch::Move(newX, newY);

                // 判断是否到达终点
                if (t >= 1.0f) {
                    loopCount++;
                    // 移动到终点
                    Touch::Move(endX, endY);
                    // 短暂停留
                    std::this_thread::sleep_for(milliseconds(5));
                    // 释放触摸
                    Touch::Upyuan();
                    touchDown = false;
                    initialTouch = true;

                    // 如果循环未完成，重新按下触摸
                    if (loopCount < loops) {
                        Touch::Down(startX, startY);
                        touchDown = true;
                        startTime = steady_clock::now(); // 重置计时器
                        // 调整控制点位置以优化轨迹
                        controlX1 += 0.05f * (endX - startX);
                        controlY1 += 0.05f * (endY - startY);
                        controlX2 += 0.05f * (endX - startX);
                        controlY2 += 0.05f * (endY - startY);
                    }
                }
                else {
                    initialTouch = false;
                }

                // 控制滑动速度
                std::this_thread::sleep_for(milliseconds(5)); // 维持时间间隔以确保连贯性
            }
        }
        else {
            spiral = false;
        }

        // 控制循环速度
        std::this_thread::sleep_for(milliseconds(5));
    }

    // 退出时释放触摸
    if (touchDown) {
        Touch::Upyuan();
        touchDown = false;
    }
}
void 震慑1() {
    if (触摸2) {
        // 定义距离和Z坐标的范围
        const int distanceThreshold = 5; // 5米范围
        const float zRangeLower = -66.48f;
        const float zRangeUpper = -66.49f;
        const float zZeroTolerance = 0.01f; // Z坐标等于0的容差范围

        std::unordered_map<int, bool> uniqueIndicesIn5m;
        std::unordered_map<int, bool> uniqueIndicesZZero;
        std::unordered_map<int, bool> uniqueIndicesZInRange;

        // 遍历所有对象，统计符合条件的角色
        for (int i = 0; i < 数量; i++) {
            if (data[i].阵营 == 2) { // 假设阵营2是求生者
                D.X = getFloat(data[i].objcoor + 0x50);
                D.Y = getFloat(data[i].objcoor + 0x58);
                D.Z = getFloat(data[i].objcoor + 0x54); // 假设Z坐标偏移为0x54
                距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;

                if (距离 <= distanceThreshold) { // 距离在5米范围内
                    if (objectIdMapWithSelection.find(data[i].obj) != objectIdMapWithSelection.end()) {
                        int index = objectIdMapWithSelection[data[i].obj].index1;

                        // 检查Z坐标条件
                        if (fabs(D.Z) <= zZeroTolerance) { // Z坐标等于0（在容差范围内）
                            if (uniqueIndicesZZero.find(index) == uniqueIndicesZZero.end()) {
                                uniqueIndicesZZero[index] = true;
                                uniqueIndicesIn5m[index] = true;
                            }
                        }
                        else if (D.Z >= zRangeLower && D.Z <= zRangeUpper) { // Z坐标在66.48到66.49之间
                            if (uniqueIndicesZInRange.find(index) == uniqueIndicesZInRange.end()) {
                                uniqueIndicesZInRange[index] = true;
                                uniqueIndicesIn5m[index] = true;
                            }
                        }
                    }
                }
            }
        }

        // 检查是否有至少两个符合条件的角色
        if (uniqueIndicesIn5m.size() >= 2) {
            if (!满足条件) {
                满足条件 = true;
                满足条件时间 = ImGui::GetTime();
            }
        }
        else {
            满足条件 = false;
        }

        // 检查是否满足条件且经过了延迟时间
        if (满足条件) {
            double currentTime = ImGui::GetTime();
            if (currentTime - 满足条件时间 >= 震慑延迟) {
                Touch::Up(); // 执行触摸释放操作
                满足条件 = false;
            }
        }
    }
}
//void 震慑1() {
//    if (触摸2) {
//        // Touch::Down(touchPointX2, touchPointY2);
//
//         // 定义方向范围（以自身为中心，前后左右各90度）
//        const float directionThreshold = 90.0f; // 90度范围
//
//        if (贴脸震慑) {
//            std::unordered_map<int, bool> uniqueIndices;
//            int zeroDistanceCount1 = 0;
//            float firstZeroDistanceAngle = 0.0f; // 第一个距离为0m的人的角度
//            bool firstZeroDistanceFound = false;
//
//            // 遍历所有对象，统计距离为 0m 且编号不同的阵营为 2 的角色数量
//            for (int i = 0; i < 数量; i++) {
//                if (data[i].阵营 == 2) {
//                    D.X = getFloat(data[i].objcoor + 0x50);
//                    D.Y = getFloat(data[i].objcoor + 0x58);
//                    距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
//
//                    if (距离 == 0) {
//                        if (objectIdMapWithSelection.find(data[i].obj) != objectIdMapWithSelection.end()) {
//                            int index = objectIdMapWithSelection[data[i].obj].index1;
//                            if (uniqueIndices.find(index) == uniqueIndices.end()) {
//                                uniqueIndices[index] = true;
//                                zeroDistanceCount1++;
//
//                                // 计算角度
//                                float angle = atan2(D.Y - Z.Y, D.X - Z.X) * (180.0f / M_PI);
//                                if (!firstZeroDistanceFound) {
//                                    firstZeroDistanceAngle = angle;
//                                    firstZeroDistanceFound = true;
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//
//            // 如果有两个编号不同的人物同时距离为 0m，且都在同一方向，则记录满足条件时间
//            if (zeroDistanceCount1 >= 2 && firstZeroDistanceFound) {
//                bool allInSameDirection = true;
//                for (int i = 0; i < 数量; i++) {
//                    if (data[i].阵营 == 2) {
//                        D.X = getFloat(data[i].objcoor + 0x50);
//                        D.Y = getFloat(data[i].objcoor + 0x58);
//                        距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
//
//                        if (距离 == 0) {
//                            float angle = atan2(D.Y - Z.Y, D.X - Z.X) * (180.0f / M_PI);
//                            float angleDiff = fmod(fabs(angle - firstZeroDistanceAngle), 360.0f);
//                            if (angleDiff > 180.0f) angleDiff = 360.0f - angleDiff; // 角度差最小化
//                            if (angleDiff > directionThreshold) {
//                                allInSameDirection = false;
//                                break;
//                            }
//                        }
//                    }
//                }
//
//                if (allInSameDirection) {
//                    if (!满足条件) {
//                        满足条件 = true;
//                        满足条件时间 = ImGui::GetTime();
//                    }
//                }
//                else {
//                    满足条件 = false;
//                }
//            }
//            else {
//                满足条件 = false;
//            }
//        }
//        else if (演戏震慑) {
//            std::unordered_map<int, bool> uniqueIndices1m; // 记录距离为 1m 的编号
//            std::unordered_map<int, bool> uniqueIndices2m; // 记录距离为 2m 的编号
//            bool has1m = false;
//            bool has2m = false;
//            float twoMeterAngle = 0.0f; // 距离为2m的人的角度
//
//            // 遍历所有对象，统计距离为 1m 和 2m 且编号不同的阵营为 2 的角色数量
//            for (int i = 0; i < 数量; i++) {
//                if (data[i].阵营 == 2) {
//                    D.X = getFloat(data[i].objcoor + 0x50);
//                    D.Y = getFloat(data[i].objcoor + 0x58);
//                    距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
//
//                    if (距离 == 1) {
//                        if (objectIdMapWithSelection.find(data[i].obj) != objectIdMapWithSelection.end()) {
//                            int index = objectIdMapWithSelection[data[i].obj].index1;
//                            if (uniqueIndices1m.find(index) == uniqueIndices1m.end()) {
//                                uniqueIndices1m[index] = true;
//                                has1m = true;
//                            }
//                        }
//                    }
//                    else if (距离 == 2) {
//                        if (objectIdMapWithSelection.find(data[i].obj) != objectIdMapWithSelection.end()) {
//                            int index = objectIdMapWithSelection[data[i].obj].index1;
//                            if (uniqueIndices2m.find(index) == uniqueIndices2m.end()) {
//                                uniqueIndices2m[index] = true;
//                                has2m = true;
//
//                                // 记录距离为2m的人的角度
//                                twoMeterAngle = atan2(D.Y - Z.Y, D.X - Z.X) * (180.0f / M_PI);
//                            }
//                        }
//                    }
//                }
//            }
//
//            // 如果有两个编号不同的人物，一个距离为 1m 另一个距离为 2m，且都在同一方向，则记录满足条件时间
//            if (has1m && has2m) {
//                bool allInSameDirection = true;
//                for (int i = 0; i < 数量; i++) {
//                    if (data[i].阵营 == 2) {
//                        D.X = getFloat(data[i].objcoor + 0x50);
//                        D.Y = getFloat(data[i].objcoor + 0x58);
//                        距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
//
//                        if (距离 == 1) {
//                            float angle = atan2(D.Y - Z.Y, D.X - Z.X) * (180.0f / M_PI);
//                            float angleDiff = fmod(fabs(angle - twoMeterAngle), 360.0f);
//                            if (angleDiff > 180.0f) angleDiff = 360.0f - angleDiff; // 角度差最小化
//                            if (angleDiff > directionThreshold) {
//                                allInSameDirection = false;
//                                break;
//                            }
//                        }
//                    }
//                }
//
//                if (allInSameDirection) {
//                    if (!满足条件) {
//                        满足条件 = true;
//                        满足条件时间 = ImGui::GetTime();
//                    }
//                }
//                else {
//                    满足条件 = false;
//                }
//            }
//            else {
//                满足条件 = false;
//            }
//        }
//
//        // 检查是否满足条件且经过了震慑延迟时间
//        if (满足条件) {
//            double currentTime = ImGui::GetTime();
//            if (currentTime - 满足条件时间 >= 震慑延迟) {
//                // 触摸2 = false;
//                Touch::Up();
//                满足条件 = false;
//            }
//        }
//    }
//}

void RefreshObjectCoordinates() {
    // 获取角色坐标数据并更新到 data 数组
    for (const auto& pair : objectIdMapWithSelection) {
        uintptr_t obj = pair.first;
        int i = pair.second.index1 - 1; // 假设 ObjectIdMapWithSelection 的索引与 data 数组的索引对应
        if (i >= 0 && i < 数量) {
            data[i].X = getFloat(getPtr64(obj + 0x40) + 0x50);
            data[i].Y = getFloat(getPtr64(obj + 0x40) + 0x58);

        }
    }
 

}


void 震慑2() {
    if (平a震慑) {
        // 定义距离和Z坐标的范围
        const float distanceThreshold = 5.0f; // 5米范围
        const float zRangeLower = -66.48f;
        const float zRangeUpper = -66.49f;
        const float zZeroTolerance = 0.01f; // Z坐标等于0的容差范围

        std::unordered_map<int, bool> uniqueIndicesIn5m;
        std::unordered_map<int, bool> uniqueIndicesZZero;
        std::unordered_map<int, bool> uniqueIndicesZInRange;

        // 遍历所有对象，统计符合条件的角色
        for (int i = 0; i < 数量; i++) {
            if (data[i].阵营 == 2) { // 假设阵营2是求生者
                D.X = getFloat(data[i].objcoor + 0x50);
                D.Y = getFloat(data[i].objcoor + 0x58);
                D.Z = getFloat(data[i].objcoor + 0x54); // 假设Z坐标偏移为0x54
                距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;

                if (距离 <= distanceThreshold) { // 距离在5米范围内
                    if (objectIdMapWithSelection.find(data[i].obj) != objectIdMapWithSelection.end()) {
                        int index = objectIdMapWithSelection[data[i].obj].index1;

                        // 检查Z坐标条件
                        if (fabs(D.Z) <= zZeroTolerance) { // Z坐标等于0（在容差范围内）
                            if (uniqueIndicesZZero.find(index) == uniqueIndicesZZero.end()) {
                                uniqueIndicesZZero[index] = true;
                                uniqueIndicesIn5m[index] = true;
                            }
                        }
                        else if (D.Z >= zRangeLower && D.Z <= zRangeUpper) { // Z坐标在66.48到66.49之间
                            if (uniqueIndicesZInRange.find(index) == uniqueIndicesZInRange.end()) {
                                uniqueIndicesZInRange[index] = true;
                                uniqueIndicesIn5m[index] = true;
                            }
                        }
                    }
                }
            }
        }

        // 检查是否有至少两个符合条件的角色
        if (uniqueIndicesIn5m.size() >= 2) {
            if (!满足条件1) {
                满足条件1 = true;
                满足条件时间1 = ImGui::GetTime();
            }
        }
        else {
            满足条件1 = false;
        }

        // 检查是否满足条件且经过了延迟时间
        if (满足条件1) {
            double currentTime = ImGui::GetTime();
            if (currentTime - 满足条件时间1 >= 震慑延迟1) {
                Touch::Down(touchPointX4, touchPointY4);
                usleep(1000 * 1000 / 5);
                Touch::Upyuan();
                满足条件1 = false;
            }
        }
    }
}

//void 震慑2() {
//    if (平a震慑) {
//
//
//        // 定义方向范围（以自身为中心，前后左右各90度）
//        const float directionThreshold = 90.0f; // 90度范围
//
//        if (贴脸震慑1) {
//            std::unordered_map<int, bool> uniqueIndices;
//            int zeroDistanceCount1 = 0;
//            float firstZeroDistanceAngle = 0.0f; // 第一个距离为0m的人的角度
//            bool firstZeroDistanceFound = false;
//
//            // 遍历所有对象，统计距离为 0m 且编号不同的阵营为 2 的角色数量
//            for (int i = 0; i < 数量; i++) {
//                if (data[i].阵营 == 2) {
//                    D.X = getFloat(data[i].objcoor + 0x50);
//                    D.Y = getFloat(data[i].objcoor + 0x58);
//                    距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
//
//                    if (距离 == 0) {
//                        if (objectIdMapWithSelection.find(data[i].obj) != objectIdMapWithSelection.end()) {
//                            int index = objectIdMapWithSelection[data[i].obj].index1;
//                            if (uniqueIndices.find(index) == uniqueIndices.end()) {
//                                uniqueIndices[index] = true;
//                                zeroDistanceCount1++;
//
//                                // 计算角度
//                                float angle = atan2(D.Y - Z.Y, D.X - Z.X) * (180.0f / M_PI);
//                                if (!firstZeroDistanceFound) {
//                                    firstZeroDistanceAngle = angle;
//                                    firstZeroDistanceFound = true;
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//
//            // 如果有两个编号不同的人物同时距离为 0m，且都在同一方向，则记录满足条件时间
//            if (zeroDistanceCount1 >= 2 && firstZeroDistanceFound) {
//                bool allInSameDirection = true;
//                for (int i = 0; i < 数量; i++) {
//                    if (data[i].阵营 == 2) {
//                        D.X = getFloat(data[i].objcoor + 0x50);
//                        D.Y = getFloat(data[i].objcoor + 0x58);
//                        距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
//
//                        if (距离 == 0) {
//                            float angle = atan2(D.Y - Z.Y, D.X - Z.X) * (180.0f / M_PI);
//                            float angleDiff = fmod(fabs(angle - firstZeroDistanceAngle), 360.0f);
//                            if (angleDiff > 180.0f) angleDiff = 360.0f - angleDiff; // 角度差最小化
//                            if (angleDiff > directionThreshold) {
//                                allInSameDirection = false;
//                                break;
//                            }
//                        }
//                    }
//                }
//
//                if (allInSameDirection) {
//                    if (!满足条件1) {
//                        满足条件1 = true;
//                        满足条件时间1 = ImGui::GetTime();
//                    }
//                }
//                else {
//                    满足条件1 = false;
//                }
//            }
//            else {
//                满足条件1 = false;
//            }
//        }
//        else if (演戏震慑1) {
//            std::unordered_map<int, bool> uniqueIndices1m; // 记录距离为 1m 的编号
//            std::unordered_map<int, bool> uniqueIndices2m; // 记录距离为 2m 的编号
//            bool has1m = false;
//            bool has2m = false;
//            float twoMeterAngle = 0.0f; // 距离为2m的人的角度
//
//            // 遍历所有对象，统计距离为 1m 和 2m 且编号不同的阵营为 2 的角色数量
//            for (int i = 0; i < 数量; i++) {
//                if (data[i].阵营 == 2) {
//                    D.X = getFloat(data[i].objcoor + 0x50);
//                    D.Y = getFloat(data[i].objcoor + 0x58);
//                    距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
//
//                    if (距离 == 1) {
//                        if (objectIdMapWithSelection.find(data[i].obj) != objectIdMapWithSelection.end()) {
//                            int index = objectIdMapWithSelection[data[i].obj].index1;
//                            if (uniqueIndices1m.find(index) == uniqueIndices1m.end()) {
//                                uniqueIndices1m[index] = true;
//                                has1m = true;
//                            }
//                        }
//                    }
//                    else if (距离 == 2) {
//                        if (objectIdMapWithSelection.find(data[i].obj) != objectIdMapWithSelection.end()) {
//                            int index = objectIdMapWithSelection[data[i].obj].index1;
//                            if (uniqueIndices2m.find(index) == uniqueIndices2m.end()) {
//                                uniqueIndices2m[index] = true;
//                                has2m = true;
//
//                                // 记录距离为2m的人的角度
//                                twoMeterAngle = atan2(D.Y - Z.Y, D.X - Z.X) * (180.0f / M_PI);
//                            }
//                        }
//                    }
//                }
//            }
//
//            // 如果有两个编号不同的人物，一个距离为 1m 另一个距离为 2m，且都在同一方向，则记录满足条件时间
//            if (has1m && has2m) {
//                bool allInSameDirection = true;
//                for (int i = 0; i < 数量; i++) {
//                    if (data[i].阵营 == 2) {
//                        D.X = getFloat(data[i].objcoor + 0x50);
//                        D.Y = getFloat(data[i].objcoor + 0x58);
//                        距离 = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2)) / 距离比例;
//
//                        if (距离 == 1) {
//                            float angle = atan2(D.Y - Z.Y, D.X - Z.X) * (180.0f / M_PI);
//                            float angleDiff = fmod(fabs(angle - twoMeterAngle), 360.0f);
//                            if (angleDiff > 180.0f) angleDiff = 360.0f - angleDiff; // 角度差最小化
//                            if (angleDiff > directionThreshold) {
//                                allInSameDirection = false;
//                                break;
//                            }
//                        }
//                    }
//                }
//
//                if (allInSameDirection) {
//                    if (!满足条件1) {
//                        满足条件1 = true;
//                        满足条件时间1 = ImGui::GetTime();
//                    }
//                }
//                else {
//                    满足条件1 = false;
//                }
//            }
//            else {
//                满足条件1 = false;
//            }
//        }
//
//        // 检查是否满足条件且经过了震慑延迟时间
//        if (满足条件1) {
//            double currentTime = ImGui::GetTime();
//            if (currentTime - 满足条件时间1 >= 震慑延迟1) {
//
//                Touch::Down(touchPointX4, touchPointY4);
//                usleep(1000 * 1000 / 5);
//                Touch::Upyuan();
//                满足条件1 = false;
//            }
//        }
//    }
//}
void 自动技能() {

 

    // 检查是否处于冷却时间中
    auto currentTime = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - lastTriggerTime).count();

    // 如果还在冷却时间中，直接返回，不进行任何操作
    if (elapsed < COOLDOWN_TIME_MS) {
        return;
    }
    if (显示监管距离 < 4.5) {
        // 检查武器位置Z轴是否在18-19之间
        if (武器位置Z >= 16 && 武器位置Z < 17) {
            // 触发触摸操作

                // 在目标位置执行触摸操作（添加随机偏移可防止被检测为机器人）
            Touch::Down(自动技能X + rand() % 21 - 10, 自动技能Y + rand() % 21 - 10);
            usleep(1000 * 1000 / 5);  // 保持触摸0.2秒
            Touch::Upyuan();  // 释放触摸

            // 记录本次触发的时间
            lastTriggerTime = std::chrono::steady_clock::now();

        }

    }

    if (显示监管距离 < 4.5) {
        // 检查武器位置Z轴是否在18-19之间
        if (武器位置Z >= 30 && 武器位置Z < 31) {
            // 触发触摸操作

                // 在目标位置执行触摸操作（添加随机偏移可防止被检测为机器人）
            Touch::Down(自动技能X + rand() % 21 - 10, 自动技能Y + rand() % 21 - 10);
            usleep(1000 * 1000 / 5);  // 保持触摸0.2秒
            Touch::Upyuan();  // 释放触摸

            // 记录本次触发的时间
            lastTriggerTime = std::chrono::steady_clock::now();

        }

    }


    if (显示监管距离 < 4.5) {
        // 检查武器位置Z轴是否在18-19之间
        if (武器位置Z >= 26 && 武器位置Z < 26.1) {
            // 触发触摸操作

                // 在目标位置执行触摸操作（添加随机偏移可防止被检测为机器人）
            Touch::Down(自动技能X + rand() % 21 - 10, 自动技能Y + rand() % 21 - 10);
            usleep(1000 * 1000 / 2);  // 保持触摸0.2秒
            Touch::Upyuan();  // 释放触摸

            // 记录本次触发的时间
            lastTriggerTime = std::chrono::steady_clock::now();

        }

    }








}

void draw_generator_progress_bars() {
    // 确保有发电机数据
    if (g_GeneratorState.records_display.empty()) return;



    // 遍历所有发电机记录
    for (const auto& rec : g_GeneratorState.records_display) {
        // 检查坐标数据是否有效
        if (rec.position.size() < 3) continue;

        // 提取坐标（根据您的说明，坐标顺序为x,z,y）
        float targetX = rec.position[0]; // X坐标
        float targetZ = rec.position[1]; // Z坐标
        float targetY = rec.position[2]; // Y坐标（高度）

        // 计算距离
        float distance = sqrt(pow(targetX - Z.X, 2) +
            pow(targetY - Z.Y, 2) +
            pow(targetZ - Z.Z, 2)) / 距离比例;

        // 如果距离太远则跳过（可调整阈值）
        if (distance > 100.0f) continue;

        // 计算屏幕位置（使用与目标对象相同的变换矩阵）
        float camera = matrix[3] * targetX + matrix[7] * targetZ +
            matrix[11] * targetY + matrix[15];

        // 如果物体在相机后面则跳过
        if (camera <= 0) continue;

        // 计算物体顶部和底部的屏幕Y坐标
        float r_x = px + (matrix[0] * targetX + matrix[4] * targetZ +
            matrix[8] * targetY + matrix[12]) / camera * px;
        float r_y_top = py - (matrix[1] * targetX + matrix[5] * targetZ +
            matrix[9] * targetY + matrix[13]) / camera * py;
        float r_y_bottom = py - (matrix[1] * targetX + matrix[5] * (targetZ + 20.0f) +
            matrix[9] * targetY + matrix[13]) / camera * py;

        // 计算物体高度（像素）
        float objectHeight = abs(r_y_bottom - r_y_top);

        // 如果物体太小则跳过
        if (objectHeight < 5.0f) continue;

        // 进度条参数设置
        float progressBarWidth = objectHeight * 2.0f; // 进度条宽度
        float progressBarHeight = 5.0f;               // 进度条高度
        float progressBarX = r_x - progressBarWidth / 2;
        float progressBarY = r_y_top - 15.0f;         // 在电机上方绘制

        // 进度条背景（灰色）
        ImGui::GetBackgroundDrawList()->AddRectFilled(
            ImVec2(progressBarX, progressBarY),
            ImVec2(progressBarX + progressBarWidth, progressBarY + progressBarHeight),
            IM_COL32(80, 80, 80, 180)  // 灰色背景
        );

        // 进度条前景（根据进度变色）
        float fillWidth = (progressBarWidth * rec.process) / 100.0f;
        ImU32 color;
        if (rec.process < 33) {
            color = IM_COL32(50, 255, 50, 220);  // 绿色
        }
        else if (rec.process < 66) {
            color = IM_COL32(255, 255, 50, 220); // 黄色
        }
        else {
            color = IM_COL32(255, 50, 50, 220);  // 红色
        }

        ImGui::GetBackgroundDrawList()->AddRectFilled(
            ImVec2(progressBarX, progressBarY),
            ImVec2(progressBarX + fillWidth, progressBarY + progressBarHeight),
            color
        );

        // 绘制进度文本
        std::string progressText = std::to_string(rec.process) + "%";
        auto textSize = ImGui::CalcTextSize(progressText.c_str());
        float textX = progressBarX + (progressBarWidth - textSize.x) / 2;
        float textY = progressBarY - textSize.y - 2;

        ImGui::GetBackgroundDrawList()->AddText(
            ImVec2(textX, textY),
            IM_COL32(255, 255, 255, 255),
            progressText.c_str()
        );
    }
}
void 孽蜥坠机1() {
    // 检查是否处于冷却时间中
    auto currentTime = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - lastTriggerTime).count();
    /*   if (elapsed < COOLDOWN_TIME_MS) {
           return; // 如果还在冷却时间中，直接返回，不进行任何操作
       }*/

       // 检查自身Z轴是否大于10
    if (Z.Z > 10 && 自身阵营 == 1) {
        // 遍历所有对象
        for (int i = 0; i < 数量; i++) {
            if (data[i].阵营 == 2) {  // 判断是否为阵营2（求生者）
                // 获取角色的坐标
                float objX = getFloat(data[i].objcoor + 0x50);
                float objY = getFloat(data[i].objcoor + 0x58);
                float objZ = getFloat(data[i].objcoor + 0x54);

                // 计算与自身的jvli
                float distance = sqrt(pow(objX - Z.X, 2) + pow(objY - Z.Y, 2)) / 距离比例;

                // 如果jvli小于等于判断jvli
                if (distance <= 判断距离) {
                    // 触发触摸
                    if (孽蜥坠机) {
                        // Touch::Down(孽蜥触摸点X, 孽蜥触摸点Y);
                        Touch::Down(孽蜥触摸点X + rand() % 21 - 10, 孽蜥触摸点Y + rand() % 21 - 10);
                        usleep(1000 * 1000 / 5);  // 0.2
                        Touch::Upyuan();

                        // 记录本次触发的时间
                        lastTriggerTime = std::chrono::steady_clock::now();

                        // 暂停逻辑 2 秒后再恢复正常判断
                        //   std::this_thread::sleep_for(std::chrono::milliseconds(COOLDOWN_TIME_MS));
                        break; // 触发一次后跳出循环，避免重复触发
                    }
                }
            }
        }
    }
}
//void FillGGValues(uintptr_t objcoor) {
//    int ggIndex = 1; // 初始化ggx的序号
//    float ggBaseValue = getFloat(objcoor + 0xe0); // 基准值
//    float ggBaseOffset = 0xe0; // 基准偏移量
//    int offset = 0; // 当前偏移量
//    int maxOffset = 17000; // 最大偏移量，十进制表示
//
//    while (ggIndex <= 14 && offset < maxOffset) {
//        float currentValue = getFloat(objcoor + ggBaseOffset + offset); // 当前偏移值
//        if (std::isnan(currentValue)) {
//            // 如果当前值是NaN，跳过该值
//            offset += 1;
//      
//        }
//        if (fabs(currentValue - ggBaseValue) <= 20) { // 判断是否在基准值上下20范围内
//            // 如果在范围内，赋值给相应的ggx、ggy、ggz
//            float* ggx = nullptr;
//            float* ggy = nullptr;
//            float* ggz = nullptr;
//
//            switch (ggIndex) {
//            case 1: ggx = &ggx1; ggy = &ggy1; ggz = &ggz1; break;
//            case 2: ggx = &ggx2; ggy = &ggy2; ggz = &ggz2; break;
//            case 3: ggx = &ggx3; ggy = &ggy3; ggz = &ggz3; break;
//            case 4: ggx = &ggx4; ggy = &ggy4; ggz = &ggz4; break;
//            case 5: ggx = &ggx5; ggy = &ggy5; ggz = &ggz5; break;
//            case 6: ggx = &ggx6; ggy = &ggy6; ggz = &ggz6; break;
//            case 7: ggx = &ggx7; ggy = &ggy7; ggz = &ggz7; break;
//            case 8: ggx = &ggx8; ggy = &ggy8; ggz = &ggz8; break;
//            case 9: ggx = &ggx9; ggy = &ggy9; ggz = &ggz9; break;
//            case 10: ggx = &ggx10; ggy = &ggy10; ggz = &ggz10; break;
//            case 11: ggx = &ggx11; ggy = &ggy11; ggz = &ggz11; break;
//            case 12: ggx = &ggx12; ggy = &ggy12; ggz = &ggz12; break;
//            case 13: ggx = &ggx13; ggy = &ggy13; ggz = &ggz13; break;
//            case 14: ggx = &ggx14; ggy = &ggy14; ggz = &ggz14; break;
//            }
//
//            *ggx = currentValue; // 当前值赋给ggx
//            *ggz = getFloat(objcoor + ggBaseOffset + offset + 4); // 偏移4赋给ggz
//            *ggy = getFloat(objcoor + ggBaseOffset + offset + 8); // 再偏移4赋给ggy
//
//            ggIndex++; // 序号加1
//        }
//        offset += 1; // 每次偏移1
//    }
//}
//
//// 定义一个函数来找到离你最近的满足类名的目标
//void FindClosestTargetAndFillGGValues() {
//    float minDistance = std::numeric_limits<float>::max(); // 初始化最小距离为最大值
//    float closestTargetX = 0.0f;
//    float closestTargetY = 0.0f;
//    float closestTargetZ = 0.0f;
//    uintptr_t closestTargetAddress = 0;
//
//    // 遍历 data 数组，找到离你最近的满足类名的目标
//    for (int i = 0; i < 数量; i++) {
//        if (strstr(data[i].类名, "dm65_survivor_m_bo") != NULL) {
//            float targetX = getFloat(data[i].objcoor + 0xe0);
//            float targetY = getFloat(data[i].objcoor + 0xe8);
//            float targetZ = getFloat(data[i].objcoor + 0xe4);
//
//            float distance = sqrt(pow(targetX - Z.X, 2) + pow(targetY - Z.Y, 2) + pow(targetZ - Z.Z, 2));
//
//            if (distance < minDistance) {
//                minDistance = distance;
//                closestTargetX = targetX;
//                closestTargetY = targetY;
//                closestTargetZ = targetZ;
//                closestTargetAddress = data[i].objcoor; // 获取最近目标的地址
//            }
//        }
//    }
//
//    // 如果找到了最近的目标，进行后续操作
//    if (closestTargetAddress != 0) {
//        // 打印调试信息
//        ImGui::Text("找到最近的目标: 距离=%.2f, X=%.2f, Y=%.2f, Z=%.2f", minDistance, closestTargetX, closestTargetY, closestTargetZ);
//
//        // 调用 FillGGValues 函数来填充 GG 值
//        FillGGValues(closestTargetAddress);
//    }
//    else {
//        // 没有找到目标
//        ImGui::Text("未找到满足类名的目标");
//    }
//}
// 全局调试结构
struct GeneratorDebugInfo {
    uint32_t uid;
    int progress;
    std::vector<float> worldPos;
    float camera;
    float distance;
    float screenX;
    float screenY;
    float barX;
    float barY;
    float barWidth;
    bool isVisible;
    std::string status;
};

static std::vector<GeneratorDebugInfo> g_GeneratorDebugInfos;
static bool g_ShowGeneratorDebug = true;



void 网页雷达() {


    for (const auto& pair : objectIdMapWithSelection) {
        uintptr_t obj = pair.first;
        const ObjectInfo& info = pair.second;
        int i = info.index1 - 1; // 假设 objectIdMapWithSelection 的索引与 data 数组的索引对应
        if (i >= 0 && i < 数量) {
            // 敌人的坐标
            float 敌人X = data[i].X;
            float 敌人Y = data[i].Y;

            // 敌人距离计算
            float 敌人距离 = sqrt(pow(敌人X - Z.X, 2) + pow(敌人Y - Z.Y, 2));

            // 根据角色索引设置数据
            if (i == 0) {
                lddata.room_id = 1001;
                strcpy(lddata.name, "player1");
                lddata.x = 敌人X;
                lddata.y = 敌人Y;
            }
            else if (i == 1) {
                lddata.room_id = 1001;
                strcpy(lddata.name, "player2");
                lddata.x = 敌人X;
                lddata.y = 敌人Y;
            }
            else if (i == 2) {
                lddata.room_id = 1001;
                strcpy(lddata.name, "player3");
                lddata.x = 敌人X;
                lddata.y = 敌人Y;
            }
            else if (i == 3) {
                lddata.room_id = 1001;
                strcpy(lddata.name, "player4");
                lddata.x = 敌人X;
                lddata.y = 敌人Y;
            }
        }
    }
    lddata.room_id = 1001;
    strcpy(lddata.name, "me");
    lddata.x = Z.X;
    lddata.y = Z.Y;
  /*  lddata.direction_x = 自身向量X;
    lddata.direction_y = 自身向量Y;*/
}



void Layout_tick_UI(bool* main_thread_flag) {


    //监听
  /*  int EventCount = GetEventCount();
    if (EventCount < 0) {
        printf("未找到输入设备\n");

    }

    int* fdArray = (int*)malloc(EventCount * sizeof(int));

    for (int i = 0; i < EventCount; i++) {
        char temp[128];
        sprintf(temp, "/dev/input/event%d", i);
        fdArray[i] = open(temp, O_RDWR | O_NONBLOCK);
    }

        for (int i = 0; i < EventCount; i++) {
            input_event ev;
            memset(&ev, 0, sizeof(ev));
            read(fdArray[i], &ev, sizeof(ev));
            if (ev.type == EV_KEY && ev.code == KEY_VOLUMEUP && ev.value == 1 && kang == true) {
                county++;
                if (county == 1) {
                    bool zhuangtai = false;

                }
                else if (county == 2) {

                    bool zhuangtai = false;

                    county = 0;
                }
            }
        }
        //监听*/
    px = static_cast<float>(displayInfo.width) / 2;
    py = static_cast<float>(displayInfo.height) / 2;
   //触摸在第一个函数里加载了（这个是第二（第三）个），触摸函数在这调用就行了   
    震慑1();
    震慑2();
    孽蜥坠机1();
    SpiralSlide();
    自动技能();
  
    if (天赋查看) {
        show_talent_viewer();
    }
    if (电机进度) {
        show_unified_generator_viewer();
    }

    if (网页开关) {
        网页雷达();
    }

    draw_generator_progress_bars();
 
 
    static float f = 0.0f;
    static int counter = 0;
    static int style_idx = 1;
    static int style_idx1 = 0;
    static ImVec4 clear_color = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    //这里很正常都是字面意思

    if (::permeate_record_ini) {
        ImGui::SetWindowPos({ LastCoordinate.Pos_x, LastCoordinate.Pos_y });
        ImGui::SetWindowSize({ LastCoordinate.Size_x, LastCoordinate.Size_y });
        permeate_record_ini = false;
    }
    Draw_Main(ImGui::GetForegroundDrawList());{
    static int 𝗜𝗠𝗚𝗨𝗜_𝗚𝗢𝗗 = 1;
    static int 𝗜𝗠𝗚𝗨𝗜_𝗚𝗢𝗗_𝗦𝗨𝗕𝗧𝗔𝗕 = 1;

    ImGuiStyle& style = ImGui::GetStyle();
    if (悬浮球)
    {
        /*   ImGui::SetNextWindowSize({120, 120});

           style.Colors[ImGuiCol_WindowBg].w = 0;
           if (ImGui::Begin("悬浮图片", &悬浮球, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar))
           {




             if (窗口状态) {
               ImGui::SetWindowPos(Pos);
               窗口状态 = false;
             }
             Pos = ImGui::GetWindowPos();
             ImDrawList* Draw = ImGui::GetWindowDrawList();

             DrawLogo(Pos.x + 62, Pos.y + 52, 60.f);


             static bool isDragging = false;
             if (ImGui::IsMouseDragging(0) && ImGui::IsWindowHovered())
             {
               isDragging = true;
             }
             if (ImGui::IsMouseReleased(0) && !ImGui::IsMouseDragging(0) && !isDragging && ImGui::IsWindowHovered())
             {
               悬浮球 = false;
               悬浮窗 = true;
               窗口状态 = true;
             }
             if (!ImGui::IsMouseDragging(0))
             {
               isDragging = false;
             }

           }
           ImGui::End();*/
    }
    style.Colors[ImGuiCol_WindowBg].w = 1;
    // style.Alpha = 1.f;
                  /* if (ImGui::Begin(OBFUSCATE("IMGUI_GOD LOGIN" ), nullptr,ImGuiWindowFlags_AlwaysAutoResize |  ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoSavedSettings)) {
                   static bool isLogin = false;
                   if (!isLogin) {
                   const ImVec2 pos = ImGui::GetWindowPos();
                   ImDrawList* draw = ImGui::GetWindowDrawList();
                   draw->AddRectFilled(ImVec2(pos.x + 8, pos.y + 8), ImVec2(pos.x + 492, pos.y + 552), ImColor(0, 0, 0,255), 10.f,ImDrawFlags_RoundCornersBottomLeft | ImDrawFlags_RoundCornersTopLeft | ImDrawFlags_RoundCornersBottomRight | ImDrawFlags_RoundCornersTopRight);
                   draw->AddRectFilled(ImVec2(pos.x + 13, pos.y + 13), ImVec2(pos.x + 487, pos.y + 547), ImColor(40, 40, 40, 255), 8.5f,ImDrawFlags_RoundCornersBottomLeft | ImDrawFlags_RoundCornersTopLeft | ImDrawFlags_RoundCornersBottomRight | ImDrawFlags_RoundCornersTopRight);
                   draw->AddRectFilled(ImVec2(pos.x + 30, pos.y + 160), ImVec2(pos.x + 470, pos.y + 220), ImColor(0, 0, 0, 255), 10.f,ImDrawFlags_RoundCornersBottomLeft | ImDrawFlags_RoundCornersTopLeft | ImDrawFlags_RoundCornersBottomRight | ImDrawFlags_RoundCornersTopRight);
                   draw->AddText(F50, 40.f, ImVec2(pos.x + 55, pos.y + 50), ImColor(255, 255, 255, 255), oxorany("WIDGETS EXPERT"));
                   ImGui::SetCursorPos(ImVec2(70, 174));
                   ImGui::InputTextWithHint("##key","YOUR KEY.........", s, sizeof s);
                   ImGui::SetCursorPos(ImVec2(30, 235));
                   if(ImGui::OptButton1("     PASTE YOUR KEY   ", ImVec2(440, 60), false)){
                   }
                   ImGui::SetCursorPos(ImVec2(100, 315));
                   static std::string err;
                   if (ImGui::OptButton1(" LOGIN", ImVec2(300, 60), false)) {
                   isLogin = true;
                   }
                   } else{*/

                   //===============================================| 𝗙𝗟𝗢𝗧𝗜𝗡𝗚 𝗟𝗢𝗚𝗢  |======================≠=================//
                                       /*static bool show;
                                       ImGui::SetNextWindowSize({ 200, 200 });
                                       ImGui::Begin("ICON BUTTON", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoBringToFrontOnFocus);
                                       //ImGui::Begin("ICON BUTTON", nullptr, ImGuiWindowFlags_NoDecoration); {
                                       const ImVec2 pos = ImGui::GetWindowPos();
                                       ImDrawList* draw = ImGui::GetWindowDrawList();
                                       draw->AddRectFilled(ImVec2(pos.x + 50, pos.y + 50), ImVec2(pos.x + 150, pos.y + 150), ImColor(230, 233, 238, 255), 10.f,ImDrawFlags_RoundCornersAll );
                                       draw->AddText(F50, 35.f, ImVec2(70 + pos.x, 70 + pos.y), ImColor(41, 44, 49, 255), oxorany("GM"));
                                       draw->AddText(Subtab, 20.f, ImVec2(46 + pos.x, 106 + pos.y), ImColor(0, 0, 255, 255), oxorany("    GTX"));
                                       draw->AddText(Subtab, 20.f, ImVec2(46 + pos.x, 106 + pos.y), ImColor(41, 44, 49, 255), oxorany("              MOD"));
                                       ImGui::SetCursorPos({ 70, 70});
                                       if(ImGui::WIDGETS_EXPERT_Open("         ", ImVec2(60, 60), false)){
                                       show = true;
                                       }*/
                                       //===================================| 𝗠𝗔𝗜𝗡 𝗜𝗠𝗚𝗨𝗜 𝗠𝗘𝗡𝗨 |≠=======================//
 
    
    if (悬浮窗) {
        ImGuiIO& io = ImGui::GetIO();
        io.FontGlobalScale = 1.3f;
        style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
        ImGui::Begin("Riley", main_thread_flag);
        ApplyPinkTheme();
        // ====================== 系统状态区 ======================
        {
            ImGui::Text("Riley 系统状态");
            ImGui::Separator();

            // 时间显示
            std::time_t now = std::time(nullptr);
            char timeBuffer[80];
            std::strftime(timeBuffer, sizeof(timeBuffer), "%Y-%m-%d %H:%M:%S", std::localtime(&now));
            ImGui::Text("当前时间：%s", timeBuffer);

            // 实验参数
           

            // 偏移量控制
           
        }

        // ====================== 系统控制区 ======================
        {
            ImGui::Separator();
            ImGui::Text("系统控制");
            ImGui::Separator();

            // 配置管理
            if (ImGui::Button("保存配置", { 150, 40 })) SaveConfig(filename);
            ImGui::SameLine();
            if (ImGui::Button("加载配置", { 150, 40 })) LoadConfig(filename);
            ImGui::SameLine();
            if (ImGui::Button("退出程序", { 150, 40 })) exit(1);

            // 模式切换
            ImGui::SameLine();
            ImGui::RadioButton("悬浮控制", &音量键, 0);
            ImGui::SameLine();
            ImGui::RadioButton("捏镜控制", &音量键, 1);

            // 基础开关组
            ImGui::Checkbox("主播模式", &::permeate_record);  ImGui::SameLine();
            ImGui::Checkbox("必看标记", &必看);              ImGui::SameLine();
            ImGui::Checkbox("触摸定位", &触摸位置);          ImGui::SameLine();
            ImGui::Checkbox("网页开关", &网页开关);          ImGui::SameLine();
            ImGui::Checkbox("边框显示", &方框样式);          ImGui::SameLine();
            ImGui::Checkbox("地图窗口", &地图窗口);
        }

        // ====================== 数据状态区 ======================
        {
            ImGui::Separator();
            ImGui::Text("数据连接状态");
            ImGui::Separator();

            ImGui::Text("状态: "); ImGui::SameLine();
            if (状态 == 2) ImGui::TextColored(ImVec4(0, 205, 0, 1), "已连接");
            else if (状态 == 1) ImGui::TextColored(ImVec4(255, 0, 0, 1), "连接中");

            // 数据状态快捷开关
            if (ImGui::CollapsingHeader("功能快捷开关")) {
                ImGui::Checkbox("快速绘制", &快捷);          ImGui::SameLine();
                ImGui::Checkbox("计时功能", &jishi);          ImGui::SameLine();
                ImGui::Checkbox("关闭绘制", &关绘制);        ImGui::SameLine();
                ImGui::Checkbox("模仿模式", &编号);

                ImGui::Checkbox("传伞功能", &宿伞);          ImGui::SameLine();
                ImGui::Checkbox("孽蜥坠机", &孽蜥坠机);      ImGui::SameLine();
                ImGui::Checkbox("孽蜥开关", &孽蜥开关);      ImGui::SameLine();
                ImGui::Checkbox("拉锯震慑", &拉锯震慑);

                ImGui::Checkbox("平A震慑", &平a震慑);        ImGui::SameLine();
                if (ImGui::Button("状态切换", { 100, 30 })) { 实体 = !实体; 视角 = !视角; }
                ImGui::SameLine();
                ImGui::Text("%s", (实体 ? "实体模式" : (视角 ? "视角模式" : "未激活")));

                ImGui::Checkbox("监管距离", &监管距离);      ImGui::SameLine();
                ImGui::Checkbox("鹿头辅助", &鹿头辅助线);    ImGui::SameLine();
                ImGui::Checkbox("捏镜绘制", &捏镜快捷);
            }
        }

        // ====================== 战斗功能区 ======================
        {
            ImGui::Separator();
            if (ImGui::CollapsingHeader("战斗辅助功能", ImGuiTreeNodeFlags_DefaultOpen)) {
                // 震慑功能组
                if (ImGui::CollapsingHeader("震慑系统")) {
                    // 拉锯震慑
                    if (ImGui::CollapsingHeader("拉锯震慑设置")) {
                        if (ImGui::Button("归位", { 100, 30 })) ResetConfig5();
                        ImGui::SameLine();
                        if (ImGui::Button("贴脸震慑", { 120, 30 })) { 贴脸震慑 = true; 演戏震慑 = false; }
                        ImGui::SameLine();
                        if (ImGui::Button("演戏震慑", { 120, 30 })) { 贴脸震慑 = false; 演戏震慑 = true; }
                        ImGui::Text("当前状态: %s", (贴脸震慑 ? "贴脸震慑" : (演戏震慑 ? "演戏震慑" : "未激活")));
                        ImGui::SliderFloat("震慑延迟(秒)", &震慑延迟, 0, 0.8f, "%.2f");
                        ImGui::SliderFloat("触摸点X", &touchPointX2, 0, py * 2, "%.1f");
                        ImGui::SliderFloat("触摸点Y", &touchPointY2, 0, px * 2, "%.1f");
                    }

                    // 普攻震慑
                    if (ImGui::CollapsingHeader("普攻震慑设置")) {
                        if (ImGui::Button("归位", { 100, 30 })) ResetConfig7();
                        ImGui::SameLine();
                        if (ImGui::Button("贴脸震慑", { 120, 30 })) { 贴脸震慑1 = true; 演戏震慑1 = false; }
                        ImGui::SameLine();
                        if (ImGui::Button("演戏震慑", { 120, 30 })) { 贴脸震慑1 = false; 演戏震慑1 = true; }
                        ImGui::Text("当前状态: %s", (贴脸震慑1 ? "贴脸震慑" : (演戏震慑1 ? "演戏震慑" : "未激活")));
                        ImGui::SliderFloat("震慑延迟(秒)", &震慑延迟1, 0, 0.8f, "%.2f");
                        ImGui::SliderFloat("触摸点X", &touchPointX4, 0, py * 2, "%.1f");
                        ImGui::SliderFloat("触摸点Y", &touchPointY4, 0, px * 2, "%.1f");
                    }
                }

                // 角色专属功能
                if (ImGui::CollapsingHeader("角色专属功能")) {
                    // 孽蜥坠机
                    if (ImGui::CollapsingHeader("孽蜥坠机控制")) {
                        ImGui::Text("自身高度: %f", Z.Z);
                        if (ImGui::Button("归位", { 100, 30 })) ResetConfig6();
                        ImGui::SliderFloat("触发距离(m)", &判断距离, 1, 10, "%.1f");
                        ImGui::SliderFloat("触摸点X", &孽蜥触摸点X, 0, py * 2, "%.1f");
                        ImGui::SliderFloat("触摸点Y", &孽蜥触摸点Y, 0, px * 2, "%.1f");
                    }

                    // 自动飞轮
                    if (ImGui::CollapsingHeader("自动飞轮设置")) {
                        if (ImGui::Button("归位", { 100, 30 })) ResetConfig11();
                        ImGui::SliderFloat("触发距离(m)", &判断距离, 1, 10, "%.1f");
                        ImGui::SliderFloat("飞轮X", &自动技能X, 0, py * 2, "%.1f");
                        ImGui::SliderFloat("飞轮Y", &自动技能Y, 0, px * 2, "%.1f");
                    }

                    // 传伞功能
                    if (ImGui::CollapsingHeader("传伞功能设置")) {
                        if (ImGui::Button("归位", { 100, 30 })) { subWindowPosX = 1929.529f; subWindowPosY = 573.499f; }
                        ImGui::SliderFloat("字体大小", &sanjuli, 30, 200, "%.1f");
                        ImGui::SliderFloat("传伞速度", &incrementInterval, 0.05f, 0.06f, "%.3f");
                        ImGui::SliderFloat("X位置", &subWindowPosX, 0, 4000, "%.1f");
                        ImGui::SliderFloat("Y位置", &subWindowPosY, 0, 4000, "%.1f");
                    }
                }
            }
        }

        // ====================== 绘制功能区 ======================
        {
            ImGui::Separator();
            if (ImGui::CollapsingHeader("绘制显示系统", ImGuiTreeNodeFlags_DefaultOpen)) {
                // 绘制总开关
                ImGui::Text("绘制总开关");
                ImGui::Checkbox("方框绘制", &show_draw_Rect);      ImGui::SameLine();
                ImGui::Checkbox("射线绘制", &show_draw_Line);      ImGui::SameLine();
                ImGui::Checkbox("道具显示", &show_draw_Prop);      ImGui::SameLine();
                ImGui::Checkbox("柜子显示", &show_draw_GUIZI);      ImGui::SameLine();
                ImGui::Checkbox("类名显示", &Debugging);            ImGui::SameLine();
                ImGui::Checkbox("监管绘制", &furen);

                // 绘制样式设置
                ImGui::SameLine();
                ImGui::Checkbox("平板模式", &平板);
                ImGui::SliderFloat("字体大小", &huizhiziti, 20, 200, "%.1f");
                ImGui::ColorEdit3("监管颜色", (float*)&监管颜色);
                ImGui::ColorEdit3("求生颜色", (float*)&求生颜色);
                if (ImGui::Button("截图", { 120, 30 })) system("su -c screencap -p /sdcard/Riley截屏.jpg");

                // 绘制内容设置
                if (ImGui::CollapsingHeader("绘制内容设置")) {
                    ImGui::Checkbox("相机显示", &show_draw_Camera);    ImGui::SameLine();
                    ImGui::Checkbox("大门显示", &show_draw_Door);      ImGui::SameLine();
                    ImGui::Checkbox("箱子显示", &show_draw_Box);       ImGui::SameLine();
                    ImGui::Checkbox("地窖显示", &show_draw_Cellar);     ImGui::SameLine();
                    ImGui::Checkbox("板子显示", &show_draw_BANZI);      ImGui::SameLine();
                    ImGui::Checkbox("电机显示", &show_draw_DIANJI);      ImGui::SameLine();
                    ImGui::Checkbox("椅子显示", &show_draw_Chair);      ImGui::SameLine();
                    ImGui::Checkbox("监管预知", &show_draw_prophet);

                    ImGui::Checkbox("夫人模式", &redqueenmod);          ImGui::SameLine();
                    ImGui::Checkbox("蝴蝶显示", &蝴蝶);                  ImGui::SameLine();
                    ImGui::Checkbox("平板椅子", &平板椅);                ImGui::SameLine();
                    ImGui::Checkbox("平板电机", &平板机);
                }

                // 绘制距离设置
                if (ImGui::CollapsingHeader("绘制距离设置")) {
                    ImGui::Text("距离大于设置值时不绘制");
                    ImGui::SliderInt("箱子距离", &zuida4, 1, 100);
                    ImGui::SliderInt("圣诞箱距离", &zuida5, 1, 100);
                    ImGui::SliderInt("摄影机距离", &zuida6, 1, 100);
                    ImGui::SliderInt("板子距离", &zuida, 1, 100);
                    ImGui::SliderInt("电机距离", &zuida2, 20, 150);
                    ImGui::SliderInt("椅子距离", &zuida3, 1, 100);
                    ImGui::SliderInt("柜子距离", &zuida7, 1, 100);
                }

                // 模式一键切换
                ImGui::Separator();
                ImGui::Text("一键切换模式");
                if (ImGui::Button("求生模式", { 150, 40 })) {
                    show_draw_Rect = true; show_draw_Line = false; show_draw_Distance = true;
                    show_draw_Door = true; show_draw_Cellar = true; show_draw_Camera = false;
                    show_draw_Name = true; show_draw_Box = false; show_draw_BANZI = true;
                    show_draw_DIANJI = true; show_draw_Chair = false; show_draw_Prop = false;
                    show_draw_GUIZI = false; show_draw_prophet = true;
                    监管距离 = true; furen = true; redqueenmod = false;
                    狗眼 = true; 被打预警 = true;
                }
                ImGui::SameLine();
                if (ImGui::Button("监管模式", { 150, 40 })) {
                    show_draw_Rect = true; show_draw_Line = false; show_draw_Distance = true;
                    show_draw_Door = false; show_draw_Cellar = true; show_draw_Camera = true;
                    show_draw_Name = true; show_draw_Box = false; show_draw_BANZI = false;
                    show_draw_DIANJI = false; show_draw_Chair = true; show_draw_Prop = true;
                    show_draw_GUIZI = false; show_draw_prophet = false;
                    监管距离 = false; furen = false; redqueenmod = true;
                    被打预警 = false;
                }
                ImGui::SameLine();
                if (ImGui::Button("重置绘制", { 150, 40 })) {
                    show_draw_BANZI = true; show_draw_DIANJI = true;
                    show_draw_Chair = true; show_draw_GUIZI = true; show_draw_Box = true;
                }
            }
        }

        // ====================== 辅助功能区 ======================
        {
            ImGui::Separator();
            if (ImGui::CollapsingHeader("高级辅助功能", ImGuiTreeNodeFlags_DefaultOpen)) {
              /*  // 鹿头辅助线
                if (ImGui::CollapsingHeader("鹿头辅助线设置")) {
                    if (ImGui::Button("归位", { 100, 30 })) ResetConfig4();
                    ImGui::SliderFloat("交叉点X", &crossPointX, 0, 4000, "%.1f");
                    ImGui::SliderFloat("交叉点Y", &crossPointY, 0, 2000, "%.1f");
                    ImGui::SliderFloat("线长度", &lineLength, 50, 1000, "%.1f");
                    ImGui::SliderFloat("开合角度(°)", &openAngle, 0, 180, "%.1f");
                    ImGui::SliderFloat("旋转角度(°)", &rotateAngle, 0, 360, "%.1f");
                }
                */
                // 无敌螺旋鞭
               /* if (ImGui::CollapsingHeader("螺旋鞭设置")) {
                    if (ImGui::Button("归位", { 100, 30 })) ResetConfig8();
                    ImGui::SliderFloat("起点X", &startX, 0, displayInfo.width, "%.1f");
                    ImGui::SliderFloat("起点Y", &startY, 0, displayInfo.height, "%.1f");
                    ImGui::SliderFloat("终点X", &endX, 0, displayInfo.width, "%.1f");
                    ImGui::SliderFloat("终点Y", &endY, 0, displayInfo.height, "%.1f");
                    ImGui::SliderFloat("滑动时间(s)", &stopDuration1, 0.1, 3, "%.2f");
                    ImGui::SliderInt("滑动速度", &loops, 0, 30);
                }
                */
                // 盖板模式
                if (ImGui::CollapsingHeader("盖板模式设置")) {
                    ImGui::Checkbox("盖板开关", &show_draw_touch);
                    ImGui::SameLine();
                    if (ImGui::Combo("归位模式", &style_idx1, "暴力\0正常\0演戏\0")) {
                    switch (style_idx1) { case 0: ResetConfig2(); break; case 1: ResetConfig1(); break; case 2: ResetConfig3(); }
                    }
                    ImGui::Text("盖板参数设置");
                    ImGui::SliderFloat("触发范围", &盖板触发范围, 1, 50, "%.0f");
                    ImGui::SliderFloat("板子范围X", &板子范围X, 1, 30, "%.1f");
                    ImGui::SliderFloat("板子范围Y", &板子范围Y, 1, 30, "%.1f");
                    ImGui::SliderFloat("触摸点X", &触摸点X, 0, px * 2, "%.1f");
                    ImGui::SliderFloat("触摸点Y", &触摸点Y, 0, py * 2, "%.1f");
                }

                // 模仿者编号编辑
                if (ImGui::CollapsingHeader("模仿者编号编辑")) {
                    ImGui::BeginChild("编号列表", ImVec2(0, 180), true);
                    ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarSize, 15);

                    static ObjectInfo* selectedInfo = nullptr;
                    for (auto& pair : objectIdMapWithSelection) {
                        uintptr_t obj = pair.first;
                        ObjectInfo& info = pair.second;
                        ImGui::PushID(obj);
                        bool is_selected = ImGui::Selectable(std::to_string(info.index1).c_str(), &info.selected);
                        if (is_selected) {
                            selectedInfo = &info;
                            for (auto& otherPair : objectIdMapWithSelection)
                                if (&otherPair.second != &info) otherPair.second.selected = false;
                        }
                        ImGui::PopID();
                    }

                    ImGui::EndChild();
                    ImGui::PopStyleVar();

                    if (ImGui::Button("+1", { 100, 30 })) { if (selectedInfo) selectedInfo->index1++; }
                    ImGui::SameLine();
                    if (ImGui::Button("-1", { 100, 30 })) { if (selectedInfo && selectedInfo->index1 > 1) selectedInfo->index1--; }
                    ImGui::SameLine();
                    if (ImGui::Button("-10", { 100, 30 })) {
                        for (auto& pair : objectIdMapWithSelection)
                            pair.second.index1 = (pair.second.index1 > 10) ? (pair.second.index1 - 10) : 1;
                    }
                    ImGui::SameLine();
                    if (ImGui::Button("等差加", { 100, 30 })) {
                        int inc = 0;
                        for (auto& pair : objectIdMapWithSelection)
                            pair.second.index1 += inc++;
                    }
                }
            }
        }

        // ====================== 界面主题设置 ======================
      
        g_window = ImGui::GetCurrentWindow();
        ImGui::End();
    }
 
    if (地图窗口) {

        static const float MAP_WIDTH = 800.0f * 1.5f;  // 原来的宽度乘以1.5
        static const float MAP_HEIGHT = 600.0f * 1.5f; // 原来的高度乘以1.5
        static float rotation = 0.0f;
        static float scale = 0.5f;
        static float mapOffsetX = 0.0f;     // 地图偏移 X
        static float mapOffsetY = 0.0f;     // 地图偏移 Y
        static float iconSize = 5.0f;       // 编号和圆的大小

        // 刷新角色坐标数据
        RefreshObjectCoordinates();

        ImGui::Begin("人物地图", NULL, ImGuiWindowFlags_NoResize);

        // 绘制地图背景
        ImGui::GetForegroundDrawList()->AddRect(
            ImVec2(0 + mapOffsetX, 0 + mapOffsetY),
            ImVec2(MAP_WIDTH + mapOffsetX, MAP_HEIGHT + mapOffsetY),
            IM_COL32(0, 0, 0, 255),
            0.0f, 0, 1.0f
        );

        // 获取世界坐标范围
        float min_x = std::numeric_limits<float>::max();
        float max_x = std::numeric_limits<float>::lowest();
        float min_y = std::numeric_limits<float>::max();
        float max_y = std::numeric_limits<float>::lowest();

        for (const auto& pair : objectIdMapWithSelection) {
            uintptr_t obj = pair.first;
            const ObjectInfo& info = pair.second;
            int i = info.index1 - 1; // 假设 ObjectIdMapWithSelection 的索引与 data 数组的索引对应
            if (i >= 0 && i < 数量) {
                float x = data[i].X;
                float y = data[i].Y;
                min_x = std::min(min_x, x);
                max_x = std::max(max_x, x);
                min_y = std::min(min_y, y);
                max_y = std::max(max_y, y);
            }
        }

        float world_width = max_x - min_x;
        float world_height = max_y - min_y;

        // 绘制角色坐标
        for (const auto& pair : objectIdMapWithSelection) {
            uintptr_t obj = pair.first;
            const ObjectInfo& info = pair.second;
            int i = info.index1 - 1; // 假设 ObjectIdMapWithSelection 的索引与 data 数组的索引对应
            if (i >= 0 && i < 数量) {



                float x = data[i].X;//996
                float y = data[i].Y;//每一个敌人（求生者）的坐标
                data[i].角度值 = atan2(y - Z.Y, x - Z.X) * (180.0f / M_PI);
                data[i].距离= sqrt(pow(x - Z.X, 2) + pow(y - Z.Y, 2)) / 距离比例;
 //Z.X
 //                  Z.Y//自身坐标
 //                  自身向量X
 //                  自身向量Y
            //   雷达角度1 = data[i].角度值;    
                  // 创建上传线程
             
              

             
             
                ImVec2 screen_pos;
                screen_pos.x = (x - min_x) / world_width * MAP_WIDTH;
                screen_pos.y = (y - min_y) / world_height * MAP_HEIGHT;

                ImVec2 rotated_pos = screen_pos;
                rotated_pos.x = cos(rotation) * (screen_pos.x - MAP_WIDTH * 0.5f) - sin(rotation) * (screen_pos.y - MAP_HEIGHT * 0.5f) + MAP_WIDTH * 0.5f;
                rotated_pos.y = sin(rotation) * (screen_pos.x - MAP_WIDTH * 0.5f) + cos(rotation) * (screen_pos.y - MAP_HEIGHT * 0.5f) + MAP_HEIGHT * 0.5f;

                ImVec2 scaled_pos;
                scaled_pos.x = rotated_pos.x * scale + (MAP_WIDTH - (MAP_WIDTH * scale)) * 0.5f + mapOffsetX;
                scaled_pos.y = rotated_pos.y * scale + (MAP_HEIGHT - (MAP_HEIGHT * scale)) * 0.5f + mapOffsetY;

                std::string index_str = std::to_string(info.index1);
                ImColor color;

                if (data[i].阵营 == 1) {
                    color = ImColor(255, 0, 0, 255); // 监管者颜色为红色
                }
                else {
                    color = ImColor(0, 255, 0, 255); // 求生者颜色为绿色
                }

                // 绘制圆点
                ImGui::GetForegroundDrawList()->AddCircleFilled(scaled_pos, iconSize, ImColor(255, 255, 0, 255));

                // 绘制编号文本
                绘制字体描边(bianhaodaxiao, scaled_pos.x, scaled_pos.y, color, index_str.c_str());
            }
        }

        // 控制地图旋转
        if (ImGui::IsWindowHovered() && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
            ImVec2 delta = ImGui::GetIO().MouseDelta;
            rotation += delta.x * 0.01f;
        }

        // 控制地图缩放
        ImGui::SliderFloat("缩放比例", &scale, 0.1f, 3.0f, "%.1f");

        // 控制地图位置
        ImGui::SliderFloat("地图 X", &mapOffsetX, -MAP_WIDTH, MAP_WIDTH);
        ImGui::SliderFloat("地图 Y", &mapOffsetY, -MAP_HEIGHT, MAP_HEIGHT);

        // 控制编号和圆的大小
        ImGui::SliderFloat("编号大小", &bianhaodaxiao, 1.0f, 50.0f, "%.1f");

        ImGui::End();
    }




    if (jishi) {
        ImGui::Begin("计时器");
        ApplyPinkTheme();
        static bool is_counting = false;  // 是否正在计时
        static int elapsed_time = 0;     // 已经经过的时间，以秒为单位
        static float accumulated_time = 0.0f;  // 累计的时间，用于精确计时，以秒为单位

        // 开始/暂停按钮
        if (ImGui::Button(is_counting ? "暂停" : "开始", { 150, 70 })) {
            is_counting = !is_counting;
        }
        ImGui::SameLine();
        // 重置按钮
        if (ImGui::Button("重置", { 150, 70 })) {
            is_counting = false;
            elapsed_time = 0;
            accumulated_time = 0.0f;
        }

        // 每次渲染时更新计时器
        if (is_counting) {
            accumulated_time += ImGui::GetIO().DeltaTime;  // 累加时间差
            if (accumulated_time >= 1.0f) {  // 当累计时间超过 1 秒时，秒数加 1
                elapsed_time++;
                accumulated_time -= 1.0f;  // 扣除 1 秒
            }
        }

        // 显示经过的时间
        ImGui::Text("经过时间: %d 秒", elapsed_time);

        ImGui::End();
    }

    if (捏镜快捷) {

        ImGui::Begin(" ");
        ApplyPinkTheme();
        const char* statusText3 = 捏镜 ? "开" : "关";
        ImGui::Text("当前状态: %s", statusText3);
        if (ImGui::Button("开/关", { 150,150 })) {
            捏镜 = !捏镜;
        }
        ImGui::End();


    }
    if (螺旋窗口) {
        ImGui::Begin("螺旋鞭");
        ApplyPinkTheme();
        if (ImGui::Button("开启", { 200, 200 })) {

            spiral = !spiral;
        }


        ImGui::End();

    }
    if (关绘制) {
        ImGui::Begin("关绘制");
        ApplyPinkTheme();

        // 添加一个按钮，当点击时切换show_draw_Chair、show_draw_Box和show_draw_DIANJI的状态
        if (ImGui::Button("点", { 150,70 }))
        {
            绘制 = !绘制;
            show_draw_Rect = !show_draw_Rect;
            show_draw_Line = !show_draw_Line;
            show_draw_Name = !show_draw_Name;
        }
        // 结束ImGui窗口
        ImGui::End();
    }
    if (必看) {

        ImGui::Begin("必看");
        ApplyPinkTheme();
        ImGui::Text("本程序仅供学习参考使用，禁止用于任何商业行为，出现任何问题与本人无关");
        ImGui::Text("此程序作者未知，睡一觉醒来就出现个这个程序");
        ImGui::Text("不认真看教程以及更新日志说明，就问问题或说用不了的");
        ImGui::Text("，建议补充维生素E。。。。");
        ImGui::Text("所有触摸均为横屏调整，横屏归位");
        ImGui::Text("震慑的延迟建议自己测一下。。。");
        ImGui::Text("捏镜子要有效果状态应为视角");
        ImGui::Text("如果没效果（或不对），先试着重启手机/换个驱动，不行的话就把游戏删了重下，");
        ImGui::Text("可能是因为游戏版本太老了");
        ImGui::Text("如果你看了这个那么你有资格问我问题了，问问题时在末尾加上321");
        ImGui::Text("只有这样我才会回答你的问题，因为你看了说明还不懂，那就是我的问题");
        ImGui::Text("转圈为白色，震慑为红色，盖板为蓝色");
        ImGui::Text("tg频道rvzqeemem(每个前移3)仅供交流学习");
        ImGui::Text("有些地图的椅子跟电机不绘制，需打开椅子绘制再打开平板椅，这样子");
        ImGui::Text("认真看说明以及更新日志，没有废话的");
        ImGui::Text("本程序仅供学习参考使用，出现任何问题与本人无关");
        ImGui::End();


    }
    if (参考数据) {
        ImGui::Begin("参考数据");
        ApplyPinkTheme();
        ImGui::Text("救人速度最快0.27秒（可以更快，但实战不好实现），最慢2s");
        ImGui::Text("1.宿伞之魂【白】0.82秒");
        ImGui::Text("2.博士0.76秒");
        ImGui::Text("3.红夫人0.59秒");
        ImGui::Text("4.使徒0.57秒");
        ImGui::Text("5.雕刻家0.55秒");
        ImGui::Text("6.摄影师0.5秒");
        ImGui::Text("6.蜡像师0.5秒");
        ImGui::Text("7.黄衣之主0.48秒");
        ImGui::Text("8.疯眼0.47秒");
        ImGui::Text("8.杰克0.47秒");
        ImGui::Text("9.孽蜥0.45秒");
        ImGui::Text("10.破轮0.43秒");
        ImGui::Text("10.红蝶0.43秒");
        ImGui::Text("11.记录员0.41秒");
        ImGui::Text("11.小提琴家0.41秒");
        ImGui::Text("12.隐士0.4秒");
        ImGui::Text("12.梦之女巫0.4秒");
        ImGui::Text("13.愚人金0.39秒");
        ImGui::Text("14.26号守卫0.38秒");
        ImGui::Text("15.爱哭鬼0.37秒");
        ImGui::Text("15.蜘蛛0.37秒");
        ImGui::Text("15.守夜人0.37秒");
        ImGui::Text("16.噩梦0.36秒");
        ImGui::Text("17.厂长0.35秒");
        ImGui::Text("18.宿伞之魂【黑】0.32秒");
        ImGui::Text("19.歌剧演员0.31秒");
        ImGui::Text("20.鹿头0.3秒");
        ImGui::Text("21.渔女0.27秒");
        ImGui::Text("22.小丑（无风翼）0.25秒");
        ImGui::End();

    }
    if (拉锯震慑) {

        ImGui::Begin("震慑");
        ApplyPinkTheme();
        if (触摸2) {
            ImGui::Text("正在自动博弈");
        }
        else {
            ImGui::Text("关闭状态");
        }


        if (ImGui::Button("开/关", { 150,70 })) {
            触摸2 = !触摸2;
        }
        /* if (ImGui::Button("停止", {150,70})) {
             触摸2 = !触摸2;
             Touch::Upyuan();
         }*/
        ImGui::End();


    }
    if (孽蜥开关) {
        ImGui::Begin("孽蜥");
        ApplyPinkTheme();
        const char* statusText2 = 孽蜥坠机 ? "开" : "关";
        ImGui::Text("当前状态: %s", statusText2);
        if (ImGui::Button("开/关", { 150,70 })) {
            孽蜥坠机 = !孽蜥坠机;
        }




        ImGui::SameLine();
        if (ImGui::Button("下落/坠机", { 150, 70 })) {
            if (isFirstClick) {
                if (!平板) {
                    ResetConfig9();
                }
                else {

                    ResetConfig平板下落();
                }
            }
            else {
                if (!平板) {
                    ResetConfig6();
                }
                else {

                    ResetConfig平板坠机();
                }
            }
            // 切换点击状态
            isFirstClick = !isFirstClick;
        }
        ImGui::End();
    }
   
    if (盖板快捷) {
        ImGui::Begin("盖板");
        ApplyPinkTheme();
        const char* statusText1 = show_draw_touch ? "开" : "关";
        ImGui::Text("当前状态: %s", statusText1);
        // 添加一个按钮，当点击时切换show_draw_Chair、show_draw_Box和show_draw_DIANJI的状态
        if (ImGui::Button("开/关", { 150,70 }))
        {
            show_draw_touch = !show_draw_touch;

        }
        // 结束ImGui窗口
        ImGui::End();
    }

    if (被打预警) {

        ImGui::SetNextWindowBgAlpha(0.0f);  // 完全透明

        // 创建窗口，设置窗口标志
        ImGuiWindowFlags windowFlags = ImGuiWindowFlags_NoCollapse |  // 禁止折叠
            // 禁止调整大小
            ImGuiWindowFlags_NoBackground; // 没有背景

        ImGui::Begin(" ", nullptr, windowFlags);
        ImGui::Text("监管距离: %d", 显示监管距离);
        ImGui::Text("预警信息: %s", yujingjuli.c_str());
        ImGui::End();


    }
    ImGui::SetNextWindowPos(ImVec2(subWindowPosX, subWindowPosY));
    if (宿伞) {
        ImGui::Begin(" ", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoCollapse);

        ImGui::Button(" ", { 190, 190 });

        if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && ImGui::IsItemHovered()) {
            buttonPressed2 = true;
            buttonPressed = true;
            startTime = ImGui::GetTime();
        }

        if (ImGui::IsMouseReleased(ImGuiMouseButton_Left) && buttonPressed) {
            伞距离 = 1;
            buttonPressed = false;
            buttonPressed2 = false;
        }

        if (buttonPressed) {
            double currentTime = ImGui::GetTime();
            if (currentTime - startTime >= incrementInterval) {
                伞距离++;
                startTime = currentTime;
            }
        }

        ImGui::End();
    }

   // displayPlayerInfo(players);





}//drawmain结束


}




//UI结束
