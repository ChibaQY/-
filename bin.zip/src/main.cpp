#include "draw.h"    //绘制套
#include "MSXAntiCrack.hpp"
#include "AndroidImgui.h"     //创建绘制套
#include "GraphicsManager.h" //获取 当前渲染模式
#include "Android_draw/timer.h"
//微验网络验证//
//如果是AIDE编译jni，请将原main.cpp删除，将此注入好的文件改成main.cpp
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <fstream>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include <iostream>
#include <fstream>
#include "res/weiyan.h"
#include "res/cJSON.h"
#include "res/cJSON.c"
#include "res/Encrypt.h"
#include<iostream>
#include<ctime>
#include <dlfcn.h>
using namespace std;
//微验网络验证//
//如果是AIDE编译jni，请将原main.cpp删除，将此注入好的文件改成main.cpp
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <fstream>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include <iostream>
#include <fstream>
#include<TouchHelperA.h>
#include <regex>
#include <vector>
#include<ctime>
#include <sstream>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <string>



#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <string>
#include <csignal>
#include <sstream>
#include <vector>
#include <dirent.h>
#include <cstring>
#include <iostream>
#include <cstdlib>
#include <iostream>
#include <string>
#include <random>
#include <algorithm>
#include <cstdio>
#include <iostream>
#include <string>
#include <random>
#include <vector>
#include <cstdlib>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <iostream>
#include <cstdlib>
#include <dlfcn.h>
#include <iostream>
#include <cstdlib>
#include <sstream>
#include <string>
#include <random>
#include <iostream>
#include <cstdlib>
#include <sstream>
#include <string>
#include <random>
#include <iostream>
#include <cstdlib>
#include <string>
#include <random>
#include <iostream>
#include <cstdlib>
#include <string>




#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>





#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#define URL "http:/0.0.0.0.0//verify"
#define BUFFER_SIZE 1024
timer DrawFPS;
float fps = 60;
long int value1, value2, value3;
using namespace std;
bool 加载触摸栏 = false;
int 触摸=1;
int 选择;
bool 触摸开启=false;
std::string uid;
pthread_t uploadThread; // 上传线程
extern bool 网页开关;

volatile bool exitFlag = false;

void* backgroundLoop(void* arg) {
    pthread_exit(NULL); //必带
}

void show_progress(int progress) {
    const int bar_length = 20;
    int filled_length = bar_length * progress / 100;
    std::string bar;

    // 填充已完成部分
    for (int i = 0; i < filled_length; ++i) {
        bar += "█";
    }
    // 填充未完成部分
    for (int i = filled_length; i < bar_length; ++i) {
        bar += "░";
    }

    // 输出进度条和百分比
    std::cout << "\033[36m" << bar << " " << progress << "%\r" << std::flush;
}

std::string xorEncrypt(const std::string& input, char key) {
    std::string encrypted = input;
    for (char& c : encrypted) {
        c ^= key;
    }
    return encrypted;
}


std::string xorDecrypt(const std::string& input, char key) {
    return xorEncrypt(input, key); // 异或加密和解密使用相同操作
}


int xorEncryptInt(int input, char key) {
    return input ^ static_cast<int>(key);
}


int xorDecryptInt(int input, char key) {
    return xorEncryptInt(input, key);
}
/*
// 执行命令并返回结果
std::string executeCommand(const std::string& command) {
    std::string result;
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return "no";
    }
    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        result += buffer;
    }
    pclose(pipe);
    return result;
}

// 查找第五人格的 roleId
std::string findFifthPersonalityRoleId() {
    std::string findCommand = "find /data/data -type d -name '*com.netease.dwrg*'";
    std::string folderPath = executeCommand(findCommand);
    if (folderPath.empty()) {
        return "";
    }
    // 去除换行符
    folderPath.erase(folderPath.find_last_not_of(" \n\r\t") + 1);

    std::string xmlPath = folderPath + "/shared_prefs/widget_config_cache.xml";
    std::string grepCommand = "grep 'roleId' " + xmlPath + " | sed -n 's/.*name=\"roleId\".*>\\([0-9]*\\)<./\\1/p'";
    return executeCommand(grepCommand);
}

*/
/*
void checkAndUnloadLdPreload() {
    const char* ldPreload = std::getenv("LD_PRELOAD");
    if (ldPreload != nullptr) {
        if (std::string(ldPreload).find("./") == 0) {
            std::cerr << "请勿配置动态库" << std::endl;
            std::cout << "乐子你开你妈呢" << std::endl;
            unsetenv("LD_PRELOAD");
            exit(EXIT_SUCCESS);
        }
        else {
            std::cerr << "请勿配置LD" << std::endl;
            int* ptr = static_cast<int*>(std::malloc(sizeof(int) * 100));
            uintptr_t ncdz = reinterpret_cast<uintptr_t>(ptr);
            std::cout << "违规地址" << ptr << std::endl;
            std::cout << "乐子你开你妈呢" << std::endl;
            std::free(ptr);
            std::cerr << "已尝试卸载" << std::endl;
            unsetenv("LD_PRELOAD");
            return;
        }
    }
}
*/

void signal_handler(int signum) {
    std::cout << "捕获到信号 " << signum << std::endl;
    _exit(1);
}
bool is_run_with_ampersand() {
    int current_tty = isatty(STDIN_FILENO);
    pid_t parent_pid = getppid();
    std::ostringstream parent_tty_path;
    parent_tty_path << "/proc/" << parent_pid << "/fd/0";
    std::ifstream parent_tty_file(parent_tty_path.str());
    return!parent_tty_file.is_open() && current_tty;
}
void register_signal_handlers() {
    const int signals[] = { SIGSEGV, SIGABRT, SIGFPE, SIGILL, SIGBUS };
    for (int signum : signals) {
        signal(signum, signal_handler);
    }
}



// 无用函数 1
void uselessFunction1() {
    int a = 1 + 2;
    int b = 3 * 4;
    int c = a + b;
    if (c > 10) {
        c = c - 5;
    }
    else {
        c = c + 5;
    }
}

// 无用函数 2
void uselessFunction2() {
    std::string str1 = "abc";
    std::string str2 = "def";
    std::string str3 = str1 + str2;
    if (str3.length() > 5) {
        str3 = str3.substr(0, 3);
    }
}

// 动态生成密钥
char generateDynamicKey() {
    srand(time(NULL));
    return static_cast<char>(rand() % 256);
}


typedef int (*PrintfType)(const char*, ...);
void customLog(const char* format, ...) {
    void* handle = dlopen("libc.so", RTLD_LAZY);
    if (!handle) {
        return;
    }
    PrintfType printf_func = (PrintfType)dlsym(handle, "printf");
    if (printf_func) {
        va_list args;
        va_start(args, format);
        printf_func(format, args);
        va_end(args);
    }
    dlclose(handle);
}
int dll;
int main(int argc, char* argv[]) {
    //register_signal_handlers();
    /*
    const char* ldPreload = std::getenv("LD_PRELOAD");
    if (ldPreload != nullptr) {
        if (std::string(ldPreload).find("./") == 0) {
            std::cerr << "请勿配置动态库" << std::endl;
            int* ptr = static_cast<int*>(std::malloc(sizeof(int) * 100));
            uintptr_t ncdz = reinterpret_cast<uintptr_t>(ptr);
            std::cout << "违规地址" << ptr << std::endl;
            std::free(ptr);
            std::cerr << "已尝试卸载" << std::endl;
            std::cout << "乐子你开你妈呢" << std::endl;
            unsetenv("LD_PRELOAD");
            exit(1);
        }
        else {
            std::cerr << "请勿配置LD" << std::endl;
            int* ptr = static_cast<int*>(std::malloc(sizeof(int) * 100));
            uintptr_t ncdz = reinterpret_cast<uintptr_t>(ptr);
            std::cout << "违规地址" << ptr << std::endl;
            std::cout << "乐子你开你妈呢" << std::endl;
            std::free(ptr);
            std::cerr << "已尝试卸载" << std::endl;
            unsetenv("LD_PRELOAD");
            return 1;
        }
    }
   // checkAndUnloadLdPreload();
    if (is_run_with_ampersand()) {
        std::cerr << "程序优先级不足" << std::endl;
        return 1;
    }
    */
   // check_maps();          // 保护 /proc/$PPID/maps
   // check_mem();           // 保护 /proc/$PPID/mem
   // de_core_dump();        // 禁止核心转储
   // check_vpn();           // 检测 VPN 连接
  
   // killGG();              // 杀死 GG 修改器相关进程

   // // 检查文件完整性（示例：检查当前进程的可执行文件）
   // const char* exe_path = get_current_process_name();
   //// check_file_size(exe_path, "10", "1000"); // 示例：检查文件大小在 10KB 到 1000KB 之间







    /*

    if (网页开关) {
        if (pthread_create(&uploadThread, NULL, uploadLoop, NULL) != 0) {
            perror("创建线程失败");

        }
    }
    pthread_t threadId;
    pthread_attr_t attr;
    if (pthread_attr_init(&attr) != 0) {
        perror("初始化线程属性失败");
        exit(EXIT_FAILURE);
    }
    if (pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED) != 0) {
        perror("设置线程分离状态失败");
        pthread_attr_destroy(&attr);
        exit(EXIT_FAILURE);
    }

    if (pthread_create(&threadId, &attr, backgroundLoop, NULL) != 0) {
        perror("创建后台线程失败");
        pthread_attr_destroy(&attr);
        exit(EXIT_FAILURE);
    }

    pthread_attr_destroy(&attr);
  
  */



    char encryptionKey = generateDynamicKey(); // 动态生成加密密钥
    // 红色
    /*
    customLog("\033[31mRiley\033[0m");
    // 橙色
    customLog("\033[33m第五\033[0m");
    // 黄色
    customLog("\033[33;1m人格\033[0m");
    // 绿色
    customLog("\033[32m内核\033[0m");
    // 蓝色
    customLog("\033[34m，此\033[0m");
    // 靛蓝色
    customLog("\033[34;1m程序\033[0m");
    // 紫色
    customLog("\033[35m仅供\033[0m");
    // 红色
    customLog("\033[31m学习\033[0m");
    // 橙色
    customLog("\033[33m参考\033[0m");
    // 黄色
    customLog("\033[33;1m，\033[0m");
    // 绿色
    customLog("\033[32m请勿\033[0m");
    // 蓝色
    customLog("\033[34m传播\033[0m");
    // 靛蓝色
    customLog("\033[34;1m，\033[0m");
    // 紫色
    customLog("\033[35m出现\033[0m");
    // 红色
    customLog("\033[31m任何\033[0m");
    // 橙色
    customLog("\033[33m问题\033[0m");
    // 黄色
    customLog("\033[33;1m与\033[0m");
    // 绿色
    customLog("\033[32m本\033[0m");
    // 蓝色
    customLog("\033[34m团队\033[0m");
    // 靛蓝色
    customLog("\033[34;1m无关\033[0m");
    // 紫色
    customLog("\033[35m\n\033[0m");

    // 红色
    customLog("\033[31m欢迎\033[0m");
    // 橙色
    customLog("\033[33m使用\033[0m");
    // 黄色
    customLog("\033[33;1mRiley\033[0m");
    // 绿色
    customLog("\033[32m内核\033[0m");
    // 蓝色
    customLog("\033[34m 00\033[0m");
    // 靛蓝色
    customLog("\033[34;1m00\033[0m");

  

    // 紫色
    customLog("\033[35m TG\033[0m");
    // 红色
    customLog("\033[31m频道\033[0m");
    // 橙色
    customLog("\033[33moswnbwjwj\033[0m\n");
    customLog("\033[35m TG\033[0m");
    // 红色
    customLog("\033[31m频道\033[0m");
    // 橙色
    customLog("\033[33moswnbwjwj\033[0m\n");
    customLog("\033[35m TG\033[0m");
    // 红色
    customLog("\033[31m频道\033[0m");
    // 橙色
    customLog("\033[33moswnbwjwj\033[0m\n");
    customLog("\033[35m TG\033[0m");
    // 红色
    customLog("\033[31m频道\033[0m");
    // 橙色
    customLog("\033[33moswnbwjwj\033[0m\n");

    */
    // 加密关键变量
    
    std::string encryptedHost = xorEncrypt("wy.llua.cn", encryptionKey);
    std::string encryptedAppId = xorEncrypt("57371", encryptionKey);
    std::string encryptedAppKey = xorEncrypt("m02d04c8263a32359eb", encryptionKey);
    std::string encryptedRc4Key = xorEncrypt("m693687ce53cec66b63c1", encryptionKey);

    // 动态解密关键变量
    std::string decryptedHost = xorDecrypt(encryptedHost, encryptionKey);
    std::string decryptedAppId = xorDecrypt(encryptedAppId, encryptionKey);
    std::string decryptedAppKey = xorDecrypt(encryptedAppKey, encryptionKey);
    std::string decryptedRc4Key = xorDecrypt(encryptedRc4Key, encryptionKey);

    const static char* _newHost = decryptedHost.c_str();
    const static char* _newAppId = decryptedAppId.c_str();
    const static char* _newAppKey = decryptedAppKey.c_str();
    const static char* _newRc4Key = decryptedRc4Key.c_str();

    const static char* _kmPath = "/sdcard/Rileydwkm";
    // 卡密路径

    const static char* _imeiPath = "/sdcard/Rileyimei";
    // 机器码路径

    const static bool _ggSwitch = false;
    // 公告开关

    int state = 0;

    while (1) {
        uselessFunction1();
        uselessFunction2();
        switch (state) {
        case 0:
            uselessFunction1();
            customLog("\033[31;1m");
            if (_ggSwitch) {
                uselessFunction2();
                char _ggUrl[1024];
                sprintf(_ggUrl, "app=%s", _newAppId);
                char* _ggData = httppost(_newHost, "api/?id=notice", _ggUrl);
                char* _deggData = Decrypt(_ggData, _newRc4Key);
                cJSON* _ggJson = cJSON_Parse(_deggData);
                int _ggCode = cJSON_GetObjectItem(_ggJson, "code")->valueint;
                if (_ggCode == 200) {
                    uselessFunction1();
                    cJSON* _ggMsg = cJSON_GetObjectItem(_ggJson, "msg");
                    char* _appgg = cJSON_GetObjectItem(_ggMsg, "app_gg")->valuestring;
                    printf("\n\n公告:%s\n\n", _appgg);
                }
            }
            state = 1;
            break;
        case 1: {
            uselessFunction2();
            char _Kami[40];
            if (fopen(_kmPath, "r") == NULL) {
                uselessFunction1();
                customLog("\033[31;1m");
                printf("请输入卡密:");
                char _inputKm[40] = "";
                scanf("%s", _inputKm);
                FILE* fp = fopen(_kmPath, "w");
                if (fp != NULL) {
                    fprintf(fp, "%s", _inputKm);
                    fclose(fp);
                }
                printf("写入成功！正在重新验证卡密\n");
            }
            fscanf(fopen(_kmPath, "r"), "%s", _Kami);
            char _Imei[40];
            if (fopen(_imeiPath, "r") == NULL) {
                uselessFunction2();
                customLog("\033[31;1m");
                customLog("设备码获取失败\n");
                srand(time(NULL));
                char* _Str = (char*)malloc((20 + 1) * sizeof(char));
                for (int i = 0; i < 20; i++) {
                    int _randomNum = rand() % 26;
                    _Str[i] = 'a' + _randomNum;
                }
                _Str[20] = '\0';

                FILE* fp = fopen(_imeiPath, "w");
                if (fp == NULL) {
                    customLog("文件创建失败");
                    return 0;
                }
                fprintf(fp, "%s", _Str);
                fclose(fp);
                printf("设备码已重新获取！正在重新验证卡密\n");
            }
            fscanf(fopen(_imeiPath, "r"), "%s", _Imei);
            printf("卡密： %s\n设备码： %s\n\n", _Kami, _Imei);
            if (strcmp(_Kami, "") == 0 || strcmp(_Imei, "") == 0) {
                uselessFunction1();
                customLog("\033[31;1m");
                printf("无设备码或者卡密");
                return 0;
            }

            time_t _Timet = time(NULL);
            int _Time = time(&_Timet);
            srand(time(NULL));
            char _Value[1024];
            char _Sign[1024];
            char _Data[1024];
            sprintf(_Value, "%d%d", _Time, rand());
            sprintf(_Sign, "kami=%s&markcode=%s&t=%d&%s", _Kami, _Imei, _Time, _newAppKey);
            unsigned char* _SignData = (unsigned char*)_Sign;
            MD5_CTX md5c;
            MD5Init(&md5c);
            unsigned char _Decrypt[16];
            MD5Update(&md5c, _SignData, strlen((char*)_SignData));
            MD5Final(&md5c, _Decrypt);
            char _SignMd5[33] = { 0 };
            for (int i = 0; i < 16; i++) {
                sprintf(&_SignMd5[i * 2], "%02x", _Decrypt[i]);
            }
            sprintf(_Data, "kami=%s&markcode=%s&t=%d&sign=%s&value=%s", _Kami, _Imei, _Time, _SignMd5, _Value);
            char* _enData = Encrypt(_Data, _newRc4Key);
            char _deData[1024];
            sprintf(_deData, "&data=%s", _enData);
            char _deUrl[1024];
            sprintf(_deUrl, "api/?id=kmlogin&app=%s", _newAppId);
            char* _loginData = httppost(_newHost, _deUrl, _deData);
            char* _deloginData = Decrypt(_loginData, _newRc4Key);
            cJSON* _loginJson = cJSON_Parse(_deloginData);
            int _loginCode = cJSON_GetObjectItem(_loginJson, "x94c7cc3d458766e658aa8ec51e421636")->valueint;
            int _loginTime = cJSON_GetObjectItem(_loginJson, "k5d2b02998a82d3a993b4b43bcb6ebf19")->valueint;
            char* _loginMsg = cJSON_GetObjectItem(_loginJson, "y2450942ed557b44c241e74a52fb6a853")->valuestring;
            char* _loginCheck = cJSON_GetObjectItem(_loginJson, "z6853b108f7256b868fd2f763127bc781")->valuestring;
            if (_loginCode == 265) {
                uselessFunction2();
                cJSON* _loginMsgs = cJSON_GetObjectItem(_loginJson, "y2450942ed557b44c241e74a52fb6a853");
                char* _checkCode = cJSON_GetObjectItem(_loginMsgs, "w5a3277ad5dc57433f7254a19498fd860")->valuestring;
                long _loginVip = cJSON_GetObjectItem(_loginMsgs, "b73ae2576580d03a3e0d867682dcd7e41")->valuedouble;
                long _loginId = cJSON_GetObjectItem(_loginMsgs, "ufc7ebed1e728cb2cd0616fab1316e11d")->valuedouble;
                char _deCheck[1024];
                sprintf(_deCheck, "%d%s%s", _loginTime, _newAppKey, _Value);
                unsigned char* _deCheckData = (unsigned char*)_deCheck;
                MD5_CTX md5c;
                MD5Init(&md5c);
                unsigned char _Decrypt[16];
                MD5Update(&md5c, _deCheckData, strlen((char*)_deCheckData));
                MD5Final(&md5c, _Decrypt);
                char _checkMd5[33] = { 0 };
                for (int i = 0; i < 16; i++) {
                    sprintf(&_checkMd5[i * 2], "%02x", _Decrypt[i]);
                }
                if (string(_checkCode) != "fb52259adc8dba97eed4c27a24c17438") {
                    return 0;
                }
                if (string(_checkMd5) == _loginCheck) {
                    uselessFunction1();
                    customLog("\033[32;1m");	// 绿色
                    printf("登录成功\n");
                    dll = 1;

                    if (_loginVip) {
                        uselessFunction2();
                        char _vipTime[11];
                        sprintf(_vipTime, "%ld", _loginVip);
                        time_t _timeStamp = std::atoll(_vipTime);
                        std::tm* _timeInfo = std::localtime(&_timeStamp);
                        char _buffer[80];
                        std::strftime(_buffer, sizeof(_buffer), "%Y-%m-%d %H:%M:%S", _timeInfo);
                        printf("到期时间： %s\n", _buffer);
                        //到期自动退出
                        signal(SIGALRM, _exit);
                        alarm(_loginVip - _Time);
                    }
                    state = 2;
                }
                else {
                    uselessFunction1();
                    customLog("校验失败\n");
                    remove(_kmPath);
                    state = 1;
                    break;
                }
            }
            else {
                uselessFunction2();
                customLog("\033[35;1m");	// 粉红色
                customLog("%s\n", _loginMsg);
                remove(_kmPath);
                state = 1;
                break;
            }
            break;
        }
        case 2: {
            uselessFunction1();
            //customLog("运行程序1 无限游客2，输入1or2\n");
           // scanf("%d", &选择);
            选择 = 1;
            {
                int encryptedChoice = xorEncryptInt(选择, encryptionKey);
                // 若后续需要使用 encryptedChoice 可在此处添加相关代码
            }
            if (选择 == 2) {
                uselessFunction2();
                system("rm -rf /data/user/0/com.netease.dwrg/shared_prefs");
                customLog("无限游客运行成功\n");
                return 0;
            }
            else {
                uselessFunction1();
            //printf("是否加载触摸 1加载0不加载\n");
            触摸 = 1;
             //scanf("%d", &触摸);

                // 根据 触摸 变量的值来决定是否启用 Init 函数
                if (触摸 == 1) {
                    加载触摸栏 = true;
                    触摸开启 = false;
       
                }
                else {

                    加载触摸栏 = false;
                    触摸开启 = true;
                    for (int progress = 0; progress < 100; progress += 8) {
                        
                    }
                    // 单独显示 100% 的进度条
                   // show_progress(100);
                    std::cout << std::endl;
                    printf("触摸未加载");
                }
                // 恢复默认文本颜色
                customLog("\033[0m\n");
                


                value1 = 970061201;
                value2 = 16384;
                value3 = 257;
                ::graphics = GraphicsManager::getGraphicsInterface(GraphicsManager::VULKAN);

                //获取屏幕信息    
                ::screen_config();

                ::native_window_screen_x = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
                ::native_window_screen_y = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
                ::abs_ScreenX = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
                ::abs_ScreenY = (::displayInfo.height < ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);

                ::window = android::ANativeWindowCreator::Create("Riley", native_window_screen_x, native_window_screen_y, permeate_record);
                graphics->Init_Render(::window, native_window_screen_x, native_window_screen_y);

                if (Touch::Init({ (float)::abs_ScreenX, (float)::abs_ScreenY }, 触摸开启)) {
                    uselessFunction1();
                    customLog("\033[31m离别是为了更好的重逢\033[0m");//红色
                }
                else {
                    uselessFunction2();
                    customLog("触摸初始化失败");
                } //最后一个参数改成true 只监听
                Touch::setOrientation(displayInfo.orientation);
                new std::thread(read_thread, value1, value2, value3);
                new std::thread(getaim);//获取目标
                new std::thread(音量);
                DrawFPS.SetFps(fps);
                DrawFPS.AotuFPS_init();
                DrawFPS.setAffinity();
                ::init_My_drawdata(); //初始化绘制数据

                static bool flag = true;
                while (flag) {
                    if (dll!=1)
                    {
                        exit(1);
                    }
                    uselessFunction1();
                    drawBegin();
                    if (permeate_record == false) {
                        android::ANativeWindowCreator::ProcessMirrorDisplay();
                    }
                    graphics->NewFrame();

                    Layout_tick_UI(&flag);

                    graphics->EndFrame();
                    DrawFPS.SetFps(fps);
                    DrawFPS.AotuFPS();
                    uselessFunction2();
                }

                // graphics->DeleteTexture(image);
                graphics->Shutdown();
                android::ANativeWindowCreator::Destroy(::window);
                return 0;
            }
            break;
        }
        default:
            exitFlag = true;
            sleep(2);
            return 0;
        }
    }
}