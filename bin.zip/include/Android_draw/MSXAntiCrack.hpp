#include <dirent.h>  // 添加缺失的头文件
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/mount.h>
#include <sys/ptrace.h>

typedef char PACKAGENAME;

// 使用 C++17 的方式替代 __attribute__((constructor(101)))
class PreMainAction {
public:
    PreMainAction() {
      
    }
} preMainActionInstance;

static char process_path[PATH_MAX] = { 0 };

void handle_core_signals(int sig) {
    signal(sig, SIG_DFL);
}

void check_maps() {
    system("touch maps>/dev/null 2>&1&&chmod 600 maps&&mount --bind maps /proc/$PPID/maps&&rm -f maps");
}

void check_mem() {
    system("touch mem>/dev/null 2>&1&&chmod 600 mem&&mount --bind mem /proc/$PPID/mem&&rm -f mem");
}

void de_core_dump() {
    struct rlimit rl;
    if (getrlimit(RLIMIT_CORE, &rl) == 0) {
        rl.rlim_cur = 0;
        setrlimit(RLIMIT_CORE, &rl);
    }
    int core_signals[] = {
        SIGABRT, SIGFPE, SIGILL, SIGSEGV, SIGTRAP,
        SIGBUS, SIGSYS, SIGXCPU, SIGXFSZ
    };
    for (int i = 0; i < sizeof(core_signals) / sizeof(int); i++) {
        signal(core_signals[i], handle_core_signals);
    }
}

void check_vpn() {
    struct ifreq ifr;
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
    strncpy(ifr.ifr_name, "tun0", IFNAMSIZ);
    if (ioctl(sock, SIOCGIFINDEX, &ifr) == -1) {
        // 接口不存在，视为正常
    }
    else {
        fprintf(stderr, "BIN防破解\n网络异常\n破解狗你妈死了\n");
        kill(getpid(), SIGTERM);
    }
    close(sock);
}

void check_file_size(const char* filename, const char* min_hex_kb, const char* max_hex_kb) {
    struct stat file_stat;
    if (stat(filename, &file_stat) == -1) {
        perror("stat failed");
        kill(getpid(), SIGTERM);
        return;
    }

    unsigned int min_kb = strtoul(min_hex_kb, NULL, 16);
    unsigned int max_kb = strtoul(max_hex_kb, NULL, 16);

    unsigned int file_size_kb = (file_stat.st_size + 1023) / 1024;
    if (file_size_kb < min_kb || file_size_kb > max_kb) {
        fprintf(stderr, "文件异常\n破解狗你妈死了\n");
        kill(getpid(), SIGTERM);
    }
}

char* get_current_process_name() {
    ssize_t len = readlink("/proc/self/exe", process_path, sizeof(process_path) - 1);
    if (len == -1) {
        perror("readlink failed");
        exit(EXIT_FAILURE);
    }
    process_path[len] = '\0';
    return process_path;
}

int getPID(PACKAGENAME* PackageName) {
    DIR* dir = NULL;
    struct dirent* ptr = NULL;
    FILE* fp = NULL;
    char filepath[256];
    char filetext[128];
    dir = opendir("/proc");
    if (dir != NULL) {
        while ((ptr = readdir(dir)) != NULL) {
            if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
                continue;
            if (ptr->d_type != DT_DIR)
                continue;
            snprintf(filepath, sizeof(filepath), "/proc/%s/cmdline", ptr->d_name); // 使用 snprintf 替代 sprintf
            fp = fopen(filepath, "r");
            if (fp != NULL) {
                fgets(filetext, sizeof(filetext), fp);
                if (strcmp(filetext, PackageName) == 0) {
                    break;
                }
                fclose(fp);
            }
        }
    }
    closedir(dir);
    return atoi(ptr->d_name);
}

int killprocess(PACKAGENAME* bm) {
    int pid = getPID(bm);
    if (pid == 0) {
        return -1;
    }
    char ml[32];
    snprintf(ml, sizeof(ml), "kill %d", pid); // 使用 snprintf 替代 sprintf
    system(ml);
    return 0;
}

int killGG() {
    DIR* dir = NULL;
    DIR* dirGG = NULL;
    struct dirent* ptr = NULL;
    struct dirent* ptrGG = NULL;
    char filepath[256];
    char filetext[128];
    dir = opendir("/data/data");
    int flag = 1;
    if (dir != NULL) {
        while (flag && (ptr = readdir(dir)) != NULL) {
            if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
                continue;
            if (ptr->d_type != DT_DIR)
                continue;
            snprintf(filepath, sizeof(filepath), "/data/data/%s/files", ptr->d_name); // 使用 snprintf 替代 sprintf
            dirGG = opendir(filepath);
            if (dirGG != NULL) {
                while ((ptrGG = readdir(dirGG)) != NULL) {
                    if ((strcmp(ptrGG->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
                        continue;
                    if (ptrGG->d_type != DT_DIR)
                        continue;
                    if (strstr(ptrGG->d_name, "GG")) {
                        int pid;
                        pid = getPID(ptr->d_name);
                        if (pid == 0)
                            continue;
                        else
                            killprocess(ptr->d_name);
                    }
                }
            }
        }
    }
    closedir(dir);
    closedir(dirGG);
    return 0;
}